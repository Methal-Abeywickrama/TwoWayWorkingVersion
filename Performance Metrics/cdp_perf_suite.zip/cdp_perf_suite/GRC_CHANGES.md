# What is different from your working file (for applying it to another .grc by hand)

`perf_hw.grc` = your `integrationTest.grc` + the Stage 1 changes + the items below. Already done in
`perf_hw.grc`; this list is only for when you want the same in another file. The block sources are in `blocks_src/`.

## 0. Stage 1 (radio + addressing)
- PlutoSDR Sink enabled: frequency `int(tx_freq)`, bandwidth `int(1.5e6)`. PlutoSDR Source enabled: frequency `int(rx_freq)`, bandwidth `int(1.5e6)`.
- The Channel Model moved from the TX→RX loopback into the RX chain (AGC → Channel Model → FLL). Its noise comes from the `nv` slider (0 = transparent).
- Framer: link `dest_id` = the FSM's `dst_addr` (fallback `peer_id = tl_peer_addr`). Deframer: `max_bit_errors = MAX_BIT_ERRORS` (was wired to tl_peer_addr), and it accepts its own address or 0.

## 0b. Plain GRC variables instead of environment variables
| Variable | Value | Used by |
|---|---|---|
| MY_ID | 0 (other PC: 1) | tl_local_addr, deframer peer_id, FSM, filters |
| PEER_ID | 1 (other PC: 0) | tl_peer_addr, framer peer_id |
| tl_local_addr / tl_peer_addr | `MY_ID` / `PEER_ID` | |
| fdd_side | `'A' if MY_ID < PEER_ID else 'B'` | |
| tx_freq / rx_freq | `TX_FREQ_A if fdd_side == 'A' else TX_FREQ_B` / the opposite | Pluto sink / source |
| ADDR | `"ip:192.168.1.10"` | Pluto URI |
| PREAMBLE_LEN / POSTAMBLE_LEN / MAX_BIT_ERRORS | 1024 / 160 / 1 | framer / deframer |
| tl_mtu, tl_rto_ms, tl_m, tl_max_retries, tl_local_port, tl_role | 200, 500, 4, 10, 1, 'initiator' | SR-ARQ FSM |
| tl_zmq_tx_port, tl_zmq_rx_port | 52001, 52002 | app ZMQ |

**Address-0 fix**, in `pdu_pdu_filter_0_0` (the broadcast filter): value `pmt.from_uint64(0 if MY_ID != 0 else 255)`.
Before this, on the node with MY_ID 0 both filters passed every packet, so its FSM got each one twice.

Options block: id `cdp_perf` (generated file `cdp_perf.py`, so your `transeciever.py` is untouched).

## 1. Variables
- `tl_zmq_tap_port`  = `52003`
- `tl_zmq_link_port` = `52004`

## 2. Replace the code of two existing embedded blocks (Open in Editor → paste)
- **epy_block_0_0** (framer) ← `blocks_src/framer_tap.py`. It is the same framer with a new output port `stats_out`.
- **epy_block_0_0_0** (deframer) ← `blocks_src/deframer_tap.py`. It is the same deframer with a new output `stats_out` and two new parameters: `tap_raw_max = 9000`, `print_payload = False`. Its `max_bit_errors` is `MAX_BIT_ERRORS`; the framer's `preamble_len` / `postamble_len` are `PREAMBLE_LEN` / `POSTAMBLE_LEN`.

## 3. New embedded blocks
| Block | Source | Parameters |
|---|---|---|
| epy_block_6 "PERF Telemetry Hub" | `hub.py` | node_addr `tl_local_addr`, config_interval `5.0`, config: in perf_hw.grc a dict holding the GRC expression of every block (it feeds the parameter tables); `None` also works |
| epy_block_7 "PERF EVM/SNR Probe" | `evm_probe.py` | sym_rate `samp_rate/sps`, ring_syms `2097152`, pre_syms `1024` |
| epy_block_8 "PERF RSSI/Spectrum Probe" | `rssi_probe.py` | samp_rate `samp_rate`, block `1024`, interval `1.0`, busy_db `3.0`, clip `0.98`, nf_window_s `3.0`, fft_every `4` |

## 4. New ZMQ message blocks
- **ZMQ PUB Message Sink**: address `"tcp://127.0.0.1:" + str(tl_zmq_tap_port)`, timeout 100, bind True.
- **ZMQ PULL Message Source**: address `"tcp://127.0.0.1:" + str(tl_zmq_link_port)`, timeout 100, bind True.

## 5. Connections
Streams:
- `digital_costas_loop_cc_0` out → epy_block_7 in (EVM probe)
- `blocks_copy_1_1` out (raw IQ from the Pluto source) → epy_block_8 in (RSSI probe)

Messages (an output port can feed several inputs, so keep all existing connections):
| From | To |
|---|---|
| epy_block_0_0 `stats_out` | hub `link_tx` |
| epy_block_0_0_0 `stats_out` | hub `link_rx` **and** epy_block_7 `frames` |
| epy_block_7 `evm_out` | hub `evm` |
| epy_block_8 `rssi_out` | hub `rssi` |
| epy_block_1 (FSM) `pdu_out` | hub `tp_tx` |
| epy_block_0 (RX header parser) `pdus` | hub `tp_rx` |
| zeromq_pull_msg_source_0 (app in) `out` | hub `app_in` |
| epy_block_1 (FSM) `app_out` | hub `app_out` |
| hub `out` | ZMQ PUB Message Sink `in` |
| ZMQ PULL Message Source (link) `out` | epy_block_0_0 (framer) `msg_in` |

Nothing else changes: the DSP chain, the FSM, the header blocks and the existing ZMQ app ports stay as they are.
