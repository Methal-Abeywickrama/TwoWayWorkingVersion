"""
PERF EVM / SNR probe (measurement only)

Stream input: the Costas loop output (1 complex sample per BPSK symbol). Symbol n of this
stream is bit n of the deframer input (decoder, diff decoder and unpack are all 1:1), so
the deframer's frame records (abs_bit, nbits) on `frames` tell exactly which symbols
belong to which frame.

For every decided frame it computes, over the frame (plus up to `pre_syms` preamble
symbols before the sync word), decision-directed:
  snr_db   = -20*log10(EVM_rms)   (MER; for BPSK this is Es/N0 = Eb/N0 incl. all impairments)
  evm_pct, amp (mean |I|), q_rms (quadrature spread / amp), drift_hz (residual frequency:
  slope of the symbol phase across the frame), ph_std_deg
and publishes them on `evm_out` as JSON. Below ~5 dB the decision-directed estimate
reads high (decision errors hide noise).
"""
import json
import time

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.sync_block):
    def __init__(self, sym_rate=375000.0, ring_syms=2097152, pre_syms=1024):
        gr.sync_block.__init__(self, name="PERF EVM/SNR Probe", in_sig=[np.complex64], out_sig=None)
        self.sym_rate = float(sym_rate)
        self.pre_syms = int(pre_syms)
        self._R = int(ring_syms)
        self._ring = np.zeros(self._R, dtype=np.complex64)
        self._n = 0                      # symbols seen so far (absolute index of the next one)
        self._pending = []
        self.message_port_register_in(pmt.intern("frames"))
        self.set_msg_handler(pmt.intern("frames"), self._on_frame)
        self.message_port_register_out(pmt.intern("evm_out"))

    def _on_frame(self, msg):
        try:
            d = pmt.cdr(msg) if pmt.is_pair(msg) else msg
            rec = json.loads(bytes(pmt.u8vector_elements(d)).decode())
        except Exception:
            return
        if rec.get("status") not in ("ok", "crc_fail"):
            return
        self._pending.append(rec)
        self._process()

    def _get(self, a, b):
        if b > self._n or a < self._n - self._R or a < 0:
            return None
        idx = np.arange(a, b) % self._R
        return self._ring[idx]

    def _process(self):
        keep = []
        for rec in self._pending:
            a = int(rec["abs_bit"]) - self.pre_syms
            b = int(rec["abs_bit"]) + int(rec["nbits"])
            if b > self._n:
                keep.append(rec)            # those symbols have not reached this block yet
                continue
            x = self._get(max(a, 0), b)
            if x is None or len(x) < 64:
                continue
            out = self._measure(x.astype(np.complex128))
            out.update({"tap": "evm", "t": time.time(), "abs_bit": rec["abs_bit"], "status": rec["status"],
                        "msg_id": rec.get("msg_id"), "n": int(len(x))})
            data = json.dumps(out, separators=(",", ":")).encode()
            self.message_port_pub(pmt.intern("evm_out"),
                                  pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data))))
        self._pending = keep[-64:]

    def _measure(self, x):
        d = np.where(x.real >= 0, 1.0, -1.0)
        amp = float(np.mean(x.real * d))
        if amp <= 1e-9:
            return {"snr_db": None}
        err = x - amp * d
        evm = float(np.sqrt(np.mean(np.abs(err) ** 2)) / amp)
        y = x * d                                   # modulation removed
        ph = np.unwrap(np.angle(y))
        k = np.arange(len(ph))
        slope = float(np.polyfit(k, ph, 1)[0]) if len(ph) > 2 else 0.0
        return {"snr_db": round(-20 * np.log10(max(evm, 1e-6)), 2), "evm_pct": round(100 * evm, 2),
                "amp": round(amp, 4), "q_rms": round(float(np.sqrt(np.mean(x.imag ** 2))) / amp, 4),
                "drift_hz": round(slope * self.sym_rate / (2 * np.pi), 2),
                "ph_std_deg": round(float(np.degrees(np.std(ph - slope * k - np.mean(ph - slope * k)))), 2)}

    def work(self, input_items, output_items):
        x = input_items[0]
        n = len(x)
        if n >= self._R:
            x = x[-self._R:]
        m = len(x)
        start = (self._n + n - m) % self._R
        first = min(m, self._R - start)
        self._ring[start:start + first] = x[:first]
        if m > first:
            self._ring[:m - first] = x[first:]
        self._n += n
        if self._pending:
            self._process()
        return n
