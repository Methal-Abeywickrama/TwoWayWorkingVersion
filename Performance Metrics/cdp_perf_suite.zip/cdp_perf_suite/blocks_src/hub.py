"""
PERF Telemetry Hub (measurement only - nothing here changes the radio or the protocol)

Collects one record per event from every layer and publishes them as JSON PDUs
(PMT pair: NIL . u8vector(JSON)) on `out` -> ZMQ PUB Message Sink -> perf_daemon.py.

Inputs (message ports):
  link_tx  framer stats_out           (JSON, passed through)
  link_rx  deframer stats_out         (JSON, passed through)
  evm      EVM/SNR probe              (JSON, passed through)
  rssi     RSSI/spectrum probe        (JSON, passed through)
  tp_tx    SR-ARQ FSM pdu_out         transport packets sent      (PMT dict -> JSON)
  tp_rx    RX header parser pdus      transport packets received  (PMT dict -> JSON)
  app_in   ZMQ app source out         app frames handed to the FSM
  app_out  SR-ARQ FSM app_out         files delivered + tx_done/tx_failed/tx_busy events

Every `config_interval` seconds it also publishes a "config" record: the evaluated value of
every flowgraph variable plus the public settings of the Python blocks (framer, deframer,
FSM, ...) and the `config` dict given in GRC, and every second a "hb" heartbeat with
per-port message counts. Payload bytes of transport/app messages are not forwarded,
only their length and CRC32.
"""
import base64
import gc
import json
import sys
import threading
import time
import zlib

import pmt
from gnuradio import gr

JSON_PORTS = ("link_tx", "link_rx", "evm", "rssi")
PMT_PORTS = ("tp_tx", "tp_rx", "app_in", "app_out")
SIMPLE = (bool, int, float, str)


def _pmt_value(v):
    try:
        if pmt.is_symbol(v):
            return pmt.symbol_to_string(v)
        if pmt.is_bool(v):
            return bool(pmt.to_bool(v))
        if pmt.is_uint64(v):
            return int(pmt.to_uint64(v))
        if pmt.is_integer(v):
            return int(pmt.to_long(v))
        if pmt.is_real(v):
            return float(pmt.to_double(v))
        if pmt.is_u8vector(v):
            return {"u8len": len(pmt.u8vector_elements(v))}
        if pmt.is_null(v):
            return None
        return str(pmt.to_python(v))
    except Exception as e:  # never let telemetry break the flowgraph
        return f"<{type(e).__name__}>"


def _pmt_dict(d):
    out = {}
    if not pmt.is_dict(d):
        return out
    keys = pmt.dict_keys(d)
    while pmt.is_pair(keys):
        k = pmt.car(keys)
        name = pmt.symbol_to_string(k) if pmt.is_symbol(k) else str(_pmt_value(k))
        out[name] = _pmt_value(pmt.dict_ref(d, k, pmt.PMT_NIL))
        keys = pmt.cdr(keys)
    return out


def _app_header(data):
    """folder_sync_daemon app frame: [dst][port][media][res][len:4] + [name_len:2][name][file]."""
    if len(data) < 8:
        return {}
    h = {"dst_addr": data[0], "dst_port": data[1], "media": data[2], "declared": int.from_bytes(data[4:8], "big")}
    body = data[8:]
    if len(body) >= 2:
        n = int.from_bytes(body[:2], "big")
        if 2 + n <= len(body):
            h["name"] = body[2:2 + n].decode("utf-8", "replace")
            h["file_len"] = len(body) - 2 - n
            h["file_crc"] = zlib.crc32(body[2 + n:])
    return h


class blk(gr.basic_block):
    def __init__(self, node_addr=0, config=None, config_interval=5.0):
        gr.basic_block.__init__(self, name="PERF Telemetry Hub", in_sig=None, out_sig=None)
        self.node_addr = node_addr
        self.config = config
        self.config_interval = config_interval
        self._counts = {p: 0 for p in JSON_PORTS + PMT_PORTS}
        self._tb = self._find_top_block()
        self._t0 = time.time()
        self._seq = 0
        self._lock = threading.Lock()
        for p in JSON_PORTS + PMT_PORTS:
            self.message_port_register_in(pmt.intern(p))
            self.set_msg_handler(pmt.intern(p), (lambda port: (lambda m: self._handle(port, m)))(p))
        self.message_port_register_out(pmt.intern("out"))
        self._stop = threading.Event()
        self._thread = None          # started by start() / first message, not when GRC inspects the block

    # ---------------------------------------------------------------- output
    def _emit(self, rec):
        with self._lock:
            self._seq += 1
            rec["hseq"] = self._seq
        data = json.dumps(rec, separators=(",", ":"), default=str).encode()
        self.message_port_pub(pmt.intern("out"), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data))))

    def _ensure_thread(self):
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, daemon=True)
            self._thread.start()

    def start(self):
        self._ensure_thread()
        return True

    def _handle(self, port, msg):
        self._ensure_thread()
        self._counts[port] += 1
        try:
            if port in JSON_PORTS:
                d = pmt.cdr(msg) if pmt.is_pair(msg) else msg
                rec = json.loads(bytes(pmt.u8vector_elements(d)).decode())
                rec.setdefault("tap", port)
                self._emit(rec)
                return
            rec = {"tap": port, "t": time.time()}
            meta, data = (pmt.car(msg), pmt.cdr(msg)) if pmt.is_pair(msg) else (pmt.PMT_NIL, msg)
            rec["meta"] = _pmt_dict(meta)
            raw = bytes(pmt.u8vector_elements(data)) if pmt.is_u8vector(data) else b""
            rec["len"] = len(raw)
            rec["crc"] = zlib.crc32(raw)
            if port in ("app_in", "app_out") and "event" not in rec["meta"]:
                rec["app"] = _app_header(raw)
            self._emit(rec)
        except Exception as e:
            self._emit({"tap": "hub_error", "t": time.time(), "port": port, "err": repr(e)})

    # ---------------------------------------------------------------- config
    @staticmethod
    def _find_top_block():
        f = sys._getframe(1)
        for _ in range(12):
            if f is None:
                break
            s = f.f_locals.get("self")
            if isinstance(s, gr.top_block):
                return s
            f = f.f_back
        return None

    def _top(self):
        if self._tb is None:
            for o in gc.get_objects():
                try:
                    if isinstance(o, gr.top_block):
                        self._tb = o
                        break
                except Exception:
                    continue
        return self._tb

    @staticmethod
    def _public(obj):
        out = {}
        for k, v in vars(obj).items():
            if k.startswith("_"):
                continue
            if isinstance(v, SIMPLE):
                out[k] = v
            elif isinstance(v, (list, tuple)) and len(v) <= 16 and all(isinstance(x, SIMPLE) for x in v):
                out[k] = list(v)
        return out

    def _config_record(self):
        rec = {"tap": "config", "t": time.time(), "t_start": self._t0, "node_addr": self.node_addr,
               "grc_config": self.config if isinstance(self.config, dict) else None,
               "vars": {}, "blocks": {}}
        tb = self._top()
        if tb is not None:
            for k, v in vars(tb).items():
                if k.startswith("_"):
                    continue
                if isinstance(v, SIMPLE):
                    rec["vars"][k] = v
                elif hasattr(v, "__dict__") and isinstance(v, gr.basic_block) and v is not self:
                    try:
                        pub = self._public(v)
                        if pub:
                            rec["blocks"][k] = {"name": v.name() if callable(getattr(v, "name", None)) else k, **pub}
                    except Exception:
                        pass
        return rec

    def _loop(self):
        last_cfg = 0.0
        while not self._stop.wait(1.0):
            try:
                now = time.time()
                if now - last_cfg >= float(self.config_interval):
                    self._emit(self._config_record())
                    last_cfg = now
                self._emit({"tap": "hb", "t": now, "up": now - self._t0, "counts": dict(self._counts)})
            except Exception as e:
                try:
                    self._emit({"tap": "hub_error", "t": time.time(), "port": "loop", "err": repr(e)})
                except Exception:
                    pass

    def stop(self):
        self._stop.set()
        return True
