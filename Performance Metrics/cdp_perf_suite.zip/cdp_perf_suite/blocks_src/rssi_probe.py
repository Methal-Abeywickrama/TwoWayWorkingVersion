"""
PERF RSSI / spectrum probe (measurement only)

Stream input: raw IQ straight from the radio source (before the AGC), at samp_rate.
Works on blocks of `block` samples:
  - block power (dBFS, full scale = 1.0), ADC clipping (|I| or |Q| >= clip)
  - noise floor = 10th percentile of block powers over the last `nf_window_s`
  - a block is "busy" when it is >= busy_db above the noise floor; runs of busy blocks are
    bursts (one JSON record per burst: start/end host time, duration, mean power, SNR)
  - spectrum of blocks >= 6 dB above the floor (and of idle blocks, for the noise) -> 99 % occupied bandwidth;
    carrier frequency offset from the spectral line of the SQUARED signal (BPSK: x^2 has a line
    at 2*CFO; peak + parabolic interpolation, about +-100 Hz), plus the power centroid
Every `interval` seconds it publishes a summary record (tap "rssi"); bursts as tap "burst".
"""
import collections
import json
import time

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.sync_block):
    def __init__(self, samp_rate=1.5e6, block=1024, interval=1.0, busy_db=3.0, clip=0.98,
                 nf_window_s=3.0, fft_every=4):
        gr.sync_block.__init__(self, name="PERF RSSI/Spectrum Probe", in_sig=[np.complex64], out_sig=None)
        self.samp_rate = float(samp_rate)
        self.block = int(block)
        self.interval = float(interval)
        self.busy_db = float(busy_db)
        self.clip = float(clip)
        self.fft_every = max(1, int(fft_every))
        self._hist = collections.deque(maxlen=max(16, int(nf_window_s * samp_rate / block)))
        self._carry = np.zeros(0, dtype=np.complex64)
        self._nf = None
        self._win = np.hanning(self.block)
        self._reset_interval(time.time())
        self._burst = None
        self._nblk = 0
        self.message_port_register_out(pmt.intern("rssi_out"))

    def _reset_interval(self, t):
        self._t_int = t
        self._acc = {"n": 0, "busy": 0, "p_busy": 0.0, "p_idle": 0.0, "n_idle": 0, "clip": 0, "samples": 0,
                     "peak": 0.0, "S_busy": np.zeros(self.block), "nb": 0, "S_idle": np.zeros(self.block), "ni": 0,
                     "S2": np.zeros(self.block)}

    def _pub(self, rec):
        data = json.dumps(rec, separators=(",", ":")).encode()
        self.message_port_pub(pmt.intern("rssi_out"), pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data))))

    @staticmethod
    def _db(p):
        return round(10 * np.log10(max(p, 1e-15)), 2)

    def _summary(self, t):
        a = self._acc
        rec = {"tap": "rssi", "t": t, "blocks": a["n"], "busy_pct": round(100 * a["busy"] / max(a["n"], 1), 2),
               "nf_dbfs": self._db(self._nf) if self._nf else None,
               "sig_dbfs": self._db(a["p_busy"] / a["busy"]) if a["busy"] else None,
               "clip_pct": round(100 * a["clip"] / max(a["samples"], 1), 4),
               "peak_dbfs": self._db(a["peak"])}
        if a["busy"] and self._nf:
            ps = a["p_busy"] / a["busy"]
            rec["snr_db"] = self._db(max(ps - self._nf, 1e-15) / self._nf)
        if a["nb"]:
            S = a["S_busy"] / a["nb"]
            if a["ni"]:
                S = np.maximum(S - a["S_idle"] / a["ni"], 0)
            S = np.fft.fftshift(S)
            f = np.fft.fftshift(np.fft.fftfreq(self.block, 1 / self.samp_rate))
            tot = S.sum()
            if tot > 0:
                c = np.cumsum(S) / tot
                lo = f[np.searchsorted(c, 0.005)]
                hi = f[min(np.searchsorted(c, 0.995), len(f) - 1)]
                rec["obw99_hz"] = round(float(hi - lo), 1)
                rec["cfo_centroid_hz"] = round(float((S * f).sum() / tot), 1)
            S2 = np.fft.fftshift(a["S2"])
            k = int(np.argmax(S2))
            if 0 < k < len(S2) - 1:
                y0, y1, y2 = np.log(S2[k - 1:k + 2] + 1e-30)
                den = y0 - 2 * y1 + y2
                dk = 0.5 * (y0 - y2) / den if den != 0 else 0.0
                rec["cfo_hz"] = round(float((f[k] + dk * self.samp_rate / self.block) / 2), 1)
        self._pub(rec)

    def work(self, input_items, output_items):
        x = input_items[0]
        n_in = len(x)
        t_now = time.time()
        buf = np.concatenate((self._carry, x)) if len(self._carry) else x
        L = len(buf)
        nb = L // self.block
        self._carry = buf[nb * self.block:].copy()
        if nb:
            blocks = buf[:nb * self.block].reshape(nb, self.block)
            p = np.mean(np.abs(blocks) ** 2, axis=1)
            mx = np.max(np.maximum(np.abs(blocks.real), np.abs(blocks.imag)), axis=1)
            clips = np.sum((np.abs(blocks.real) >= self.clip) | (np.abs(blocks.imag) >= self.clip), axis=1)
            self._hist.extend(p.tolist())
            if len(self._hist) >= 16 and (self._nblk % 64 == 0 or self._nf is None):
                self._nf = float(np.percentile(np.fromiter(self._hist, float), 10))
            nf = self._nf if self._nf else float(np.min(p))
            busy = p >= nf * 10 ** (self.busy_db / 10)
            a = self._acc
            a["n"] += nb
            a["busy"] += int(busy.sum())
            a["p_busy"] += float(p[busy].sum())
            a["clip"] += int(clips.sum())
            a["samples"] += nb * self.block
            a["peak"] = max(a["peak"], float(mx.max()) ** 2)
            for k in range(nb):
                self._nblk += 1
                if self._nblk % self.fft_every == 0:
                    S = np.abs(np.fft.fft(blocks[k] * self._win)) ** 2
                    if p[k] >= nf * 4.0:              # spectra only from blocks >= 6 dB above the floor
                        a["S_busy"] += S
                        a["nb"] += 1
                        a["S2"] += np.abs(np.fft.fft(blocks[k].astype(np.complex128) ** 2)) ** 2
                    else:
                        a["S_idle"] += S
                        a["ni"] += 1
                # host time of the end of block k (the newest sample arrived at t_now)
                tk = t_now - (L - (k + 1) * self.block) / self.samp_rate
                if busy[k]:
                    if self._burst is None:
                        self._burst = {"t0": tk - self.block / self.samp_rate, "p": 0.0, "n": 0, "clip": 0}
                    b = self._burst
                    b["p"] += float(p[k])
                    b["n"] += 1
                    b["clip"] += int(clips[k])
                    b["t1"] = tk
                elif self._burst is not None:
                    b = self._burst
                    ps = b["p"] / b["n"]
                    rec = {"tap": "burst", "t": t_now, "t0": round(b["t0"], 6), "t1": round(b["t1"], 6),
                           "dur_ms": round(1000 * (b["t1"] - b["t0"]), 2), "p_dbfs": self._db(ps),
                           "nf_dbfs": self._db(nf), "snr_db": self._db(max(ps - nf, 1e-15) / nf),
                           "clip": b["clip"]}
                    self._burst = None
                    if rec["dur_ms"] >= 1.0:
                        self._pub(rec)
        if t_now - self._t_int >= self.interval:
            self._summary(t_now)
            self._reset_interval(t_now)
        return n_in
