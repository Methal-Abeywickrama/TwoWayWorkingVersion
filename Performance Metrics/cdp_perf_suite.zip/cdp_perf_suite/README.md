# CDP transceiver — hardware performance test suite

For the **working flowgraph**: BPSK burst framer/deframer + SR-ARQ + app (folder sync / chat),
FDD on the two ANTSDRs. The adaptive-modulation and encryption builds are **not** included.

`perf_hw.grc` is your working app flowgraph with the radios on (Stage 1) plus measurement
taps. The DSP chain, the framer/deframer decoding, the SR-ARQ FSM and the header blocks are unchanged.
**Use it like your own file:** copy it to both PCs, set **MY_ID / PEER_ID** in GRC (0/1 on one, 1/0 on
the other) and press Run. Then start `python3 perf/perf_daemon.py`. No environment variables are needed.
**All commands are in COMMANDS.md.**

What is different from your file (all visible in GRC):
- Every setting is a plain GRC variable: MY_ID, PEER_ID, ADDR, PREAMBLE_LEN, POSTAMBLE_LEN, MAX_BIT_ERRORS, and the SR-ARQ values (tl_mtu, tl_rto_ms, tl_m, tl_max_retries, ...). The TL_* environment variables are gone; their old defaults are now the GRC values.
- The TX/RX frequencies follow the IDs: the lower ID transmits on TX_FREQ_A.
- **Fix for address 0.** 0 is also the broadcast address, so on the node with MY_ID 0 both PDU filters passed every packet. Its FSM received each packet twice and sent every SYN_ACK / ACK / FIN_ACK twice; in simulation, 8 ACKs for 4 DATA packets. The broadcast filter is now disabled on the node whose own address is 0, because the other filter already covers it.
- The flowgraph ID is `cdp_perf`, so GRC writes `cdp_perf.py` and never overwrites your `transeciever.py`.
- The taps (below), and the deframer's console line shortened to the payload length.

```
             perf_daemon.py  (one per PC; dashboard http://127.0.0.1:8088, log file perf_logs/*.jsonl)
               │ app PUSH :52001      │ app PULL :52002        │ link PUSH :52004        │ telemetry SUB :52003
               ▼                      ▲                        ▼                         ▲
   ┌─────────── flowgraph (perf_hw.grc) ───────────────────────────────────────────────────────────────┐
   │ ZMQ app in ─► SR-ARQ FSM ─► TX hdr serializer ─► FRAMER ◄─ ZMQ link in (raw frames, no ARQ)       │
   │                  ▲   │app_out                        │stats_out          ▲tp_tx / app_in / app_out│
   │ RX hdr parser ◄──┘   └─► ZMQ app out                 ▼                   │                        │
   │      ▲tp_rx                                    modulator ─► Pluto TX     TELEMETRY HUB ─► ZMQ PUB │
   │ DEFRAMER ◄─ bits ◄─ decoders ◄─ COSTAS ◄─ EQ ◄─ sync ◄─ FLL ◄─ AGC ◄─ Pluto RX                     │
   │   │stats_out (every sync: ok / CRC fail / bad length + raw bits)  │            │                    │
   │   └────────────► EVM/SNR PROBE (per-burst SNR) ◄──────────────────┘            └─► RSSI/SPECTRUM    │
   └────────────────────────────────────────────────────────────────────────────── PROBE (raw IQ) ────┘
```

## What gets measured

| Layer | Metrics |
|---|---|
| **Capacity (from the flowgraph parameters)** | symbol rate, raw bit rate, theoretical occupied BW (1+α)·Rs, spectral efficiency, burst overhead, air time and max throughput vs payload size, ideal ARQ goodput |
| **Physical / link** (every burst, both directions) | frames sent / detected / OK / CRC fail / bad length / never detected, **FER**, **BER** (sync + header + payload + CRC bits, exact, from the received bits of every failed burst vs the bytes that were sent), worst-case BER (lost bursts counted at 50 %), sync-word bit errors, false syncs, burst latency |
| **Error structure** (each failed burst) | **error density** (bit errors ÷ bits), error count, number and length of error bursts, adjacent-pair share (DBPSK symbol errors), where in the burst (header / payload / CRC, 20-bin position profile), first-error position |
| **Signal** | per-burst **SNR from EVM** (MER), EVM %, residual frequency after Costas; RSSI at the antenna (dBFS), noise floor, wideband SNR, **measured 99 % occupied bandwidth**, **carrier frequency offset**, ADC clipping, channel occupancy; **BER and FER vs SNR** with BPSK theory curves |
| **Link tests** (message sets, no ARQ) | per size × content pattern: FER, BER, error density mean/max, SNR, **delivered throughput** (and the max possible) → **max link bit rate** |
| **SR-ARQ** | **retransmission rate vs packet payload size**, transmissions per packet, retransmission cause (DATA lost vs ACK lost/late, needs both logs), never-ACKed packets, SYN / FIN retries, duplicate ACKs, **RTT DATA→ACK** (Karn), SYN→SYN_ACK handshake time |
| **Application** | per message size × pattern: completion rate, byte-exact verification at the receiver, completion time, **goodput** (median / max) vs ideal, channel utilisation, end-to-end latency |
| **Setup** | program start/end and every job and note at both ends with timestamps, clock offset between the PCs; a **key-parameter table for both nodes**: TX/RX frequency, sample rate, TX attenuation, RX gain mode/gain, analog bandwidth, power squelch (if any), sps, roll-off, AGC, FLL BW, **symbol-sync BW** / TED / damping / max deviation, equalizer, **Costas BW**, **preamble / postamble length**, sync-word errors, MTU, window, RTO, retries, ports. Differences between nodes are marked. **Every other parameter** (all variables, all block settings, the GRC expression of every block) follows. Automatic findings. |

## Files

| | |
|---|---|
| `COMMANDS.md` | **every command, step by step** (start here) |
| `perf_hw.grc` | the instrumented flowgraph for the ANTSDRs (same file on both PCs, set MY_ID / PEER_ID) |
| `perf_sim_node0.grc`, `perf_sim_node1.grc` | the same without radios (ZMQ IQ), for a test on one PC |
| `perf/perf_daemon.py` | the daemon: talks to every tap, runs tests, logs everything, serves the dashboard |
| `perf/perf_report.py` | builds the report from one or both PCs' logs (also from the dashboard) |
| `perf/test_sets/*.json` | message sets (link tests) and plans (sequences of tests); add your own |
| `GRC_CHANGES.md` | every change vs your file, for applying it to another .grc by hand |
| `blocks_src/` | the 5 embedded-block sources |
| `generated_*/` | what GRC generates from the three .grc files (reference; GRC regenerates on Run) |
| `sample_report/` | a report from the simulated session below (what to expect) |
| `offline_test/` | the simulation used to verify all of this (no GNU Radio or radio needed) |

Needs on each laptop: GNU Radio 3.10 with gr-iio, `python3-zmq`, `numpy`, a browser. Stop the chat app /
`folder_sync_daemon.py` while testing (same app ZMQ ports).

## Running it
See **COMMANDS.md**. Short version: on both PCs, open `perf_hw.grc` in GRC, set MY_ID / PEER_ID, press
Run, then run `python3 perf/perf_daemon.py` and open http://127.0.0.1:8088.

### Tests (dashboard "Run a test", or `perf/perf_daemon.py submit ...` from a terminal)

| Test | What it does |
|---|---|
| **Full review** (plan `full_review`) | about 6–10 min: 15 s idle baseline → link sets `standard`, `patterns`, `stress` → ARQ sweep 16 B–10 kB → ARQ content check. One click for the whole report. |
| **Link BER set** (the side program) | sends a fixed set of raw frames straight into the framer, each once, no ARQ, paced at the chosen fraction of the air rate. The receiver logs every sync detection with the raw bits of failed frames. |
| **ARQ sweep** | app messages of the given sizes × patterns × repetitions through the whole stack; waits for tx_done/tx_failed for each; the receiver verifies every byte |
| **Idle baseline** | nobody sends: noise floor and false syncs |
| **Note** | writes a note into the log (e.g. "antennas 3 m apart, CH_GAIN 10"); shows on the report timeline |

Payload patterns: `random`, `zeros`, `ones`, `alt55`, `altAA`, `text`, `ramp`. In differential BPSK a 0 bit means "no phase change". All-zero payloads therefore give the symbol-timing loop no transitions, which is a useful content stress test.

Message sets: `quick`, `standard`, `patterns`, `stress` (100 % load, the max-bit-rate test), `long_soak`,
`my_set_example` (template: copy it, edit sizes ≥ 23 B / counts / patterns, it appears in the dashboard).

### The cross-PC BER workflow
1. Both daemons running. On the sender's dashboard: **Link BER set**, pick a set, **Send set**.
   The receiver's dashboard shows frames arriving live (Frames received OK / CRC fail, live BER).
2. When it is done, on the **receiver**: *Logs and reports* → **download** its log
   (`perf_data/perf_logs/node1_<host>_<time>.jsonl`). Copy it to the sender PC (USB / scp).
3. On the **sender**: *Import peer log* → select that file → tick both logs → **Build report**.
   (Or from a terminal: `python3 perf/perf_report.py perf_data/perf_logs/node0_*.jsonl node1_*.jsonl -o myreport`.)

Every burst the sender handed to the radio is matched to what the receiver's deframer decided.
For every failed burst, the received bits are XOR-ed with the bits that were sent. That gives BER, error density, error bursts and error positions per burst.

The report aligns the two PC clocks itself, using frames in both directions the same way NTP does. Your laptops being NTP-synced (`timedatectl`) is still recorded and helps.
A single log still gives a one-sided report. The receiver-only view estimates link-test FER/BER from the test headers inside the frames.

### Report contents
`report.html` (charts with hover values and a table view, light/dark), `report.md`, `summary.json`,
`frames.csv` (every burst: status, bit errors, bits, density, error bursts, SNR, RSSI, latency),
`messages.csv` (every ARQ test message), `packets.csv` (every DATA packet: transmissions, RTT, retx cause),
`config.json` (all parameters of both flowgraphs).

## Notes and limits
- The taps add CPU in the flowgraph process (two small Python stream probes and JSON per burst), measured in simulation as a few % of one core.
- The deframer's console line is shortened in this build (`print_payload=False`: `[RX RECEIVED] #n: <200 B>` instead of printing binary payloads). Decoding is unchanged.
- Your working deframer re-scans its whole buffer on every call. In a test with 8 kB frames delivered in 512-bit chunks it used about 50 % of a core, so the `stress` set is also a CPU test of the RX path.
- dBFS assumes the Pluto source's fc32 full scale is 1.0. Compare levels within a session rather than as absolute dBm.
- SNR from EVM is decision-directed: it reads high below about 7 dB.
- OBW and CFO use only seconds when the channel was at least 20 % busy. CFO is accurate to about ±150 Hz (squared-BPSK spectral line).
- `blocks_message_debug_0/1` are still in the graph (as in your file). They print every PDU; disable them for maximum-throughput runs if the console becomes the bottleneck.
- The EVM and RSSI probe blocks can be disabled in GRC (right-click → Disable) if you ever suspect them. Everything else keeps working; you only lose the SNR / RSSI / OBW / CFO numbers.
- There is no power squelch in this flowgraph (or in the files you sent). If you add one, the report lists its settings automatically.

## How this was verified (no hardware here)
`offline_test/` runs both nodes from `generated_hw/` in one process: every embedded block (FSM, header blocks, framer/deframer with taps, hub, probes) plus both daemons. A real-time 375 kBd BPSK channel per direction drives the deframer, EVM probe and RSSI probe, and records the **true** bit errors of every burst.

Simulated session (the one in `sample_report/`): nodes with MY_ID 0 / PEER_ID 1 and 1 / 0. A→B had 417 bursts with an SNR sweep from 6 to 13 dB, plus a 13 dB stress run, ARQ at 8 dB, and messages B→A. Results:
- **All 93 failed bursts' bit-error counts equal the channel's true counts.** Overall BER equals the truth (3.67e-4).
- SNR estimates are within 0.04 dB of the set Es/N0.
- OBW is 453 kHz (RRC α = 0.35 → ~0.48 MHz). CFO is 1.32 kHz against 1.2 kHz set.
- The clock offset is recovered (2.49 s against a 2.5 s shift).
- 38 ARQ retransmissions are counted identically live and in the report, and all ARQ messages were verified byte-exact.
- Each FSM received every packet exactly once (with the address-0 fix).

The .grc files were saved and validated by GNU Radio's own GRC code and compiled with its `grcc`. The ZMQ transport and the pmt (de)serialisation are the parts this simulation cannot exercise; they follow `folder_sync_daemon.py`, which already works on your machine. Use `perf_daemon.py check` to confirm the taps on the real setup.

Run it yourself: `python3 offline_test/e2e_test.py` (about 1 min; last line `RESULT: PASS`).
The simulated nodes use MY_ID 0 / PEER_ID 1 and 1 / 0 exactly like your two PCs. The daemons are started without addresses and learn them from the flowgraph.
