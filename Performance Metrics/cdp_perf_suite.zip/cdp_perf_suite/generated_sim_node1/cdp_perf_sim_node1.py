#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: CDP transceiver - PERF SIM node 1 (no radio, ZMQ IQ)
# Author: mushab404
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
from PyQt5 import QtCore
from gnuradio import analog
from gnuradio import blocks
from gnuradio import blocks, gr
from gnuradio import channels
from gnuradio.filter import firdes
from gnuradio import digital
from gnuradio import filter
from gnuradio import gr
from gnuradio.fft import window
import sys
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import eng_notation
from gnuradio import gr, pdu
from gnuradio import pdu
import pmt
from gnuradio import zeromq
import cdp_perf_sim_node1_epy_block_0 as epy_block_0  # embedded python block
import cdp_perf_sim_node1_epy_block_0_0 as epy_block_0_0  # embedded python block
import cdp_perf_sim_node1_epy_block_0_0_0 as epy_block_0_0_0  # embedded python block
import cdp_perf_sim_node1_epy_block_1 as epy_block_1  # embedded python block
import cdp_perf_sim_node1_epy_block_2 as epy_block_2  # embedded python block
import cdp_perf_sim_node1_epy_block_6 as epy_block_6  # embedded python block
import cdp_perf_sim_node1_epy_block_7 as epy_block_7  # embedded python block
import cdp_perf_sim_node1_epy_block_8 as epy_block_8  # embedded python block
import os
import sip
import threading



class cdp_perf_sim_node1(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "CDP transceiver - PERF SIM node 1 (no radio, ZMQ IQ)", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("CDP transceiver - PERF SIM node 1 (no radio, ZMQ IQ)")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "cdp_perf_sim_node1")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.PEER_ID = PEER_ID = 0
        self.MY_ID = MY_ID = 1
        self.fdd_side = fdd_side = 'A' if MY_ID < PEER_ID else 'B'
        self.TX_FREQ_B = TX_FREQ_B = 2437e6
        self.TX_FREQ_A = TX_FREQ_A = 2412e6
        self.BPSK_CONST = BPSK_CONST = digital.constellation_rect([1+0j, -1+0j], [0, 1],
        2, 2, 1, 1, 1).base()
        self.tx_freq = tx_freq = TX_FREQ_A if fdd_side == 'A' else TX_FREQ_B
        self.tl_zmq_tx_port = tl_zmq_tx_port = 52011
        self.tl_zmq_tap_port = tl_zmq_tap_port = 52013
        self.tl_zmq_rx_port = tl_zmq_rx_port = 52012
        self.tl_zmq_link_port = tl_zmq_link_port = 52014
        self.tl_rto_ms = tl_rto_ms = 500
        self.tl_role = tl_role = 'initiator'
        self.tl_peer_addr = tl_peer_addr = PEER_ID
        self.tl_mtu = tl_mtu = 200
        self.tl_max_retries = tl_max_retries = 10
        self.tl_m = tl_m = 4
        self.tl_local_port = tl_local_port = 1
        self.tl_local_addr = tl_local_addr = MY_ID
        self.sym_bw = sym_bw = 0.020
        self.sps = sps = 4
        self.samp_rate = samp_rate = 1.5e6
        self.rx_freq = rx_freq = TX_FREQ_B if fdd_side == 'A' else TX_FREQ_A
        self.nv = nv = 0
        self.iq_tx_port = iq_tx_port = 53001 if fdd_side == 'A' else 53002
        self.iq_rx_port = iq_rx_port = 53002 if fdd_side == 'A' else 53001
        self.fll_loop_bw = fll_loop_bw = 0.01
        self.costas_bw = costas_bw = 0.02
        self.alpha = alpha = 0.35
        self.adpt_alg = adpt_alg = digital.adaptive_algorithm_cma( BPSK_CONST, .01, 4).base()
        self.SDR_CF = SDR_CF = 433e6
        self.QPSK_CONST = QPSK_CONST = digital.constellation_rect([-1-1j, -1+1j, 1+1j, 1-1j], [0, 1, 3, 2],
        4, 2, 2, 1, 1).base()
        self.PREAMBLE_LEN = PREAMBLE_LEN = 1024
        self.POSTAMBLE_LEN = POSTAMBLE_LEN = 160
        self.MAX_BIT_ERRORS = MAX_BIT_ERRORS = 1
        self.CH_GAIN = CH_GAIN = 20.0
        self.ADDR = ADDR = "ip:192.168.1.10"

        ##################################################
        # Blocks
        ##################################################

        self._nv_range = qtgui.Range(0, 1, 0.01, 0, 200)
        self._nv_win = qtgui.RangeWidget(self._nv_range, self.set_nv, "RX extra noise (nv)", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_layout.addWidget(self._nv_win)
        self.zeromq_sub_source_iq = zeromq.sub_source(gr.sizeof_gr_complex, 1, "tcp://127.0.0.1:" + str(iq_rx_port), 100, False, (-1), '', False)
        self.zeromq_push_msg_sink_0 = zeromq.push_msg_sink("tcp://127.0.0.1:" + str(tl_zmq_rx_port), 100, True)
        self.zeromq_pull_msg_source_link = zeromq.pull_msg_source("tcp://127.0.0.1:" + str(tl_zmq_link_port), 100, True)
        self.zeromq_pull_msg_source_0 = zeromq.pull_msg_source("tcp://127.0.0.1:" + str(tl_zmq_tx_port), 100, True)
        self.zeromq_pub_sink_iq = zeromq.pub_sink(gr.sizeof_gr_complex, 1, "tcp://127.0.0.1:" + str(iq_tx_port), 100, False, (-1), '', True, True)
        self.zeromq_pub_msg_sink_tap = zeromq.pub_msg_sink("tcp://127.0.0.1:" + str(tl_zmq_tap_port), 100, True)
        self.root_raised_cosine_filter_0 = filter.fir_filter_ccf(
            1,
            firdes.root_raised_cosine(
                1,
                samp_rate,
                (samp_rate/float(sps)),
                alpha,
                (11*sps+1)))
        self.qtgui_freq_sink_x_1 = qtgui.freq_sink_c(
            1024, #size
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "", #name
            1,
            None # parent
        )
        self.qtgui_freq_sink_x_1.set_update_time(0.10)
        self.qtgui_freq_sink_x_1.set_y_axis((-140), 10)
        self.qtgui_freq_sink_x_1.set_y_label('Relative Gain', 'dB')
        self.qtgui_freq_sink_x_1.set_trigger_mode(qtgui.TRIG_MODE_FREE, 0.0, 0, "")
        self.qtgui_freq_sink_x_1.enable_autoscale(False)
        self.qtgui_freq_sink_x_1.enable_grid(False)
        self.qtgui_freq_sink_x_1.set_fft_average(1.0)
        self.qtgui_freq_sink_x_1.enable_axis_labels(True)
        self.qtgui_freq_sink_x_1.enable_control_panel(False)
        self.qtgui_freq_sink_x_1.set_fft_window_normalized(False)



        labels = ['', '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.qtgui_freq_sink_x_1.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_freq_sink_x_1.set_line_label(i, labels[i])
            self.qtgui_freq_sink_x_1.set_line_width(i, widths[i])
            self.qtgui_freq_sink_x_1.set_line_color(i, colors[i])
            self.qtgui_freq_sink_x_1.set_line_alpha(i, alphas[i])

        self._qtgui_freq_sink_x_1_win = sip.wrapinstance(self.qtgui_freq_sink_x_1.qwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_freq_sink_x_1_win)
        self.qtgui_const_sink_x_1 = qtgui.const_sink_c(
            1024, #size
            "", #name
            1, #number of inputs
            None # parent
        )
        self.qtgui_const_sink_x_1.set_update_time(0.10)
        self.qtgui_const_sink_x_1.set_y_axis((-2), 2)
        self.qtgui_const_sink_x_1.set_x_axis((-2), 2)
        self.qtgui_const_sink_x_1.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_1.enable_autoscale(False)
        self.qtgui_const_sink_x_1.enable_grid(False)
        self.qtgui_const_sink_x_1.enable_axis_labels(True)


        labels = ['', '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_1.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_1.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_1.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_1.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_1.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_1.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_1.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_1_win = sip.wrapinstance(self.qtgui_const_sink_x_1.qwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_const_sink_x_1_win)
        self.qtgui_const_sink_x_0 = qtgui.const_sink_c(
            1024, #size
            "", #name
            1, #number of inputs
            None # parent
        )
        self.qtgui_const_sink_x_0.set_update_time(0.10)
        self.qtgui_const_sink_x_0.set_y_axis((-2), 2)
        self.qtgui_const_sink_x_0.set_x_axis((-2), 2)
        self.qtgui_const_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_0.enable_autoscale(False)
        self.qtgui_const_sink_x_0.enable_grid(False)
        self.qtgui_const_sink_x_0.enable_axis_labels(True)


        labels = ['', '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_0_win = sip.wrapinstance(self.qtgui_const_sink_x_0.qwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_const_sink_x_0_win)
        self.pdu_pdu_to_tagged_stream_0_0 = pdu.pdu_to_tagged_stream(gr.types.byte_t, 'packet_len')
        self.pdu_pdu_filter_0_0 = pdu.pdu_filter(pmt.intern("dst_addr"), pmt.from_uint64(0 if MY_ID != 0 else 255), False)
        self.pdu_pdu_filter_0 = pdu.pdu_filter(pmt.intern("dst_addr"), pmt.from_uint64(tl_local_addr), False)
        self.epy_block_8 = epy_block_8.blk(samp_rate=samp_rate, block=1024, interval=1.0, busy_db=3.0, clip=0.98, nf_window_s=3.0, fft_every=4)
        self.epy_block_7 = epy_block_7.blk(sym_rate=samp_rate/sps, ring_syms=2097152, pre_syms=1024)
        self.epy_block_6 = epy_block_6.blk(node_addr=tl_local_addr, config={'grc_blocks': {'BPSK_CONST': {'id': 'variable_constellation_rect', 'const_points': '[1+0j, -1+0j]', 'imag_sect': '1', 'precision': '8', 'real_sect': '2', 'rot_sym': '2', 'soft_dec_lut': 'None', 'sym_map': '[0, 1]', 'w_imag_sect': '1', 'w_real_sect': '1'}, 'QPSK_CONST': {'id': 'variable_constellation_rect', 'const_points': '[-1-1j, -1+1j, 1+1j, 1-1j]', 'imag_sect': '2', 'precision': '8', 'real_sect': '2', 'rot_sym': '4', 'soft_dec_lut': 'None', 'sym_map': '[0, 1, 3, 2]', 'w_imag_sect': '1', 'w_real_sect': '1'}, 'adpt_alg': {'id': 'variable_adaptive_algorithm', 'cons': 'BPSK_CONST', 'delta': '10.0', 'ffactor': '0.99', 'modulus': '4', 'step_size': '.01', 'type': 'cma'}, 'analog_agc_xx_0': {'id': 'analog_agc_xx', 'gain': '1.0', 'max_gain': '1000', 'rate': '1e-3', 'reference': '1.0', 'type': 'complex'}, 'blocks_copy_0_0': {'id': 'blocks_copy', 'enabled': 'True', 'showports': 'False', 'type': 'byte', 'vlen': '1'}, 'blocks_copy_1_1': {'id': 'blocks_copy', 'enabled': 'True', 'showports': 'False', 'type': 'complex', 'vlen': '1'}, 'blocks_copy_1_2': {'id': 'blocks_copy', 'enabled': 'True', 'showports': 'False', 'type': 'complex', 'vlen': '1'}, 'blocks_message_debug_0': {'id': 'blocks_message_debug', 'en_uvec': 'True', 'log_level': 'info'}, 'blocks_message_debug_1': {'id': 'blocks_message_debug', 'en_uvec': 'True', 'log_level': 'info'}, 'blocks_tag_gate_0_0': {'id': 'blocks_tag_gate', 'propagate_tags': 'False', 'single_key': '""', 'type': 'complex', 'vlen': '1'}, 'blocks_unpack_k_bits_bb_0_0': {'id': 'blocks_unpack_k_bits_bb', 'k': '1'}, 'channels_channel_model_0': {'id': 'channels_channel_model', 'block_tags': 'False', 'epsilon': '1.0', 'freq_offset': '0.0', 'noise_voltage': 'nv', 'seed': '0', 'taps': '1.0'}, 'digital_constellation_decoder_cb_0_0': {'id': 'digital_constellation_decoder_cb', 'constellation': 'BPSK_CONST'}, 'digital_constellation_modulator_0_0_0': {'id': 'digital_constellation_modulator', 'constellation': 'BPSK_CONST', 'differential': 'True', 'excess_bw': 'alpha', 'log': 'False', 'samples_per_symbol': 'sps', 'truncate': 'False', 'verbose': 'False'}, 'digital_costas_loop_cc_0': {'id': 'digital_costas_loop_cc', 'order': 'BPSK_CONST.arity()', 'use_snr': 'False', 'w': 'costas_bw'}, 'digital_diff_decoder_bb_0_0': {'id': 'digital_diff_decoder_bb', 'coding': 'digital.DIFF_DIFFERENTIAL', 'modulus': '2'}, 'digital_fll_band_edge_cc_0': {'id': 'digital_fll_band_edge_cc', 'filter_size': '11* sps +1', 'rolloff': 'alpha', 'samps_per_sym': 'sps', 'type': 'cc', 'w': 'fll_loop_bw'}, 'digital_linear_equalizer_0': {'id': 'digital_linear_equalizer', 'adapt_after_training': 'True', 'alg': 'adpt_alg', 'num_taps': '15', 'sps': '2', 'training_sequence': '[]', 'training_start_tag': '""'}, 'digital_symbol_sync_xx_0': {'id': 'digital_symbol_sync_xx', 'constellation': 'digital.constellation_bpsk().base()', 'damping': '1.0', 'loop_bw': 'sym_bw', 'max_dev': '0.05', 'nfilters': '128', 'osps': '2', 'pfb_mf_taps': '[]', 'resamp_type': 'digital.IR_MMSE_8TAP', 'sps': 'sps', 'ted_gain': '1.0', 'ted_type': 'digital.TED_SIGNAL_TIMES_SLOPE_ML', 'type': 'cc'}, 'iio_pluto_sink_0_0': {'id': 'iio_pluto_sink', 'attenuation1': 'CH_GAIN', 'bandwidth': 'int(1.5e6)', 'buffer_size': '4096', 'cyclic': 'False', 'filter': '', 'filter_source': "'Auto'", 'fpass': '0', 'frequency': 'int(tx_freq)', 'fstop': '0', 'len_tag_key': '', 'samplerate': 'int(samp_rate)', 'type': 'fc32', 'uri': 'ADDR'}, 'iio_pluto_source_0': {'id': 'iio_pluto_source', 'bandwidth': 'int(1.5e6)', 'bbdc': 'True', 'buffer_size': '4096', 'filter': '', 'filter_source': "'Auto'", 'fpass': '0', 'frequency': 'int(rx_freq)', 'fstop': '0', 'gain1': "'slow_attack'", 'len_tag_key': 'packet_len', 'manual_gain1': '64', 'quadrature': 'True', 'rfdc': 'True', 'samplerate': 'int(samp_rate)', 'type': 'fc32', 'uri': 'ADDR'}, 'pdu_pdu_filter_0': {'id': 'pdu_pdu_filter', 'invert': 'False', 'k': 'pmt.intern("dst_addr")', 'v': 'pmt.from_uint64(tl_local_addr)'}, 'pdu_pdu_filter_0_0': {'id': 'pdu_pdu_filter', 'invert': 'False', 'k': 'pmt.intern("dst_addr")', 'v': 'pmt.from_uint64(0 if MY_ID != 0 else 255)'}, 'pdu_pdu_to_tagged_stream_0_0': {'id': 'pdu_pdu_to_tagged_stream', 'tag': 'packet_len', 'type': 'byte'}, 'root_raised_cosine_filter_0': {'id': 'root_raised_cosine_filter', 'decim': '1', 'gain': '1', 'interp': '1', 'ntaps': '11*sps+1', 'samp_rate': 'samp_rate', 'sym_rate': 'samp_rate/float(sps)', 'type': 'fir_filter_ccf'}, 'zeromq_pull_msg_source_0': {'id': 'zeromq_pull_msg_source', 'address': '"tcp://127.0.0.1:" + str(tl_zmq_tx_port)', 'bind': 'True', 'timeout': '100'}, 'zeromq_push_msg_sink_0': {'id': 'zeromq_push_msg_sink', 'address': '"tcp://127.0.0.1:" + str(tl_zmq_rx_port)', 'bind': 'True', 'timeout': '100'}, 'nv': {'id': 'variable_qtgui_range', 'min_len': '200', 'orient': 'QtCore.Qt.Horizontal', 'rangeType': 'float', 'start': '0', 'step': '0.01', 'stop': '1', 'value': '0', 'widget': 'counter_slider'}}}, config_interval=5.0)
        self.epy_block_2 = epy_block_2.blk()
        self.epy_block_1 = epy_block_1.blk(m=tl_m, rto_ms=tl_rto_ms, node_role=tl_role, mtu_bytes=tl_mtu, local_addr=tl_local_addr, local_port=tl_local_port, max_retries=tl_max_retries)
        self.epy_block_0_0_0 = epy_block_0_0_0.PacketDeframerRX(peer_id=MY_ID, max_bit_errors=MAX_BIT_ERRORS, max_payload_len=8192, bit_rate=375000, tap_raw_max=9000, print_payload=False)
        self.epy_block_0_0 = epy_block_0_0.PacketFramerTX(peer_id=tl_peer_addr, preamble_len=PREAMBLE_LEN, repeat_count=1, max_payload_len=8192, preamble_byte=0xFF, postamble_len=POSTAMBLE_LEN)
        self.epy_block_0 = epy_block_0.blk()
        self.digital_symbol_sync_xx_0 = digital.symbol_sync_cc(
            digital.TED_SIGNAL_TIMES_SLOPE_ML,
            sps,
            sym_bw,
            1.0,
            1.0,
            0.05,
            2,
            digital.constellation_bpsk().base(),
            digital.IR_MMSE_8TAP,
            128,
            [])
        self.digital_linear_equalizer_0 = digital.linear_equalizer(15, 2, adpt_alg, True, [], "")
        self.digital_fll_band_edge_cc_0 = digital.fll_band_edge_cc(sps, alpha, (11* sps +1), fll_loop_bw)
        self.digital_diff_decoder_bb_0_0 = digital.diff_decoder_bb(2, digital.DIFF_DIFFERENTIAL)
        self.digital_costas_loop_cc_0 = digital.costas_loop_cc(costas_bw, BPSK_CONST.arity(), False)
        self.digital_constellation_modulator_0_0_0 = digital.generic_mod(
            constellation=BPSK_CONST,
            differential=True,
            samples_per_symbol=sps,
            pre_diff_code=True,
            excess_bw=alpha,
            verbose=False,
            log=False,
            truncate=False)
        self.digital_constellation_decoder_cb_0_0 = digital.constellation_decoder_cb(BPSK_CONST)
        self.channels_channel_model_0 = channels.channel_model(
            noise_voltage=nv,
            frequency_offset=0.0,
            epsilon=1.0,
            taps=[1.0],
            noise_seed=0,
            block_tags=False)
        self.blocks_unpack_k_bits_bb_0_0 = blocks.unpack_k_bits_bb(1)
        self.blocks_tag_gate_0_0 = blocks.tag_gate(gr.sizeof_gr_complex * 1, False)
        self.blocks_tag_gate_0_0.set_single_key("")
        self.blocks_message_debug_1 = blocks.message_debug(True, gr.log_levels.info)
        self.blocks_message_debug_0 = blocks.message_debug(True, gr.log_levels.info)
        self.blocks_copy_1_2 = blocks.copy(gr.sizeof_gr_complex*1)
        self.blocks_copy_1_2.set_enabled(True)
        self.blocks_copy_1_1 = blocks.copy(gr.sizeof_gr_complex*1)
        self.blocks_copy_1_1.set_enabled(True)
        self.blocks_copy_0_0 = blocks.copy(gr.sizeof_char*1)
        self.blocks_copy_0_0.set_enabled(True)
        self.analog_agc_xx_0 = analog.agc_cc((1e-3), 1.0, 1.0, 1000)


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self.epy_block_0, 'pdus'), (self.epy_block_6, 'tp_rx'))
        self.msg_connect((self.epy_block_0, 'pdus'), (self.pdu_pdu_filter_0, 'pdus'))
        self.msg_connect((self.epy_block_0, 'pdus'), (self.pdu_pdu_filter_0_0, 'pdus'))
        self.msg_connect((self.epy_block_0_0, 'stats_out'), (self.epy_block_6, 'link_tx'))
        self.msg_connect((self.epy_block_0_0, 'pdu_out'), (self.pdu_pdu_to_tagged_stream_0_0, 'pdus'))
        self.msg_connect((self.epy_block_0_0_0, 'pdu_out'), (self.blocks_message_debug_0, 'print_pdu'))
        self.msg_connect((self.epy_block_0_0_0, 'pdu_out'), (self.epy_block_0, 'pdus'))
        self.msg_connect((self.epy_block_0_0_0, 'stats_out'), (self.epy_block_6, 'link_rx'))
        self.msg_connect((self.epy_block_0_0_0, 'stats_out'), (self.epy_block_7, 'frames'))
        self.msg_connect((self.epy_block_1, 'pdu_out'), (self.epy_block_2, 'pdus'))
        self.msg_connect((self.epy_block_1, 'pdu_out'), (self.epy_block_6, 'tp_tx'))
        self.msg_connect((self.epy_block_1, 'app_out'), (self.epy_block_6, 'app_out'))
        self.msg_connect((self.epy_block_1, 'app_out'), (self.zeromq_push_msg_sink_0, 'in'))
        self.msg_connect((self.epy_block_2, 'pdus'), (self.blocks_message_debug_1, 'print_pdu'))
        self.msg_connect((self.epy_block_2, 'pdus'), (self.epy_block_0_0, 'msg_in'))
        self.msg_connect((self.epy_block_6, 'out'), (self.zeromq_pub_msg_sink_tap, 'in'))
        self.msg_connect((self.epy_block_7, 'evm_out'), (self.epy_block_6, 'evm'))
        self.msg_connect((self.epy_block_8, 'rssi_out'), (self.epy_block_6, 'rssi'))
        self.msg_connect((self.pdu_pdu_filter_0, 'pdus'), (self.epy_block_1, 'pdu_in'))
        self.msg_connect((self.pdu_pdu_filter_0_0, 'pdus'), (self.epy_block_1, 'pdu_in'))
        self.msg_connect((self.zeromq_pull_msg_source_0, 'out'), (self.blocks_message_debug_0, 'print_pdu'))
        self.msg_connect((self.zeromq_pull_msg_source_0, 'out'), (self.epy_block_1, 'app_in'))
        self.msg_connect((self.zeromq_pull_msg_source_0, 'out'), (self.epy_block_6, 'app_in'))
        self.msg_connect((self.zeromq_pull_msg_source_link, 'out'), (self.epy_block_0_0, 'msg_in'))
        self.connect((self.analog_agc_xx_0, 0), (self.channels_channel_model_0, 0))
        self.connect((self.blocks_copy_0_0, 0), (self.digital_constellation_modulator_0_0_0, 0))
        self.connect((self.blocks_copy_1_1, 0), (self.analog_agc_xx_0, 0))
        self.connect((self.blocks_copy_1_1, 0), (self.epy_block_8, 0))
        self.connect((self.blocks_copy_1_2, 0), (self.root_raised_cosine_filter_0, 0))
        self.connect((self.blocks_tag_gate_0_0, 0), (self.zeromq_pub_sink_iq, 0))
        self.connect((self.blocks_unpack_k_bits_bb_0_0, 0), (self.epy_block_0_0_0, 0))
        self.connect((self.channels_channel_model_0, 0), (self.digital_fll_band_edge_cc_0, 0))
        self.connect((self.digital_constellation_decoder_cb_0_0, 0), (self.digital_diff_decoder_bb_0_0, 0))
        self.connect((self.digital_constellation_modulator_0_0_0, 0), (self.blocks_tag_gate_0_0, 0))
        self.connect((self.digital_costas_loop_cc_0, 0), (self.digital_constellation_decoder_cb_0_0, 0))
        self.connect((self.digital_costas_loop_cc_0, 0), (self.epy_block_7, 0))
        self.connect((self.digital_costas_loop_cc_0, 0), (self.qtgui_const_sink_x_0, 0))
        self.connect((self.digital_costas_loop_cc_0, 0), (self.qtgui_const_sink_x_1, 0))
        self.connect((self.digital_costas_loop_cc_0, 0), (self.qtgui_freq_sink_x_1, 0))
        self.connect((self.digital_diff_decoder_bb_0_0, 0), (self.blocks_unpack_k_bits_bb_0_0, 0))
        self.connect((self.digital_fll_band_edge_cc_0, 0), (self.blocks_copy_1_2, 0))
        self.connect((self.digital_linear_equalizer_0, 0), (self.digital_costas_loop_cc_0, 0))
        self.connect((self.digital_symbol_sync_xx_0, 0), (self.digital_linear_equalizer_0, 0))
        self.connect((self.pdu_pdu_to_tagged_stream_0_0, 0), (self.blocks_copy_0_0, 0))
        self.connect((self.root_raised_cosine_filter_0, 0), (self.digital_symbol_sync_xx_0, 0))
        self.connect((self.zeromq_sub_source_iq, 0), (self.blocks_copy_1_1, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "cdp_perf_sim_node1")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_PEER_ID(self):
        return self.PEER_ID

    def set_PEER_ID(self, PEER_ID):
        self.PEER_ID = PEER_ID
        self.set_fdd_side('A' if self.MY_ID < self.PEER_ID else 'B')
        self.set_tl_peer_addr(self.PEER_ID)

    def get_MY_ID(self):
        return self.MY_ID

    def set_MY_ID(self, MY_ID):
        self.MY_ID = MY_ID
        self.set_fdd_side('A' if self.MY_ID < self.PEER_ID else 'B')
        self.set_tl_local_addr(self.MY_ID)
        self.epy_block_0_0_0.peer_id = self.MY_ID
        self.pdu_pdu_filter_0_0.set_val(pmt.from_uint64(0 if self.MY_ID != 0 else 255))

    def get_fdd_side(self):
        return self.fdd_side

    def set_fdd_side(self, fdd_side):
        self.fdd_side = fdd_side
        self.set_iq_rx_port(53002 if self.fdd_side == 'A' else 53001)
        self.set_iq_tx_port(53001 if self.fdd_side == 'A' else 53002)
        self.set_rx_freq(self.TX_FREQ_B if self.fdd_side == 'A' else self.TX_FREQ_A)
        self.set_tx_freq(self.TX_FREQ_A if self.fdd_side == 'A' else self.TX_FREQ_B)

    def get_TX_FREQ_B(self):
        return self.TX_FREQ_B

    def set_TX_FREQ_B(self, TX_FREQ_B):
        self.TX_FREQ_B = TX_FREQ_B
        self.set_rx_freq(self.TX_FREQ_B if self.fdd_side == 'A' else self.TX_FREQ_A)
        self.set_tx_freq(self.TX_FREQ_A if self.fdd_side == 'A' else self.TX_FREQ_B)

    def get_TX_FREQ_A(self):
        return self.TX_FREQ_A

    def set_TX_FREQ_A(self, TX_FREQ_A):
        self.TX_FREQ_A = TX_FREQ_A
        self.set_rx_freq(self.TX_FREQ_B if self.fdd_side == 'A' else self.TX_FREQ_A)
        self.set_tx_freq(self.TX_FREQ_A if self.fdd_side == 'A' else self.TX_FREQ_B)

    def get_BPSK_CONST(self):
        return self.BPSK_CONST

    def set_BPSK_CONST(self, BPSK_CONST):
        self.BPSK_CONST = BPSK_CONST
        self.digital_constellation_decoder_cb_0_0.set_constellation(self.BPSK_CONST)

    def get_tx_freq(self):
        return self.tx_freq

    def set_tx_freq(self, tx_freq):
        self.tx_freq = tx_freq

    def get_tl_zmq_tx_port(self):
        return self.tl_zmq_tx_port

    def set_tl_zmq_tx_port(self, tl_zmq_tx_port):
        self.tl_zmq_tx_port = tl_zmq_tx_port

    def get_tl_zmq_tap_port(self):
        return self.tl_zmq_tap_port

    def set_tl_zmq_tap_port(self, tl_zmq_tap_port):
        self.tl_zmq_tap_port = tl_zmq_tap_port

    def get_tl_zmq_rx_port(self):
        return self.tl_zmq_rx_port

    def set_tl_zmq_rx_port(self, tl_zmq_rx_port):
        self.tl_zmq_rx_port = tl_zmq_rx_port

    def get_tl_zmq_link_port(self):
        return self.tl_zmq_link_port

    def set_tl_zmq_link_port(self, tl_zmq_link_port):
        self.tl_zmq_link_port = tl_zmq_link_port

    def get_tl_rto_ms(self):
        return self.tl_rto_ms

    def set_tl_rto_ms(self, tl_rto_ms):
        self.tl_rto_ms = tl_rto_ms

    def get_tl_role(self):
        return self.tl_role

    def set_tl_role(self, tl_role):
        self.tl_role = tl_role

    def get_tl_peer_addr(self):
        return self.tl_peer_addr

    def set_tl_peer_addr(self, tl_peer_addr):
        self.tl_peer_addr = tl_peer_addr
        self.epy_block_0_0.peer_id = self.tl_peer_addr

    def get_tl_mtu(self):
        return self.tl_mtu

    def set_tl_mtu(self, tl_mtu):
        self.tl_mtu = tl_mtu

    def get_tl_max_retries(self):
        return self.tl_max_retries

    def set_tl_max_retries(self, tl_max_retries):
        self.tl_max_retries = tl_max_retries
        self.epy_block_1.max_retries = self.tl_max_retries

    def get_tl_m(self):
        return self.tl_m

    def set_tl_m(self, tl_m):
        self.tl_m = tl_m
        self.epy_block_1.m = self.tl_m

    def get_tl_local_port(self):
        return self.tl_local_port

    def set_tl_local_port(self, tl_local_port):
        self.tl_local_port = tl_local_port
        self.epy_block_1.local_port = self.tl_local_port

    def get_tl_local_addr(self):
        return self.tl_local_addr

    def set_tl_local_addr(self, tl_local_addr):
        self.tl_local_addr = tl_local_addr
        self.epy_block_1.local_addr = self.tl_local_addr
        self.epy_block_6.node_addr = self.tl_local_addr
        self.pdu_pdu_filter_0.set_val(pmt.from_uint64(self.tl_local_addr))

    def get_sym_bw(self):
        return self.sym_bw

    def set_sym_bw(self, sym_bw):
        self.sym_bw = sym_bw
        self.digital_symbol_sync_xx_0.set_loop_bandwidth(self.sym_bw)

    def get_sps(self):
        return self.sps

    def set_sps(self, sps):
        self.sps = sps
        self.digital_symbol_sync_xx_0.set_sps(self.sps)
        self.epy_block_7.sym_rate = self.samp_rate/self.sps
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.samp_rate, (self.samp_rate/float(self.sps)), self.alpha, (11*self.sps+1)))

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.epy_block_7.sym_rate = self.samp_rate/self.sps
        self.epy_block_8.samp_rate = self.samp_rate
        self.qtgui_freq_sink_x_1.set_frequency_range(0, self.samp_rate)
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.samp_rate, (self.samp_rate/float(self.sps)), self.alpha, (11*self.sps+1)))

    def get_rx_freq(self):
        return self.rx_freq

    def set_rx_freq(self, rx_freq):
        self.rx_freq = rx_freq

    def get_nv(self):
        return self.nv

    def set_nv(self, nv):
        self.nv = nv
        self.channels_channel_model_0.set_noise_voltage(self.nv)

    def get_iq_tx_port(self):
        return self.iq_tx_port

    def set_iq_tx_port(self, iq_tx_port):
        self.iq_tx_port = iq_tx_port

    def get_iq_rx_port(self):
        return self.iq_rx_port

    def set_iq_rx_port(self, iq_rx_port):
        self.iq_rx_port = iq_rx_port

    def get_fll_loop_bw(self):
        return self.fll_loop_bw

    def set_fll_loop_bw(self, fll_loop_bw):
        self.fll_loop_bw = fll_loop_bw
        self.digital_fll_band_edge_cc_0.set_loop_bandwidth(self.fll_loop_bw)

    def get_costas_bw(self):
        return self.costas_bw

    def set_costas_bw(self, costas_bw):
        self.costas_bw = costas_bw
        self.digital_costas_loop_cc_0.set_loop_bandwidth(self.costas_bw)

    def get_alpha(self):
        return self.alpha

    def set_alpha(self, alpha):
        self.alpha = alpha
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.samp_rate, (self.samp_rate/float(self.sps)), self.alpha, (11*self.sps+1)))

    def get_adpt_alg(self):
        return self.adpt_alg

    def set_adpt_alg(self, adpt_alg):
        self.adpt_alg = adpt_alg

    def get_SDR_CF(self):
        return self.SDR_CF

    def set_SDR_CF(self, SDR_CF):
        self.SDR_CF = SDR_CF

    def get_QPSK_CONST(self):
        return self.QPSK_CONST

    def set_QPSK_CONST(self, QPSK_CONST):
        self.QPSK_CONST = QPSK_CONST

    def get_PREAMBLE_LEN(self):
        return self.PREAMBLE_LEN

    def set_PREAMBLE_LEN(self, PREAMBLE_LEN):
        self.PREAMBLE_LEN = PREAMBLE_LEN
        self.epy_block_0_0.preamble_len = self.PREAMBLE_LEN

    def get_POSTAMBLE_LEN(self):
        return self.POSTAMBLE_LEN

    def set_POSTAMBLE_LEN(self, POSTAMBLE_LEN):
        self.POSTAMBLE_LEN = POSTAMBLE_LEN
        self.epy_block_0_0.postamble_len = self.POSTAMBLE_LEN

    def get_MAX_BIT_ERRORS(self):
        return self.MAX_BIT_ERRORS

    def set_MAX_BIT_ERRORS(self, MAX_BIT_ERRORS):
        self.MAX_BIT_ERRORS = MAX_BIT_ERRORS
        self.epy_block_0_0_0.max_bit_errors = self.MAX_BIT_ERRORS

    def get_CH_GAIN(self):
        return self.CH_GAIN

    def set_CH_GAIN(self, CH_GAIN):
        self.CH_GAIN = CH_GAIN

    def get_ADDR(self):
        return self.ADDR

    def set_ADDR(self, ADDR):
        self.ADDR = ADDR




def main(top_block_cls=cdp_perf_sim_node1, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
