# CDP transceiver — simulated session (sample)

2 log(s), nodes 0, 1 · generated 2026-10-08 23:44:07.767 · 542 bursts, 12 ARQ messages

## Summary

Headline numbers; every number below is broken down further in its section.

- **PHY bit rate (air):** 375.0 kb/s (1.5 MS/s ÷ 4 sps, BPSK)
- **Max link throughput measured:** 290.6 kb/s (4096 B frames, load 1.0, 0 → 1)
- **Max app goodput (SR-ARQ):** 33.35 kb/s (2000 B message)
- **BER 0 → 1:** 3.67e-04 (606 errors / 1,652,016 bits)
- **Frame error rate 0 → 1:** 22.78 % (93 failed + 2 lost of 417)
- **BER 1 → 0:** 0 (0 errors / 50,296 bits)
- **Frame error rate 1 → 0:** 0.00 % (0 failed + 0 lost of 125)
- **Retransmission rate:** 41.8 % (38 retx / 91 DATA packets)
- **SNR from EVM (median):** 9.9 dB (p10 7.8 · p90 12.1 dB)
- **Occupied bandwidth:** 453 kHz (theory (1+α)·Rs = 506 kHz)
- **DATA→ACK round trip (median):** 157 ms (p95 273 ms)
- **ARQ messages completed:** 12 / 12 (12 verified byte-exact at the receiver)


## Test setup

Who logged what, and how the two clocks were aligned.

| Node | Host | Log | Program start | Program end | NTP synced | Clock offset vs ref |
|---|---|---|---|---|---|---|
| 0 | vm | node0_vm_20261008-234249.jsonl | 2026-10-08 23:42:49.614 | 2026-10-08 23:43:43.446 |  | 0.0 ms |
| 1 | vm | node1_vm_20261008-234249.jsonl | 2026-10-08 23:42:49.793 | 2026-10-08 23:43:43.446 |  | -8.3 ms |


### Key radio, modem and protocol parameters

| Group | Parameter | Node 0 | Node 1 | Differs |
|---|---|---|---|---|
| Node | MY_ID / PEER_ID | 0 / 1 | 1 / 0 |  |
| Radio | SDR URI | ip:192.168.1.10 | ip:192.168.1.10 |  |
| Radio | TX frequency | 2.412 GHz | 2.437 GHz |  |
| Radio | RX frequency | 2.437 GHz | 2.412 GHz |  |
| Radio | Sample rate | 1.5 MS/s | 1.5 MS/s |  |
| Radio | TX attenuation (CH_GAIN) | 20.0 dB | 20.0 dB |  |
| Radio | TX / RX analog bandwidth | 1500000 (int(1.5e6)) / 1500000 (int(1.5e6)) | 1500000 (int(1.5e6)) / 1500000 (int(1.5e6)) |  |
| Radio | RX gain mode / manual gain | slow_attack / 64 dB | slow_attack / 64 dB |  |
| Radio | Pluto buffer (TX / RX) | 4096 / 4096 samples | 4096 / 4096 samples |  |
| Radio | Power squelch | none in this flowgraph | none in this flowgraph |  |
| Modem | Modulation | BPSK, differential | BPSK, differential |  |
| Modem | Samples / symbol (sps) | 4 | 4 |  |
| Modem | Symbol rate | 375 kBd | 375 kBd |  |
| Modem | RRC roll-off (alpha) | 0.35 | 0.35 |  |
| Modem | RX RRC taps | 45 (11*sps+1) | 45 (11*sps+1) |  |
| RX loops | AGC rate / reference / max gain | 1e-3 / 1.0 / 1000 | 1e-3 / 1.0 / 1000 |  |
| RX loops | FLL band-edge loop BW (fll_loop_bw) | 0.01 | 0.01 |  |
| RX loops | FLL filter size | 45 (11* sps +1) | 45 (11* sps +1) |  |
| RX loops | Symbol sync loop BW (sym_bw) | 0.02 | 0.02 |  |
| RX loops | Symbol sync TED / damping / TED gain | digital.TED_SIGNAL_TIMES_SLOPE_ML / 1.0 / 1.0 | digital.TED_SIGNAL_TIMES_SLOPE_ML / 1.0 / 1.0 |  |
| RX loops | Symbol sync max deviation / out sps / filters | 0.05 / 2 / 128 | 0.05 / 2 / 128 |  |
| RX loops | Equalizer taps / sps | 15 / 2 | 15 / 2 |  |
| RX loops | Equalizer algorithm | cons=BPSK_CONST, delta=10.0, ffactor=0.99, modulus=4, step_size=.01, type=cma | cons=BPSK_CONST, delta=10.0, ffactor=0.99, modulus=4, step_size=.01, type=cma |  |
| RX loops | Costas loop BW (costas_bw) / order | 0.02 / 2 (BPSK) | 0.02 / 2 (BPSK) |  |
| RX test | Added noise (nv slider) | 0 | 0 |  |
| Framing | Preamble length | 1024 B of 0xFF | 1024 B of 0xFF |  |
| Framing | Postamble length | 160 B | 160 B |  |
| Framing | Sync word / max sync bit errors | 0x1ACFFC1D / 1 | 0x1ACFFC1D / 1 |  |
| Framing | Max payload (framer / deframer) | 8192 / 8192 B | 8192 / 8192 B |  |
| Framing | Burst repeats | 1 | 1 |  |
| Framing | Header / CRC | 6 B (len, dest, msg_id, rep, n_reps) / CRC32 | 6 B (len, dest, msg_id, rep, n_reps) / CRC32 |  |
| SR-ARQ | MTU (bytes per DATA packet) | 200 | 200 |  |
| SR-ARQ | Sequence bits m / window | 4 / 8 | 4 / 8 |  |
| SR-ARQ | RTO / max retries | 500 ms / 10 | 500 ms / 10 |  |
| SR-ARQ | Local port / role | 1 / initiator | 1 / initiator |  |
| Ports | ZMQ app in / out / telemetry / link | 52001 / 52002 / 52003 / 52004 | 52001 / 52002 / 52003 / 52004 |  |

Clock alignment: two-way (like NTP), from the earliest-arriving 10 % of frames each way. Estimated one-way receive pipeline delay (framer → deframer minus air time): 1.7 ms.

| Job | Node | Type | Set / plan | Start | Duration | Status | Result |
|---|---|---|---|---|---|---|---|
| 0-1 | 0 | mark |  | 2026-10-08 23:42:50.200 | 0.0 s | done | {"text": "e2e start, antennas 1 m"} |
| 0-2 | 0 | idle |  | 2026-10-08 23:42:50.400 | 3.0 s | done | {"duration_s": 3.0} |
| 0-3 | 0 | link |  | 2026-10-08 23:42:53.404 | 4.7 s | done | {"sent": 72, "refused": 0, "frames": 72, "load": 0.8} |
| 0-4 | 0 | link |  | 2026-10-08 23:42:58.212 | 2.0 s | done | {"sent": 25, "refused": 0, "frames": 25, "load": 0.9} |
| 0-5 | 0 | link |  | 2026-10-08 23:43:00.414 | 2.0 s | done | {"sent": 25, "refused": 0, "frames": 25, "load": 0.9} |
| 0-6 | 0 | link |  | 2026-10-08 23:43:02.621 | 2.0 s | done | {"sent": 25, "refused": 0, "frames": 25, "load": 0.9} |
| 0-7 | 0 | link |  | 2026-10-08 23:43:04.823 | 2.0 s | done | {"sent": 25, "refused": 0, "frames": 25, "load": 0.9} |
| 0-8 | 0 | link |  | 2026-10-08 23:43:07.025 | 2.0 s | done | {"sent": 25, "refused": 0, "frames": 25, "load": 0.9} |
| 0-9 | 0 | link |  | 2026-10-08 23:43:09.228 | 2.0 s | done | {"sent": 25, "refused": 0, "frames": 25, "load": 0.9} |
| 0-10 | 0 | link |  | 2026-10-08 23:43:11.430 | 2.0 s | done | {"sent": 25, "refused": 0, "frames": 25, "load": 0.9} |
| 0-11 | 0 | link |  | 2026-10-08 23:43:13.637 | 2.9 s | done | {"sent": 15, "refused": 0, "frames": 15, "load": 1.0} |
| 0-12 | 0 | arq |  | 2026-10-08 23:43:16.643 | 14.2 s | done | {"tx_done": 10} |
| 1-1 | 1 | arq |  | 2026-10-08 23:43:30.854 | 1.3 s | done | {"tx_done": 2} |
| 0-13 | 0 | mark |  | 2026-10-08 23:43:32.257 | 0.0 s | done | {"text": "e2e end"} |


## Theoretical capacity of this configuration

What the flowgraph parameters allow at best. The fixed per-burst overhead (preamble, sync, header, CRC, postamble) sets the ceiling for short frames.

- **Symbol rate:** 375.0 kBd (samp_rate 1.5 MS/s, sps 4)
- **Raw bit rate:** 375.0 kb/s (BPSK, 1 bit/symbol)
- **Occupied bandwidth (theory):** 506 kHz (RRC α = 0.35)
- **Spectral efficiency:** 0.74 b/s/Hz (raw bits per Hz)
- **Overhead per burst:** 1,198 B (preamble 1024 B + postamble 160 B + 14 B)
- **Burst air time, 200 B:** 29.8 ms (1,398 B on air)

| Payload (B) | Burst air time (ms) | Max link throughput (kb/s) | Air efficiency | ARQ packets (MTU 200) | ARQ ideal goodput (kb/s) |
|---|---|---|---|---|---|
| 16 | 25.9 | 4.9 | 1.3 % | 1 | 0.82 |
| 32 | 26.2 | 9.8 | 2.6 % | 1 | 1.63 |
| 64 | 26.9 | 19.0 | 5.1 % | 1 | 3.24 |
| 128 | 28.3 | 36.2 | 9.7 % | 1 | 6.43 |
| 200 | 29.8 | 53.6 | 14.3 % | 2 | 8.57 |
| 256 | 31.0 | 66.0 | 17.6 % | 2 | 10.90 |
| 512 | 36.5 | 112.3 | 29.9 % | 3 | 18.68 |
| 1024 | 47.4 | 172.8 | 46.1 % | 6 | 26.59 |
| 2048 | 69.2 | 236.6 | 63.1 % | 11 | 35.65 |
| 4096 | 112.9 | 290.1 | 77.4 % | 21 | 42.96 |
| 8192 | 200.3 | 327.2 | 87.2 % | 42 | 46.98 |


## Physical layer: every burst, every direction

Each burst handed to the modulator is matched to what the other node's deframer decided. ok = CRC passed; crc_fail = sync found, CRC wrong; bad_len = sync found, header length impossible; lost = no sync detected while the receiver was logging. BER counts sync-word + header + payload + CRC bits of detected bursts; 'worst case' also counts lost bursts at 50 %.

| Direction | Sent | Observed | OK | CRC fail | Bad len | Lost | FER | BER | BER worst | Mean err. density (failed) | SNR med (dB) | Sync-word bit errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 → 1 | 417 | 417 | 322 | 93 | 0 | 2 | 22.78 % | 3.67e-04 | 1.49e-03 | 2.20e-03 | 8.1 | 0 |
| 1 → 0 | 125 | 125 | 125 | 0 | 0 | 0 | 0.00 % | 0 | 0 | – | 10.0 | 0 |

| Direction | False syncs (noise) | Re-syncs inside a failed frame | Good frames from unknown sender |
|---|---|---|---|
| 0 → 1 | 0 | 0 | 0 |
| 1 → 0 | 1 | 0 | 0 |

| SNR bin (dB) | Bursts | Failed | Bits | Bit errors | BER |
|---|---|---|---|---|---|
| 6 | 25 | 25 | 82,800 | 368 | 4.44e-03 |
| 7 | 25 | 24 | 82,800 | 128 | 1.55e-03 |
| 8 | 178 | 43 | 294,528 | 108 | 3.67e-04 |
| 9 | 25 | 1 | 82,800 | 2 | 2.42e-05 |
| 10 | 150 | 0 | 133,096 | 0 | 0 |
| 11 | 25 | 0 | 82,800 | 0 | 0 |
| 12 | 72 | 0 | 367,488 | 0 | 0 |
| 13 | 40 | 0 | 576,000 | 0 | 0 |

Burst delivery latency (framer → deframer decision, clock-corrected, includes TX queueing and air time): median 43.1 ms, p95 166.9 ms, max 243.6 ms.


## Link BER tests (message sets, no ARQ)

Raw frames from the perf daemon straight into the framer; every frame sent exactly once. Throughput = delivered payload bits ÷ time between first and last good frame at the receiver.

| Dir | Job | Set | Size (B) | Pattern | Load | Sent | OK | Failed | Lost | FER | BER | Err. density mean | Err. density max | SNR (dB) | Throughput (kb/s) | Max possible (kb/s) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 → 1 | 0-3 | custom | 32 | random | 0.8 | 12 | 12 | 0 | 0 | 0.0 % | 0 | – | – | 12.0 | 7.9 | 9.8 |
| 0 → 1 | 0-3 | custom | 128 | random | 0.8 | 12 | 12 | 0 | 0 | 0.0 % | 0 | – | – | 12.1 | 30.1 | 36.2 |
| 0 → 1 | 0-3 | custom | 512 | random | 0.8 | 12 | 12 | 0 | 0 | 0.0 % | 0 | – | – | 12.1 | 91.6 | 112.3 |
| 0 → 1 | 0-3 | custom | 2048 | random | 0.8 | 12 | 12 | 0 | 0 | 0.0 % | 0 | – | – | 12.0 | 193.5 | 236.6 |
| 0 → 1 | 0-3 | custom | 512 | zeros | 0.8 | 12 | 12 | 0 | 0 | 0.0 % | 0 | – | – | 12.0 | 92.1 | 112.3 |
| 0 → 1 | 0-3 | custom | 512 | ones | 0.8 | 12 | 12 | 0 | 0 | 0.0 % | 0 | – | – | 12.0 | 91.8 | 112.3 |
| 0 → 1 | 0-4 | custom | 400 | random | 0.9 | 25 | 0 | 25 | 0 | 100.0 % | 4.44e-03 | 4.44e-03 | 7.25e-03 | 6.0 | – | 93.9 |
| 0 → 1 | 0-5 | custom | 400 | random | 0.9 | 25 | 1 | 24 | 0 | 96.0 % | 1.55e-03 | 1.61e-03 | 4.23e-03 | 7.0 | – | 93.9 |
| 0 → 1 | 0-6 | custom | 400 | random | 0.9 | 25 | 18 | 7 | 0 | 28.0 % | 2.90e-04 | 1.04e-03 | 1.21e-03 | 8.0 | 60.4 | 93.9 |
| 0 → 1 | 0-7 | custom | 400 | random | 0.9 | 25 | 24 | 1 | 0 | 4.0 % | 2.42e-05 | 6.04e-04 | 6.04e-04 | 9.0 | 80.5 | 93.9 |
| 0 → 1 | 0-8 | custom | 400 | random | 0.9 | 25 | 25 | 0 | 0 | 0.0 % | 0 | – | – | 10.0 | 83.9 | 93.9 |
| 0 → 1 | 0-9 | custom | 400 | random | 0.9 | 25 | 25 | 0 | 0 | 0.0 % | 0 | – | – | 11.0 | 83.9 | 93.9 |
| 0 → 1 | 0-10 | custom | 400 | random | 0.9 | 25 | 25 | 0 | 0 | 0.0 % | 0 | – | – | 13.0 | 83.8 | 93.9 |
| 0 → 1 | 0-11 | custom | 4096 | random | 1.0 | 15 | 15 | 0 | 0 | 0.0 % | 0 | – | – | 13.0 | 290.6 | 290.1 |


### Receiver-only view

| RX node | Run | OK | Failed (header readable) | Missing (lost or unreadable) | Payload BER of failed | Sender log present |
|---|---|---|---|---|---|---|
| 1 | 1351115581 | 72 | 0 | 0 | – | yes |
| 1 | 1715713168 | 1 | 10 | 22 | 4.90e-02 | yes |
| 1 | 220107403 | 18 | 7 | 0 | 9.82e-04 | yes |
| 1 | 1153376913 | 24 | 1 | 0 | 6.25e-04 | yes |
| 1 | 1543290216 | 25 | 0 | 0 | – | yes |
| 1 | 295753599 | 25 | 0 | 0 | – | yes |
| 1 | 1072848828 | 25 | 0 | 0 | – | yes |
| 1 | 1596531625 | 15 | 0 | 0 | – | yes |


## Error analysis of failed bursts

Per failed burst: error density = bit errors ÷ compared bits. A burst = errors closer than 8 bits. In differential BPSK one wrong symbol gives two adjacent bit errors (a pair).

- **Failed bursts analysed:** 93 (0 partial (bad length))
- **Error density median:** 1.21e-03 (max 7.25e-03)
- **Errors per failed burst (median):** 4
- **Error bursts per failed frame:** 3.22 (longest burst 11 bits)
- **Errors in adjacent pairs:** 100.0 % (≈100 % = isolated symbol errors)
- **Where (hdr / payload / CRC):** 16 / 586 / 4 (bit errors)

| Sent at | Msg id | Size | Status | Bit errors | Bits | Density | Bursts | Longest burst | First error at | SNR (dB) |
|---|---|---|---|---|---|---|---|---|---|---|
| 2026-10-08 23:42:58.858 | 89 | 400 | crc_fail | 24 | 3312 | 7.25e-03 | 12 | 2 | 32.4 % | 6.2 |
| 2026-10-08 23:42:58.288 | 74 | 400 | crc_fail | 20 | 3312 | 6.04e-03 | 10 | 2 | 26.4 % | 6.0 |
| 2026-10-08 23:42:58.480 | 79 | 400 | crc_fail | 20 | 3312 | 6.04e-03 | 10 | 2 | 0.3 % | 6.1 |
| 2026-10-08 23:42:58.743 | 86 | 400 | crc_fail | 20 | 3312 | 6.04e-03 | 10 | 2 | 13.8 % | 6.1 |
| 2026-10-08 23:42:59.046 | 94 | 400 | crc_fail | 20 | 3312 | 6.04e-03 | 8 | 10 | 24.7 % | 6.1 |
| 2026-10-08 23:42:58.705 | 85 | 400 | crc_fail | 18 | 3312 | 5.43e-03 | 8 | 11 | 9.8 % | 6.1 |
| 2026-10-08 23:42:58.781 | 87 | 400 | crc_fail | 18 | 3312 | 5.43e-03 | 9 | 2 | 0.4 % | 6.0 |
| 2026-10-08 23:42:58.820 | 88 | 400 | crc_fail | 18 | 3312 | 5.43e-03 | 9 | 2 | 1.2 % | 6.0 |
| 2026-10-08 23:42:59.122 | 96 | 400 | crc_fail | 18 | 3312 | 5.43e-03 | 9 | 2 | 0.4 % | 6.1 |
| 2026-10-08 23:42:58.212 | 72 | 400 | crc_fail | 16 | 3312 | 4.83e-03 | 8 | 3 | 39.1 % | 6.1 |
| 2026-10-08 23:42:58.250 | 73 | 400 | crc_fail | 16 | 3312 | 4.83e-03 | 8 | 2 | 28.6 % | 5.9 |
| 2026-10-08 23:42:58.516 | 80 | 400 | crc_fail | 16 | 3312 | 4.83e-03 | 8 | 2 | 7.4 % | 6.0 |
| 2026-10-08 23:42:58.591 | 82 | 400 | crc_fail | 16 | 3312 | 4.83e-03 | 8 | 2 | 2.4 % | 5.9 |
| 2026-10-08 23:42:58.402 | 77 | 400 | crc_fail | 14 | 3312 | 4.23e-03 | 7 | 2 | 25.3 % | 5.9 |
| 2026-10-08 23:42:58.440 | 78 | 400 | crc_fail | 14 | 3312 | 4.23e-03 | 7 | 2 | 5.5 % | 6.0 |
| 2026-10-08 23:42:58.667 | 84 | 400 | crc_fail | 14 | 3312 | 4.23e-03 | 7 | 2 | 1.0 % | 6.0 |
| 2026-10-08 23:42:58.894 | 90 | 400 | crc_fail | 14 | 3312 | 4.23e-03 | 7 | 2 | 34.1 % | 6.0 |
| 2026-10-08 23:42:59.008 | 93 | 400 | crc_fail | 14 | 3312 | 4.23e-03 | 7 | 2 | 3.8 % | 6.0 |
| 2026-10-08 23:43:00.757 | 106 | 400 | crc_fail | 14 | 3312 | 4.23e-03 | 7 | 2 | 5.9 % | 7.0 |
| 2026-10-08 23:42:58.933 | 91 | 400 | crc_fail | 12 | 3312 | 3.62e-03 | 6 | 2 | 25.8 % | 6.1 |
| 2026-10-08 23:43:22.577 | 46 | 218 | crc_fail | 6 | 1856 | 3.23e-03 | 3 | 2 | 17.9 % | 8.1 |
| 2026-10-08 23:43:26.237 | 92 | 64 | crc_fail | 2 | 624 | 3.21e-03 | 1 | 2 | 46.8 % | 8.1 |
| 2026-10-08 23:42:58.364 | 76 | 400 | crc_fail | 10 | 3312 | 3.02e-03 | 4 | 11 | 1.7 % | 6.0 |
| 2026-10-08 23:42:58.553 | 81 | 400 | crc_fail | 10 | 3312 | 3.02e-03 | 5 | 2 | 0.8 % | 6.1 |
| 2026-10-08 23:42:59.085 | 95 | 400 | crc_fail | 10 | 3312 | 3.02e-03 | 5 | 2 | 14.8 % | 6.0 |


## SR-ARQ transport layer

From the sender's taps on the FSM: every SYN / DATA / FIN sent and every SYN_ACK / ACK / FIN_ACK received. A DATA packet sent again before its ACK arrived is a retransmission. With the receiver's log, each retransmission is classified: the receiver had decoded the DATA (so the ACK was lost or late) or not.

- **Sessions (node 0 → 1):** 10 (10 closed with FIN_ACK)
- **DATA packets:** 78 (116 transmissions)
- **Retransmission rate:** 48.7 % (data lost: 38)
- **Never ACKed:** 0 (packets)
- **SYN retries:** 0 (0 FIN retries)
- **RTT DATA→ACK:** 149 ms (min 78 · p95 272 ms (Karn: first-try packets))
- **Handshake SYN→SYN_ACK:** 78 ms (10 sessions)
- **Duplicate ACKs:** 0

| Payload (B) | On-link payload (B) | Packets | Transmissions | Retx | Retx rate | Tx per packet | Implied packet loss | Link FER at that size | Median RTT (ms) |
|---|---|---|---|---|---|---|---|---|---|
| 45 | 63 | 2 | 2 | 0 | 0.0 % | 1.000 | 0.0 % | 20.0 % | 138 |
| 46 | 64 | 2 | 3 | 1 | 50.0 % | 1.500 | 33.3 % | 20.0 % | 198 |
| 60 | 78 | 2 | 2 | 0 | 0.0 % | 1.000 | 0.0 % | 0.0 % | 81 |
| 146 | 164 | 2 | 2 | 0 | 0.0 % | 1.000 | 0.0 % | 0.0 % | 272 |
| 165 | 183 | 2 | 2 | 0 | 0.0 % | 1.000 | 0.0 % | 0.0 % | 80 |
| 200 | 218 | 68 | 105 | 37 | 54.4 % | 1.544 | 35.2 % | 35.2 % | 157 |

- **Sessions (node 1 → 0):** 2 (2 closed with FIN_ACK)
- **DATA packets:** 13 (13 transmissions)
- **Retransmission rate:** 0.0 % (no retransmissions)
- **Never ACKed:** 0 (packets)
- **SYN retries:** 0 (0 FIN retries)
- **RTT DATA→ACK:** 198 ms (min 78 · p95 264 ms (Karn: first-try packets))
- **Handshake SYN→SYN_ACK:** 80 ms (2 sessions)
- **Duplicate ACKs:** 0

| Payload (B) | On-link payload (B) | Packets | Transmissions | Retx | Retx rate | Tx per packet | Implied packet loss | Link FER at that size | Median RTT (ms) |
|---|---|---|---|---|---|---|---|---|---|
| 43 | 61 | 1 | 1 | 0 | 0.0 % | 1.000 | 0.0 % | 0.0 % | 97 |
| 44 | 62 | 1 | 1 | 0 | 0.0 % | 1.000 | 0.0 % | 0.0 % | 240 |
| 200 | 218 | 11 | 11 | 0 | 0.0 % | 1.000 | 0.0 % | 0.0 % | 198 |


## Application: messages through the full stack

Each test message = app frame (8 B header + name + payload) → SR-ARQ → radio; completion = tx_done from the FSM. Goodput = payload bits ÷ completion time. Latency = sender hand-off → verified at the receiver.

| Size (B) | Pattern | Sent | Completed | Verified | Packets | Mean retx | Median time (s) | Median goodput (kb/s) | Max goodput (kb/s) | Ideal goodput (kb/s) | Channel utilisation | Handshake (ms) | Latency (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 16 | random | 2 | 2 | 2 | 1 | 0.00 | 0.18 | 0.73 | 0.74 | 0.82 | 0.45 | 75 | 0.12 |
| 120 | random | 2 | 2 | 2 | 1 | 0.00 | 0.18 | 5.33 | 5.33 | 6.04 | 0.45 | 79 | 0.13 |
| 400 | random | 2 | 2 | 2 | 3 | 1.50 | 0.93 | 3.72 | 4.73 | 14.75 | 0.21 | 77 | 0.88 |
| 1500 | random | 2 | 2 | 2 | 8 | 2.50 | 0.94 | 13.69 | 17.16 | 32.42 | 0.42 | 76 | 0.89 |
| 5000 | random | 2 | 2 | 2 | 26 | 15.00 | 3.35 | 11.95 | 11.99 | 43.87 | 0.38 | 76 | 3.30 |

| Size (B) | Pattern | Sent | Completed | Verified | Packets | Mean retx | Median time (s) | Median goodput (kb/s) | Max goodput (kb/s) | Ideal goodput (kb/s) | Channel utilisation | Handshake (ms) | Latency (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 200 | text | 1 | 1 | 1 | 2 | 0.00 | 0.20 | 7.89 | 7.89 | 8.57 | 0.54 | 83 | 0.13 |
| 2000 | text | 1 | 1 | 1 | 11 | 0.00 | 0.48 | 33.35 | 33.35 | 34.89 | 0.79 | 77 | 0.41 |


## RF measurements at each receiver

From the RSSI/spectrum probe on the raw IQ (before the AGC): dBFS relative to the ADC full scale. Wideband SNR is over the whole sample-rate bandwidth (about 6 dB below the SNR in the symbol bandwidth at 4 samples/symbol). OBW = band holding 99 % of the received signal power; CFO = its power centroid.

| Node | Samples | Noise floor (dBFS) | Signal (dBFS) | Wideband SNR (dB) | OBW 99 % (kHz) | CFO (kHz) | Max clipping (%) | Peak (dBFS) | Channel busy (%) |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 53 | -43.2 | -37.5 | 4.2 | – | – | 0.0000 | -28.0 | 6.2 |
| 1 | 53 | -37.1 | -32.9 | 2.2 | 453 | 1.32 | 0.0000 | -20.8 | 27.8 |


## Timeline

Program start/end at both ends, jobs and notes, on the reference clock (node 0).

| Time (reference clock) | Node | Event | Detail |
|---|---|---|---|
| 2026-10-08 23:42:49.614 | 0 | program start | vm |
| 2026-10-08 23:42:49.801 | 1 | program start | vm |
| 2026-10-08 23:42:50.200 | 0 | job 0-1 start | mark  |
| 2026-10-08 23:42:50.200 | 0 | note | e2e start, antennas 1 m |
| 2026-10-08 23:42:50.200 | 0 | job 0-1 end | done |
| 2026-10-08 23:42:50.400 | 0 | job 0-2 start | idle  |
| 2026-10-08 23:42:53.401 | 0 | job 0-2 end | done |
| 2026-10-08 23:42:53.404 | 0 | job 0-3 start | link  |
| 2026-10-08 23:42:58.065 | 0 | job 0-3 end | done |
| 2026-10-08 23:42:58.212 | 0 | job 0-4 start | link  |
| 2026-10-08 23:43:00.225 | 0 | job 0-4 end | done |
| 2026-10-08 23:43:00.414 | 0 | job 0-5 start | link  |
| 2026-10-08 23:43:02.426 | 0 | job 0-5 end | done |
| 2026-10-08 23:43:02.621 | 0 | job 0-6 start | link  |
| 2026-10-08 23:43:04.634 | 0 | job 0-6 end | done |
| 2026-10-08 23:43:04.823 | 0 | job 0-7 start | link  |
| 2026-10-08 23:43:06.837 | 0 | job 0-7 end | done |
| 2026-10-08 23:43:07.025 | 0 | job 0-8 start | link  |
| 2026-10-08 23:43:09.039 | 0 | job 0-8 end | done |
| 2026-10-08 23:43:09.228 | 0 | job 0-9 start | link  |
| 2026-10-08 23:43:11.240 | 0 | job 0-9 end | done |
| 2026-10-08 23:43:11.430 | 0 | job 0-10 start | link  |
| 2026-10-08 23:43:13.443 | 0 | job 0-10 end | done |
| 2026-10-08 23:43:13.637 | 0 | job 0-11 start | link  |
| 2026-10-08 23:43:16.560 | 0 | job 0-11 end | done |
| 2026-10-08 23:43:16.643 | 0 | job 0-12 start | arq  |
| 2026-10-08 23:43:30.797 | 0 | job 0-12 end | done |
| 2026-10-08 23:43:30.862 | 1 | job 1-1 start | arq  |
| 2026-10-08 23:43:32.146 | 1 | job 1-1 end | done |
| 2026-10-08 23:43:32.257 | 0 | job 0-13 start | mark  |
| 2026-10-08 23:43:32.257 | 0 | note | e2e end |
| 2026-10-08 23:43:32.257 | 0 | job 0-13 end | done |
| 2026-10-08 23:43:43.446 | 0 | program end | 1444 records |
| 2026-10-08 23:43:43.454 | 1 | program end | 1651 records |


## Findings and suggestions

Automatic checks on the numbers above.

- **Check:** The 1024 B preamble is 73% of every 200 B burst's air time, so it caps 200 B throughput at 54 kb/s of 375. Try halving it and compare FER at the same SNR; bigger MTU also amortises it.
- **Check:** 0 → 1: 22.8% of bursts failed or were lost (median SNR 8.1 dB). See FER vs SNR / size to find where the link breaks down.
- **OK:** 1 → 0: frame error rate 0.00% over 125 bursts.
- **Check:** Median SNR 9.9 dB is low for BPSK at these frame lengths: raise TX power (lower CH_GAIN attenuation) or shorten the distance.

## Flowgraph parameters (every node)

Runtime values reported by the running flowgraph (variables after environment variables were applied, settings of the Python blocks), the GRC expressions of every DSP/radio block, and the daemon's settings.


### Node 0 (vm)

| Variable | Value |
|---|---|
| ADDR | ip:192.168.1.10 |
| CH_GAIN | 20.0 |
| MAX_BIT_ERRORS | 1 |
| MY_ID | 0 |
| PEER_ID | 1 |
| POSTAMBLE_LEN | 160 |
| PREAMBLE_LEN | 1024 |
| SDR_CF | 433000000.0 |
| TX_FREQ_A | 2412000000.0 |
| TX_FREQ_B | 2437000000.0 |
| alpha | 0.35 |
| costas_bw | 0.02 |
| fdd_side | A |
| fll_loop_bw | 0.01 |
| iq_rx_port | 53002 |
| iq_tx_port | 53001 |
| nv | 0 |
| rx_freq | 2437000000.0 |
| samp_rate | 1500000.0 |
| sps | 4 |
| sym_bw | 0.02 |
| tl_local_addr | 0 |
| tl_local_port | 1 |
| tl_m | 4 |
| tl_max_retries | 10 |
| tl_mtu | 200 |
| tl_peer_addr | 1 |
| tl_role | initiator |
| tl_rto_ms | 500 |
| tl_zmq_link_port | 52004 |
| tl_zmq_rx_port | 52002 |
| tl_zmq_tap_port | 52003 |
| tl_zmq_tx_port | 52001 |
| tx_freq | 2412000000.0 |

| Python block | Setting | Value |
|---|---|---|
| epy_block_0_0 | max_payload_len | 8192 |
| epy_block_0_0 | name | Packet Framer TX (Burst) |
| epy_block_0_0 | peer_id | 1 |
| epy_block_0_0 | postamble_len | 160 |
| epy_block_0_0 | preamble_byte | 255 |
| epy_block_0_0 | preamble_len | 1024 |
| epy_block_0_0 | repeat_count | 1 |
| epy_block_0_0_0 | bit_rate | 375000.0 |
| epy_block_0_0_0 | max_bit_errors | 1 |
| epy_block_0_0_0 | max_payload_len | 8192 |
| epy_block_0_0_0 | n_bad_len | 1 |
| epy_block_0_0_0 | n_crc_fail | 0 |
| epy_block_0_0_0 | n_ok | 125 |
| epy_block_0_0_0 | n_sync | 125 |
| epy_block_0_0_0 | name | Packet Deframer RX (Fast Burst) |
| epy_block_0_0_0 | peer_id | 0 |
| epy_block_0_0_0 | print_payload | False |
| epy_block_0_0_0 | tap_raw_max | 9000 |
| epy_block_1 | acked | [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False] |
| epy_block_1 | all_tx_pkts | [] |
| epy_block_1 | ctrl_retries | 0 |
| epy_block_1 | data_retries | [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] |
| epy_block_1 | dst_addr | 0 |
| epy_block_1 | dst_port | 0 |
| epy_block_1 | last_done_sid | 5272880419993286237 |
| epy_block_1 | local_addr | 0 |
| epy_block_1 | local_port | 1 |
| epy_block_1 | m | 4 |
| epy_block_1 | max_retries | 10 |
| epy_block_1 | media_code | 0 |
| epy_block_1 | mtu | 200 |
| epy_block_1 | name | SR-ARQ FSM Core |
| epy_block_1 | next_seq_abs | 0 |
| epy_block_1 | pkts_delivered | 0 |
| epy_block_1 | rcv_base | 0 |
| epy_block_1 | received | [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False] |
| epy_block_1 | role | initiator |
| epy_block_1 | rto_s | 0.5 |
| epy_block_1 | send_base | 0 |
| epy_block_1 | seq_space | 16 |
| epy_block_1 | session_id | 0 |
| epy_block_1 | state | IDLE |
| epy_block_1 | total_rx | 0 |
| epy_block_1 | total_tx | 0 |
| epy_block_1 | win_size | 8 |
| epy_block_7 | name | PERF EVM/SNR Probe |
| epy_block_7 | pre_syms | 1024 |
| epy_block_7 | sym_rate | 375000.0 |
| epy_block_8 | block | 1024 |
| epy_block_8 | busy_db | 3.0 |
| epy_block_8 | clip | 0.98 |
| epy_block_8 | fft_every | 4 |
| epy_block_8 | interval | 1.0 |
| epy_block_8 | name | PERF RSSI/Spectrum Probe |
| epy_block_8 | samp_rate | 1500000.0 |
| pdu_pdu_filter_0 | invert | False |
| pdu_pdu_filter_0 | name | PduFilter |
| pdu_pdu_filter_0_0 | invert | False |
| pdu_pdu_filter_0_0 | name | PduFilter |

| GRC block | Type | Parameters (as set in GRC) |
|---|---|---|
| BPSK_CONST | variable_constellation_rect | const_points=[1+0j, -1+0j], imag_sect=1, precision=8, real_sect=2, rot_sym=2, soft_dec_lut=None, sym_map=[0, 1], w_imag_sect=1, w_real_sect=1 |
| QPSK_CONST | variable_constellation_rect | const_points=[-1-1j, -1+1j, 1+1j, 1-1j], imag_sect=2, precision=8, real_sect=2, rot_sym=4, soft_dec_lut=None, sym_map=[0, 1, 3, 2], w_imag_sect=1, w_real_sect=1 |
| adpt_alg | variable_adaptive_algorithm | cons=BPSK_CONST, delta=10.0, ffactor=0.99, modulus=4, step_size=.01, type=cma |
| analog_agc_xx_0 | analog_agc_xx | gain=1.0, max_gain=1000, rate=1e-3, reference=1.0, type=complex |
| blocks_copy_0_0 | blocks_copy | enabled=True, showports=False, type=byte, vlen=1 |
| blocks_copy_1_1 | blocks_copy | enabled=True, showports=False, type=complex, vlen=1 |
| blocks_copy_1_2 | blocks_copy | enabled=True, showports=False, type=complex, vlen=1 |
| blocks_message_debug_0 | blocks_message_debug | en_uvec=True, log_level=info |
| blocks_message_debug_1 | blocks_message_debug | en_uvec=True, log_level=info |
| blocks_tag_gate_0_0 | blocks_tag_gate | propagate_tags=False, single_key="", type=complex, vlen=1 |
| blocks_unpack_k_bits_bb_0_0 | blocks_unpack_k_bits_bb | k=1 |
| channels_channel_model_0 | channels_channel_model | block_tags=False, epsilon=1.0, freq_offset=0.0, noise_voltage=nv, seed=0, taps=1.0 |
| digital_constellation_decoder_cb_0_0 | digital_constellation_decoder_cb | constellation=BPSK_CONST |
| digital_constellation_modulator_0_0_0 | digital_constellation_modulator | constellation=BPSK_CONST, differential=True, excess_bw=alpha, log=False, samples_per_symbol=sps, truncate=False, verbose=False |
| digital_costas_loop_cc_0 | digital_costas_loop_cc | order=BPSK_CONST.arity(), use_snr=False, w=costas_bw |
| digital_diff_decoder_bb_0_0 | digital_diff_decoder_bb | coding=digital.DIFF_DIFFERENTIAL, modulus=2 |
| digital_fll_band_edge_cc_0 | digital_fll_band_edge_cc | filter_size=11* sps +1, rolloff=alpha, samps_per_sym=sps, type=cc, w=fll_loop_bw |
| digital_linear_equalizer_0 | digital_linear_equalizer | adapt_after_training=True, alg=adpt_alg, num_taps=15, sps=2, training_sequence=[], training_start_tag="" |
| digital_symbol_sync_xx_0 | digital_symbol_sync_xx | constellation=digital.constellation_bpsk().base(), damping=1.0, loop_bw=sym_bw, max_dev=0.05, nfilters=128, osps=2, pfb_mf_taps=[], resamp_type=digital.IR_MMSE_8TAP, sps=sps, ted_gain=1.0, ted_type=digital.TED_SIGNAL_TIMES_SLOPE_ML, type=cc |
| iio_pluto_sink_0_0 | iio_pluto_sink | attenuation1=CH_GAIN, bandwidth=int(1.5e6), buffer_size=4096, cyclic=False, filter=, filter_source='Auto', fpass=0, frequency=int(tx_freq), fstop=0, len_tag_key=, samplerate=int(samp_rate), type=fc32, uri=ADDR |
| iio_pluto_source_0 | iio_pluto_source | bandwidth=int(1.5e6), bbdc=True, buffer_size=4096, filter=, filter_source='Auto', fpass=0, frequency=int(rx_freq), fstop=0, gain1='slow_attack', len_tag_key=packet_len, manual_gain1=64, quadrature=True, rfdc=True, samplerate=int(samp_rate), type=fc32, uri=ADDR |
| nv | variable_qtgui_range | min_len=200, orient=QtCore.Qt.Horizontal, rangeType=float, start=0, step=0.01, stop=1, value=0, widget=counter_slider |
| pdu_pdu_filter_0 | pdu_pdu_filter | invert=False, k=pmt.intern("dst_addr"), v=pmt.from_uint64(tl_local_addr) |
| pdu_pdu_filter_0_0 | pdu_pdu_filter | invert=False, k=pmt.intern("dst_addr"), v=pmt.from_uint64(0 if MY_ID != 0 else 255) |
| pdu_pdu_to_tagged_stream_0_0 | pdu_pdu_to_tagged_stream | tag=packet_len, type=byte |
| root_raised_cosine_filter_0 | root_raised_cosine_filter | decim=1, gain=1, interp=1, ntaps=11*sps+1, samp_rate=samp_rate, sym_rate=samp_rate/float(sps), type=fir_filter_ccf |
| zeromq_pub_msg_sink_tap | zeromq_pub_msg_sink | address="tcp://127.0.0.1:" + str(tl_zmq_tap_port), bind=True, timeout=100 |
| zeromq_pull_msg_source_0 | zeromq_pull_msg_source | address="tcp://127.0.0.1:" + str(tl_zmq_tx_port), bind=True, timeout=100 |
| zeromq_pull_msg_source_link | zeromq_pull_msg_source | address="tcp://127.0.0.1:" + str(tl_zmq_link_port), bind=True, timeout=100 |
| zeromq_push_msg_sink_0 | zeromq_push_msg_sink | address="tcp://127.0.0.1:" + str(tl_zmq_rx_port), bind=True, timeout=100 |


### Node 1 (vm)

| Variable | Value |
|---|---|
| ADDR | ip:192.168.1.10 |
| CH_GAIN | 20.0 |
| MAX_BIT_ERRORS | 1 |
| MY_ID | 1 |
| PEER_ID | 0 |
| POSTAMBLE_LEN | 160 |
| PREAMBLE_LEN | 1024 |
| SDR_CF | 433000000.0 |
| TX_FREQ_A | 2412000000.0 |
| TX_FREQ_B | 2437000000.0 |
| alpha | 0.35 |
| costas_bw | 0.02 |
| fdd_side | B |
| fll_loop_bw | 0.01 |
| iq_rx_port | 53001 |
| iq_tx_port | 53002 |
| nv | 0 |
| rx_freq | 2412000000.0 |
| samp_rate | 1500000.0 |
| sps | 4 |
| sym_bw | 0.02 |
| tl_local_addr | 1 |
| tl_local_port | 1 |
| tl_m | 4 |
| tl_max_retries | 10 |
| tl_mtu | 200 |
| tl_peer_addr | 0 |
| tl_role | initiator |
| tl_rto_ms | 500 |
| tl_zmq_link_port | 52004 |
| tl_zmq_rx_port | 52002 |
| tl_zmq_tap_port | 52003 |
| tl_zmq_tx_port | 52001 |
| tx_freq | 2437000000.0 |

| Python block | Setting | Value |
|---|---|---|
| epy_block_0_0 | max_payload_len | 8192 |
| epy_block_0_0 | name | Packet Framer TX (Burst) |
| epy_block_0_0 | peer_id | 0 |
| epy_block_0_0 | postamble_len | 160 |
| epy_block_0_0 | preamble_byte | 255 |
| epy_block_0_0 | preamble_len | 1024 |
| epy_block_0_0 | repeat_count | 1 |
| epy_block_0_0_0 | bit_rate | 375000.0 |
| epy_block_0_0_0 | max_bit_errors | 1 |
| epy_block_0_0_0 | max_payload_len | 8192 |
| epy_block_0_0_0 | n_bad_len | 0 |
| epy_block_0_0_0 | n_crc_fail | 93 |
| epy_block_0_0_0 | n_ok | 322 |
| epy_block_0_0_0 | n_sync | 415 |
| epy_block_0_0_0 | name | Packet Deframer RX (Fast Burst) |
| epy_block_0_0_0 | peer_id | 1 |
| epy_block_0_0_0 | print_payload | False |
| epy_block_0_0_0 | tap_raw_max | 9000 |
| epy_block_1 | acked | [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False] |
| epy_block_1 | all_tx_pkts | [] |
| epy_block_1 | ctrl_retries | 0 |
| epy_block_1 | data_retries | [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] |
| epy_block_1 | dst_addr | 0 |
| epy_block_1 | dst_port | 0 |
| epy_block_1 | last_done_sid | 9537240470296409199 |
| epy_block_1 | local_addr | 1 |
| epy_block_1 | local_port | 1 |
| epy_block_1 | m | 4 |
| epy_block_1 | max_retries | 10 |
| epy_block_1 | media_code | 0 |
| epy_block_1 | mtu | 200 |
| epy_block_1 | name | SR-ARQ FSM Core |
| epy_block_1 | next_seq_abs | 0 |
| epy_block_1 | pkts_delivered | 0 |
| epy_block_1 | rcv_base | 0 |
| epy_block_1 | received | [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False] |
| epy_block_1 | role | initiator |
| epy_block_1 | rto_s | 0.5 |
| epy_block_1 | send_base | 0 |
| epy_block_1 | seq_space | 16 |
| epy_block_1 | session_id | 0 |
| epy_block_1 | state | IDLE |
| epy_block_1 | total_rx | 0 |
| epy_block_1 | total_tx | 0 |
| epy_block_1 | win_size | 8 |
| epy_block_7 | name | PERF EVM/SNR Probe |
| epy_block_7 | pre_syms | 1024 |
| epy_block_7 | sym_rate | 375000.0 |
| epy_block_8 | block | 1024 |
| epy_block_8 | busy_db | 3.0 |
| epy_block_8 | clip | 0.98 |
| epy_block_8 | fft_every | 4 |
| epy_block_8 | interval | 1.0 |
| epy_block_8 | name | PERF RSSI/Spectrum Probe |
| epy_block_8 | samp_rate | 1500000.0 |
| pdu_pdu_filter_0 | invert | False |
| pdu_pdu_filter_0 | name | PduFilter |
| pdu_pdu_filter_0_0 | invert | False |
| pdu_pdu_filter_0_0 | name | PduFilter |

| GRC block | Type | Parameters (as set in GRC) |
|---|---|---|
| BPSK_CONST | variable_constellation_rect | const_points=[1+0j, -1+0j], imag_sect=1, precision=8, real_sect=2, rot_sym=2, soft_dec_lut=None, sym_map=[0, 1], w_imag_sect=1, w_real_sect=1 |
| QPSK_CONST | variable_constellation_rect | const_points=[-1-1j, -1+1j, 1+1j, 1-1j], imag_sect=2, precision=8, real_sect=2, rot_sym=4, soft_dec_lut=None, sym_map=[0, 1, 3, 2], w_imag_sect=1, w_real_sect=1 |
| adpt_alg | variable_adaptive_algorithm | cons=BPSK_CONST, delta=10.0, ffactor=0.99, modulus=4, step_size=.01, type=cma |
| analog_agc_xx_0 | analog_agc_xx | gain=1.0, max_gain=1000, rate=1e-3, reference=1.0, type=complex |
| blocks_copy_0_0 | blocks_copy | enabled=True, showports=False, type=byte, vlen=1 |
| blocks_copy_1_1 | blocks_copy | enabled=True, showports=False, type=complex, vlen=1 |
| blocks_copy_1_2 | blocks_copy | enabled=True, showports=False, type=complex, vlen=1 |
| blocks_message_debug_0 | blocks_message_debug | en_uvec=True, log_level=info |
| blocks_message_debug_1 | blocks_message_debug | en_uvec=True, log_level=info |
| blocks_tag_gate_0_0 | blocks_tag_gate | propagate_tags=False, single_key="", type=complex, vlen=1 |
| blocks_unpack_k_bits_bb_0_0 | blocks_unpack_k_bits_bb | k=1 |
| channels_channel_model_0 | channels_channel_model | block_tags=False, epsilon=1.0, freq_offset=0.0, noise_voltage=nv, seed=0, taps=1.0 |
| digital_constellation_decoder_cb_0_0 | digital_constellation_decoder_cb | constellation=BPSK_CONST |
| digital_constellation_modulator_0_0_0 | digital_constellation_modulator | constellation=BPSK_CONST, differential=True, excess_bw=alpha, log=False, samples_per_symbol=sps, truncate=False, verbose=False |
| digital_costas_loop_cc_0 | digital_costas_loop_cc | order=BPSK_CONST.arity(), use_snr=False, w=costas_bw |
| digital_diff_decoder_bb_0_0 | digital_diff_decoder_bb | coding=digital.DIFF_DIFFERENTIAL, modulus=2 |
| digital_fll_band_edge_cc_0 | digital_fll_band_edge_cc | filter_size=11* sps +1, rolloff=alpha, samps_per_sym=sps, type=cc, w=fll_loop_bw |
| digital_linear_equalizer_0 | digital_linear_equalizer | adapt_after_training=True, alg=adpt_alg, num_taps=15, sps=2, training_sequence=[], training_start_tag="" |
| digital_symbol_sync_xx_0 | digital_symbol_sync_xx | constellation=digital.constellation_bpsk().base(), damping=1.0, loop_bw=sym_bw, max_dev=0.05, nfilters=128, osps=2, pfb_mf_taps=[], resamp_type=digital.IR_MMSE_8TAP, sps=sps, ted_gain=1.0, ted_type=digital.TED_SIGNAL_TIMES_SLOPE_ML, type=cc |
| iio_pluto_sink_0_0 | iio_pluto_sink | attenuation1=CH_GAIN, bandwidth=int(1.5e6), buffer_size=4096, cyclic=False, filter=, filter_source='Auto', fpass=0, frequency=int(tx_freq), fstop=0, len_tag_key=, samplerate=int(samp_rate), type=fc32, uri=ADDR |
| iio_pluto_source_0 | iio_pluto_source | bandwidth=int(1.5e6), bbdc=True, buffer_size=4096, filter=, filter_source='Auto', fpass=0, frequency=int(rx_freq), fstop=0, gain1='slow_attack', len_tag_key=packet_len, manual_gain1=64, quadrature=True, rfdc=True, samplerate=int(samp_rate), type=fc32, uri=ADDR |
| nv | variable_qtgui_range | min_len=200, orient=QtCore.Qt.Horizontal, rangeType=float, start=0, step=0.01, stop=1, value=0, widget=counter_slider |
| pdu_pdu_filter_0 | pdu_pdu_filter | invert=False, k=pmt.intern("dst_addr"), v=pmt.from_uint64(tl_local_addr) |
| pdu_pdu_filter_0_0 | pdu_pdu_filter | invert=False, k=pmt.intern("dst_addr"), v=pmt.from_uint64(0 if MY_ID != 0 else 255) |
| pdu_pdu_to_tagged_stream_0_0 | pdu_pdu_to_tagged_stream | tag=packet_len, type=byte |
| root_raised_cosine_filter_0 | root_raised_cosine_filter | decim=1, gain=1, interp=1, ntaps=11*sps+1, samp_rate=samp_rate, sym_rate=samp_rate/float(sps), type=fir_filter_ccf |
| zeromq_pub_msg_sink_tap | zeromq_pub_msg_sink | address="tcp://127.0.0.1:" + str(tl_zmq_tap_port), bind=True, timeout=100 |
| zeromq_pull_msg_source_0 | zeromq_pull_msg_source | address="tcp://127.0.0.1:" + str(tl_zmq_tx_port), bind=True, timeout=100 |
| zeromq_pull_msg_source_link | zeromq_pull_msg_source | address="tcp://127.0.0.1:" + str(tl_zmq_link_port), bind=True, timeout=100 |
| zeromq_push_msg_sink_0 | zeromq_push_msg_sink | address="tcp://127.0.0.1:" + str(tl_zmq_rx_port), bind=True, timeout=100 |


### Differences between the nodes

| Variable | Node 0 | Node 1 |
|---|---|---|
| MY_ID | 0 | 1 |
| PEER_ID | 1 | 0 |
| fdd_side | A | B |
| iq_rx_port | 53002 | 53001 |
| iq_tx_port | 53001 | 53002 |
| rx_freq | 2437000000.0 | 2412000000.0 |
| tl_local_addr | 0 | 1 |
| tl_peer_addr | 1 | 0 |
| tx_freq | 2412000000.0 | 2437000000.0 |
