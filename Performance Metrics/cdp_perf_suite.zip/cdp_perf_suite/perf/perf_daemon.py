#!/usr/bin/env python3
"""
perf_daemon.py - performance-test daemon for the CDP transceiver (working BPSK + SR-ARQ flowgraph,
instrumented build perf_hw.grc / perf_sim.grc). It REPLACES the chat app / folder_sync_daemon
while you test: stop those first (they share the app ZMQ ports).

It connects to every layer of the flowgraph:
    app  : PUSH -> :TL_ZMQ_TX_PORT (52001)   app frames into the SR-ARQ FSM  (same as folder_sync_daemon)
           PULL <- :TL_ZMQ_RX_PORT (52002)   delivered files + tx_done/tx_failed/tx_busy events
    link : PUSH -> :TL_ZMQ_LINK_PORT (52004) raw link frames straight into the framer (no ARQ)
    taps : SUB  <- :TL_ZMQ_TAP_PORT (52003)  telemetry hub: every burst sent, every sync detection
                                             (ok / CRC fail / bad length, raw bits of failed frames),
                                             per-frame SNR (EVM), RSSI / noise floor / bandwidth / CFO,
                                             every transport packet in and out, every app message
and logs ALL of it, with host timestamps, to perf_logs/<session>.jsonl (session_start / session_end
markers, job_start / job_end markers, one line per message). Carry that file to the other PC
(or upload it in the dashboard) and build the merged report there.

Dashboard: http://127.0.0.1:8088  (live status, start tests, import the peer's log, build reports)

Usage (plug and play: start the flowgraph in GRC first, then just)
    python3 perf_daemon.py                (MY_ID / PEER_ID are read from the running flowgraph;
                                           logs go to ../perf_data/, dashboard http://127.0.0.1:8088)
    python3 perf_daemon.py --sim-node1    (2nd flowgraph on the SAME PC: perf_sim_node1.grc, dashboard :8089)
    python3 perf_daemon.py submit arq     --sizes 16,64,200,1000,5000 --patterns random,zeros --reps 3
    python3 perf_daemon.py submit link    --set standard        (test_sets/*.json, or --sizes/--count/--patterns)
    python3 perf_daemon.py submit plan    --name full_review
    python3 perf_daemon.py submit idle    --duration 20
    python3 perf_daemon.py submit mark    --text "antenna moved to 3 m"
    python3 perf_daemon.py status
    python3 perf_daemon.py check          (connects, listens 8 s, prints what each tap delivers)

Nothing has to be set: ports default to the values in perf_hw.grc (52001-52004) and the node
addresses come from the flowgraph. Optional overrides: --local-addr/--peer, --tx-port/--rx-port/
--tap-port/--link-port, --http-port, --root.
Requires python3-zmq and GNU Radio's pmt (run with the python3 that runs GNU Radio).
"""
import argparse
import base64
import collections
import json
import os
import platform
import queue
import random
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import perf_common as C  # noqa: E402

VERSION = "1.0"


def log_line(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


# =====================================================================
#  Transport to the flowgraph
# =====================================================================
def pmt_to_py(pmt, v):
    """PMT -> plain Python (dicts, numbers, strings). u8vectors become bytes."""
    try:
        if pmt.is_dict(v):
            out = {}
            keys = pmt.dict_keys(v)
            while pmt.is_pair(keys):
                k = pmt.car(keys)
                out[pmt.symbol_to_string(k) if pmt.is_symbol(k) else str(k)] = pmt_to_py(pmt, pmt.dict_ref(v, k, pmt.PMT_NIL))
                keys = pmt.cdr(keys)
            return out
        if pmt.is_symbol(v):
            return pmt.symbol_to_string(v)
        if pmt.is_u8vector(v):
            return bytes(pmt.u8vector_elements(v))
        if pmt.is_uint64(v):
            return int(pmt.to_uint64(v))
        if pmt.is_integer(v):
            return int(pmt.to_long(v))
        if pmt.is_real(v):
            return float(pmt.to_double(v))
        if pmt.is_bool(v):
            return bool(pmt.to_bool(v))
        if pmt.is_null(v):
            return None
        return pmt.to_python(v)
    except Exception:
        return None


class ZmqTransport:
    """Real transport: ZMQ sockets to the flowgraph (same pattern as folder_sync_daemon.py)."""

    def __init__(self, a):
        import zmq
        import pmt
        self.zmq, self.pmt, self.a = zmq, pmt, a
        ctx = zmq.Context.instance()

        def sock(kind, port, hwm=None):
            s = ctx.socket(kind)
            s.setsockopt(zmq.LINGER, 0)
            if hwm:
                s.setsockopt(zmq.SNDHWM, hwm)
            s.connect(f"tcp://127.0.0.1:{port}")
            return s
        self.app_tx = sock(zmq.PUSH, a.tx_port, 16)
        self.app_rx = sock(zmq.PULL, a.rx_port)
        self.link_tx = sock(zmq.PUSH, a.link_port, 2000)
        self.tap = sock(zmq.SUB, a.tap_port)
        self.tap.setsockopt(zmq.SUBSCRIBE, b"")
        self.stop = False

    def start(self, on_app, on_tel):
        threading.Thread(target=self._loop, args=(self.app_rx, on_app, self._app_msg), daemon=True).start()
        threading.Thread(target=self._loop, args=(self.tap, on_tel, self._tel_msg), daemon=True).start()

    def _loop(self, s, cb, conv):
        while not self.stop:
            try:
                if not s.poll(200, self.zmq.POLLIN):
                    continue
                raw = s.recv()
                item = conv(self.pmt.deserialize_str(raw))
            except Exception as e:
                log_line(f"[ZMQ] receive error: {e!r}")
                continue
            if item is not None:
                try:
                    cb(*item) if isinstance(item, tuple) else cb(item)
                except Exception:
                    traceback.print_exc()

    def _app_msg(self, msg):
        pmt = self.pmt
        meta = pmt_to_py(pmt, pmt.car(msg)) if pmt.is_pair(msg) else {}
        data = pmt_to_py(pmt, pmt.cdr(msg) if pmt.is_pair(msg) else msg)
        return (meta if isinstance(meta, dict) else {}, data if isinstance(data, bytes) else b"")

    def _tel_msg(self, msg):
        pmt = self.pmt
        d = pmt.cdr(msg) if pmt.is_pair(msg) else msg
        if not pmt.is_u8vector(d):
            return None
        return json.loads(bytes(pmt.u8vector_elements(d)).decode())

    def _send(self, s, msg):
        try:
            s.send(self.pmt.serialize_str(msg), self.zmq.NOBLOCK)
            return True
        except self.zmq.Again:
            return False

    def send_app(self, frame):
        pmt = self.pmt
        return self._send(self.app_tx, pmt.cons(pmt.make_dict(), pmt.init_u8vector(len(frame), list(frame))))

    def send_link(self, payload, meta):
        pmt = self.pmt
        m = pmt.make_dict()
        for k, v in meta.items():
            m = pmt.dict_add(m, pmt.intern(k), pmt.from_uint64(int(v)))
        return self._send(self.link_tx, pmt.cons(m, pmt.init_u8vector(len(payload), list(payload))))

    def close(self):
        self.stop = True


# =====================================================================
#  Log file
# =====================================================================
class JsonlLog:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.f = open(self.path, "a", buffering=1, encoding="utf-8")
        self.lock = threading.Lock()
        self.n = 0

    def write(self, rec):
        rec.setdefault("t", time.time())
        line = json.dumps(rec, separators=(",", ":"), default=str)
        with self.lock:
            self.f.write(line + "\n")
            self.n += 1

    def close(self):
        with self.lock:
            self.f.close()


# =====================================================================
#  Live statistics (dashboard / console); the report recomputes everything from the log
# =====================================================================
class LiveStats:
    def __init__(self):
        self.lock = threading.Lock()
        self.c = collections.Counter()
        self.hist = collections.deque(maxlen=900)       # (t, evm_snr, rssi_snr, nf_dbfs)
        self.last = {}
        self.hb_t = 0.0
        self.data_tx = {}                                 # (session, slot) -> pending / acked
        self.runs = {}                                    # link-test runs heard as receiver
        self.ber = [0, 0]                                 # live payload bit errors / bits (receiver)
        self.cfg = None

    def tel(self, r):
        tap = r.get("tap")
        with self.lock:
            c = self.c
            if tap == "hb":
                self.hb_t = time.time()
                self.last["hb"] = r
            elif tap == "config":
                self.cfg = r
            elif tap == "link_tx":
                c["tx_frames"] += 1
                c["tx_bytes"] += r.get("frame_len", 0)
                if "perf_seq" in r:
                    c["tx_link_test"] += 1
            elif tap == "link_rx":
                st = r.get("status", "?")
                c["rx_" + st] += 1
                c["rx_sync_err"] += r.get("sync_err", 0)
                if st == "ok" and not r.get("for_me", True):
                    c["rx_not_for_me"] += 1
                self._link_test_rx(r)
            elif tap == "evm" and r.get("snr_db") is not None:
                self.last["evm"] = r
                self.hist.append((r["t"], r["snr_db"], None, None))
            elif tap == "rssi":
                keep = self.last.get("rssi") or {}
                r = dict(r)
                for k in ("sig_dbfs", "snr_db", "obw99_hz", "cfo_hz"):      # keep the last value seen with signal
                    if r.get(k) is None and keep.get(k) is not None:
                        r[k] = keep[k]
                self.last["rssi"] = r
                self.hist.append((r["t"], None, r.get("snr_db"), r.get("nf_dbfs")))
            elif tap == "burst":
                c["rx_bursts"] += 1
                self.last["burst"] = r
            elif tap == "tp_tx":
                pt = r.get("meta", {}).get("pkt_type", "?")
                c["tp_tx_" + pt] += 1
                if pt == "DATA":
                    # the FSM numbers packets by window slot (mod 2^m): a packet on a slot whose previous
                    # packet has not been ACKed yet is a retransmission
                    k = (r["meta"].get("session_id"), r["meta"].get("seq_no"))
                    if self.data_tx.get(k) == "pending":
                        c["tp_retx"] += 1
                    self.data_tx[k] = "pending"
                    if len(self.data_tx) > 20000:
                        self.data_tx.clear()
            elif tap == "tp_rx":
                m = r.get("meta", {})
                c["tp_rx_" + m.get("pkt_type", "?")] += 1
                if m.get("pkt_type") == "ACK":
                    self.data_tx[(m.get("session_id"), m.get("seq_no"))] = "acked"
            elif tap == "hub_error":
                c["hub_errors"] += 1
                self.last["hub_error"] = r

    def _link_test_rx(self, r):
        st = r.get("status")
        if st == "ok" and r.get("head"):
            info = C.parse_link_payload(base64.b64decode(r["head"]) + bytes(32))
            if info:
                run = self.runs.setdefault(info["run"], {"ok": set(), "fail": set(), "max": -1, "t": 0})
                run["ok"].add(info["seq"])
                run["max"] = max(run["max"], info["seq"])
                run["t"] = r["t"]
        elif st in ("crc_fail", "bad_len") and r.get("raw"):
            raw = base64.b64decode(r["raw"])
            info = C.parse_link_payload(raw[C.LINK_HDR_BYTES:])
            if info and info["run"] in self.runs:
                run = self.runs[info["run"]]
                run["fail"].add(info["seq"])
                run["max"] = max(run["max"], info["seq"])
                exp = C.expected_link_payload(info)
                got = raw[C.LINK_HDR_BYTES:C.LINK_HDR_BYTES + len(exp)]
                n = min(len(exp), len(got))
                if n:
                    x = int.from_bytes(bytes(a ^ b for a, b in zip(exp[:n], got[:n])), "big")
                    self.ber[0] += bin(x).count("1")
                    self.ber[1] += 8 * n

    def snapshot(self):
        with self.lock:
            c = dict(self.c)
            dec = c.get("rx_ok", 0) + c.get("rx_crc_fail", 0) + c.get("rx_bad_len", 0)
            runs = []
            for rid, run in sorted(self.runs.items(), key=lambda kv: -kv[1]["t"])[:5]:
                seen = len(run["ok"] | run["fail"])
                exp = run["max"] + 1
                runs.append({"run": rid, "ok": len(run["ok"]), "fail": len(run["fail"] - run["ok"]),
                             "missing_so_far": max(0, exp - seen), "highest_seq": run["max"]})
            return {"counters": c, "rx_decided": dec,
                    "rx_fer": (c.get("rx_crc_fail", 0) + c.get("rx_bad_len", 0)) / dec if dec else None,
                    "live_ber": self.ber[0] / self.ber[1] if self.ber[1] else None,
                    "evm": self.last.get("evm"), "rssi": self.last.get("rssi"), "burst": self.last.get("burst"),
                    "hb_age": time.time() - self.hb_t if self.hb_t else None, "hb": self.last.get("hb"),
                    "hist": list(self.hist)[-300:], "link_runs_rx": runs}


# =====================================================================
#  The daemon
# =====================================================================
def ntp_status():
    out = {}
    for prop in ("NTPSynchronized", "NTP", "Timezone"):
        try:
            out[prop] = subprocess.run(["timedatectl", "show", "-p", prop, "--value"], capture_output=True,
                                       text=True, timeout=2).stdout.strip()
        except Exception:
            pass
    return out


def parse_grc(path):
    """Every enabled block and variable of a .grc file (expressions as written in GRC)."""
    try:
        import yaml
        d = yaml.safe_load(open(path, encoding="utf-8"))
    except Exception as e:
        return {"error": f"could not read {path}: {e}"}
    skip = {"affinity", "alias", "maxoutbuf", "minoutbuf", "_source_code", "gui_hint", "comment"}
    out = {"file": str(path), "title": d.get("options", {}).get("parameters", {}).get("title"),
           "variables": {}, "blocks": {}}
    for b in d.get("blocks", []):
        if b.get("states", {}).get("state") != "enabled":
            continue
        p = b.get("parameters", {})
        if b["id"] == "variable":
            out["variables"][b["name"]] = str(p.get("value", ""))
        elif not b["id"].startswith(("qtgui_const", "qtgui_freq", "virtual_", "epy_block", "import")):
            out["blocks"][b["name"]] = {"id": b["id"], **{k: str(v) for k, v in p.items()
                                        if k not in skip and not k.startswith(("alpha", "color", "label", "width",
                                                                              "style", "marker"))}}
    return out


class PerfDaemon:
    def __init__(self, a, transport):
        self.a, self.tr = a, transport
        self.root = Path(a.root).resolve()
        self.logs_dir = self.root / "perf_logs"
        self.imported = self.logs_dir / "imported"
        self.reports_dir = self.root / "perf_reports"
        self.inbox = self.root / "perf_inbox"
        for d in (self.logs_dir, self.imported, self.reports_dir, self.inbox):
            d.mkdir(parents=True, exist_ok=True)
        self.sets_dir = Path(a.sets_dir) if getattr(a, "sets_dir", None) else HERE / "test_sets"
        self.host = socket.gethostname()
        self.session = None
        self.log = None                     # opened once the node addresses are known
        self.ready = threading.Event()
        self.stats = LiveStats()
        self.events = queue.Queue()
        self.jobs = collections.deque()
        self.job_cv = threading.Condition()
        self.cancel = threading.Event()
        self.current = None
        self.done_jobs = collections.deque(maxlen=50)
        self.lines = collections.deque(maxlen=200)
        self.report_state = {"state": "idle"}
        self.grc = parse_grc(a.grc) if getattr(a, "grc", None) and Path(a.grc).exists() else None
        self._last_cfg_log = (None, 0.0)
        self._last_hb_log = 0.0
        self._job_n = 0
        self.closed = False

    # ---------------------------------------------------------------- helpers
    def say(self, msg):
        log_line(msg)
        self.lines.append(time.strftime("%H:%M:%S ") + msg)

    def link_params(self):
        return C.link_params(self.stats.cfg)

    def flowgraph_alive(self):
        return self.stats.hb_t and time.time() - self.stats.hb_t < 5

    def start(self):
        """Connect at once; the log starts when MY_ID / PEER_ID are known (from the flowgraph)."""
        self.tr.start(self._app_cb, self._tel_cb)
        threading.Thread(target=self._job_loop, daemon=True).start()
        threading.Thread(target=self._init_session, daemon=True).start()

    def _tel_cb(self, rec):
        if self.ready.is_set():
            self.on_tel(rec)
        else:
            self.stats.tel(rec)            # only learn the configuration until the log is open

    def _app_cb(self, meta, data):
        if self.ready.is_set():
            self.on_app(meta, data)

    def _init_session(self):
        a = self.a
        t0, warned = time.time(), 0
        while not self.closed:
            cfg = self.stats.cfg
            if cfg:
                v = cfg.get("vars", {})
                me = v.get("MY_ID", v.get("tl_local_addr"))
                peer = v.get("PEER_ID", v.get("tl_peer_addr"))
                if a.local_addr is not None and me is not None and int(me) != a.local_addr:
                    self.say(f"WARNING: --local-addr {a.local_addr} but the flowgraph has MY_ID {me}: using {me}")
                if a.peer is not None and peer is not None and int(peer) != a.peer:
                    self.say(f"WARNING: --peer {a.peer} but the flowgraph has PEER_ID {peer}: using {peer}")
                a.local_addr = int(me) if me is not None else a.local_addr
                a.peer = int(peer) if peer is not None else a.peer
                break
            if a.local_addr is not None and a.peer is not None and time.time() - t0 > 10:
                self.say("no flowgraph telemetry yet: using the addresses given on the command line")
                break
            if time.time() - warned > 10:
                self.say(f"waiting for the flowgraph (telemetry port {a.tap_port}) to learn MY_ID / PEER_ID ...")
                warned = time.time()
            time.sleep(0.2)
        if self.closed:
            return
        self.session = f"node{a.local_addr}_{self.host}_{time.strftime('%Y%m%d-%H%M%S')}"
        self.log = JsonlLog(self.logs_dir / f"{self.session}.jsonl")
        self._write_session_start()
        self.ready.set()
        self.say(f"node {a.local_addr} -> peer {a.peer}; logging to {self.log.path}")

    def _write_session_start(self):
        a = self.a
        rec = {"k": "session_start", "t": time.time(), "iso": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
               "version": VERSION, "session": self.session, "host": self.host,
               "platform": platform.platform(), "python": sys.version.split()[0],
               "node_addr": a.local_addr, "peer_addr": a.peer, "peer_port": a.port,
               "ports": {"app_tx": a.tx_port, "app_rx": a.rx_port, "tap": a.tap_port, "link": a.link_port},
               "env": {k: v for k, v in os.environ.items() if k.startswith("TL_")},
               "clock": {"ntp": ntp_status(), "monotonic": time.monotonic(), "tz": time.strftime("%z")}}
        if getattr(a, "grc", None) and Path(a.grc).exists():
            rec["grc"] = self.grc = parse_grc(a.grc)          # re-read: the file as it is now
            gv = rec["grc"].get("variables", {})
            if gv.get("MY_ID") is not None and str(gv.get("MY_ID")) != str(a.local_addr):
                self.say(f"NOTE: {a.grc} has MY_ID {gv.get('MY_ID')} but the running flowgraph has {a.local_addr}: "
                         "the block settings in the report come from that file - save the .grc you are running, "
                         "or pass --grc <file>")
        self.log.write(rec)

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.cancel.set()
        if self.log is None:
            self.tr.close()
            return
        snap = self.stats.snapshot()
        self.log.write({"k": "session_end", "t": time.time(), "iso": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                        "records": self.log.n, "counters": snap["counters"]})
        self.log.close()
        self.tr.close()

    # ---------------------------------------------------------------- inputs from the flowgraph
    def on_tel(self, rec):
        tap = rec.get("tap")
        self.stats.tel(rec)
        now = time.time()
        if tap == "config":
            key = json.dumps({"v": rec.get("vars"), "b": rec.get("blocks")}, sort_keys=True, default=str)
            if key == self._last_cfg_log[0] and now - self._last_cfg_log[1] < 60:
                return
            if self._last_cfg_log[0] is None:
                self.say("flowgraph telemetry connected")
            self._last_cfg_log = (key, now)
        elif tap == "hb":
            if now - self._last_hb_log < 10:
                return
            self._last_hb_log = now
        elif tap == "hub_error":
            self.say(f"[HUB] {rec.get('port')}: {rec.get('err')}")
        rec = dict(rec)
        rec["k"] = "tel"
        rec["rt"] = now
        self.log.write(rec)

    def on_app(self, meta, data):
        t = time.time()
        if "event" in meta:
            ev = meta["event"]
            self.log.write({"k": "app_event", "t": t, "event": ev, "session_id": meta.get("session_id")})
            self.events.put((ev, t))
            return
        rec = {"k": "app_rx", "t": t, "len": len(data), "src_addr": meta.get("src_addr"),
               "src_port": meta.get("src_port"), "session_id": meta.get("session_id")}
        try:
            name, content = C.parse_app_frame(data)
        except ValueError as e:
            rec.update(perf=False, error=str(e))
            self.log.write(rec)
            self.say(f"[APP] unparseable frame ({len(data)} B): {e}")
            return
        rec["name"] = name
        info = C.parse_perf_name(name)
        if info:
            exp = C.perf_data(info["run"], info["idx"], info["size"], info["pattern"])
            n = min(len(exp), len(content))
            errs = sum(bin(x ^ y).count("1") for x, y in zip(exp[:n], content[:n])) + 8 * abs(len(exp) - len(content))
            rec.update(perf=True, ok=(content == exp), bit_errors=errs, **info)
            self.stats.c["app_rx_ok" if content == exp else "app_rx_bad"] += 1
            self.say(f"[APP] received test message #{info['idx']} ({info['size']} B {info['pattern']}): "
                     f"{'OK' if content == exp else f'CONTENT ERROR ({errs} bit errors)'}")
        else:
            rec.update(perf=False, file_len=len(content))
            p = self.inbox / Path(name).name
            try:
                p.write_bytes(content)
            except OSError:
                pass
            self.say(f"[APP] received non-test file {name} ({len(content)} B) -> perf_inbox/")
        self.log.write(rec)

    # ---------------------------------------------------------------- jobs
    def test_sets(self):
        out = []
        for p in sorted(self.sets_dir.glob("*.json")):
            try:
                d = json.loads(p.read_text())
                d["file"] = p.name
                out.append(d)
            except Exception as e:
                out.append({"name": p.stem, "error": str(e)})
        return out

    def _find_set(self, name):
        for s in self.test_sets():
            if s.get("name") == name or s.get("file") in (name, f"{name}.json"):
                return s
        raise ValueError(f"no test set named {name!r} in {self.sets_dir}")

    def submit(self, job):
        jobs = [job]
        if job.get("type") == "plan":
            plan = self._find_set(job["name"]) if job.get("name") else job
            jobs = [dict(j, plan=plan.get("name")) for j in plan["jobs"]]
        ids = []
        with self.job_cv:
            for j in jobs:
                j = dict(j)
                if j.get("type") not in ("arq", "link", "idle", "mark"):
                    raise ValueError(f"unknown job type {j.get('type')!r}")
                if j["type"] == "link" and j.get("set") and not j.get("items"):
                    s = self._find_set(j["set"])
                    j["items"] = s["items"]
                    j.setdefault("load", s.get("load", 0.8))
                self._job_n += 1
                j["id"] = f"{self.a.local_addr}-{self._job_n}"
                j["run"] = random.getrandbits(31)
                j["queued_t"] = time.time()
                self.jobs.append(j)
                ids.append(j["id"])
            self.job_cv.notify_all()
        self.say(f"queued {len(ids)} job(s): {', '.join(ids)}")
        return ids

    def cancel_jobs(self, clear_queue=True):
        with self.job_cv:
            n = len(self.jobs) if clear_queue else 0
            if clear_queue:
                self.jobs.clear()
        self.cancel.set()
        self.say(f"cancel requested (running job stops, {n} queued job(s) dropped)")

    def _job_loop(self):
        while not self.ready.wait(0.5):
            if self.closed:
                return
        while not self.closed:
            with self.job_cv:
                while not self.jobs and not self.closed:
                    self.job_cv.wait(1.0)
                if self.closed:
                    return
                job = self.jobs.popleft()
            self._run_job(job)

    def _run_job(self, job):
        self.cancel.clear()
        self.current = {"id": job["id"], "type": job["type"], "done": 0, "total": 0, "t0": time.time(), "note": ""}
        peer = int(job.get("peer", self.a.peer))
        port = int(job.get("port", self.a.port))
        job["peer"], job["port"] = peer, port
        self.log.write({"k": "job_start", "t": time.time(), "job": job["id"], "run": job["run"], "type": job["type"],
                        "params": {k: v for k, v in job.items() if k not in ("id", "run")},
                        "link_params": self.link_params()})
        self.say(f"[JOB {job['id']}] start {job['type']} {job.get('set') or ''}")
        status, summary = "done", {}
        try:
            if job["type"] != "mark" and not self._wait_flowgraph():
                raise RuntimeError("no telemetry from the flowgraph (is perf_hw/perf_sim running?)")
            summary = getattr(self, f"_job_{job['type']}")(job) or {}
            if self.cancel.is_set():
                status = "cancelled"
        except Exception as e:
            status, summary = "error", {"error": str(e)}
            self.say(f"[JOB {job['id']}] ERROR {e}")
            traceback.print_exc()
        self.log.write({"k": "job_end", "t": time.time(), "job": job["id"], "run": job["run"], "type": job["type"],
                        "status": status, "summary": summary})
        self.say(f"[JOB {job['id']}] {status} {json.dumps(summary)[:200]}")
        self.done_jobs.appendleft({"id": job["id"], "type": job["type"], "status": status, "summary": summary,
                                   "t": time.time(), "plan": job.get("plan"), "set": job.get("set")})
        self.current = None

    def _wait_flowgraph(self, timeout=30):
        end = time.time() + timeout
        while time.time() < end and not self.cancel.is_set():
            if self.flowgraph_alive():
                return True
            if self.current:
                self.current["note"] = "waiting for flowgraph telemetry"
            time.sleep(0.25)
        return self.flowgraph_alive()

    def _sleep(self, s):
        return self.cancel.wait(max(0.0, s))

    def _wait_event(self, timeout):
        end = time.time() + timeout
        while not self.cancel.is_set():
            left = end - time.time()
            if left <= 0:
                return None, time.time()
            try:
                return self.events.get(timeout=min(left, 0.25))
            except queue.Empty:
                continue
        return "cancelled", time.time()

    # -- ARQ (application + SR-ARQ) sweep
    def _job_arq(self, job):
        sizes = [int(s) for s in job.get("sizes", [16, 64, 200, 1000])]
        patterns = job.get("patterns", ["random"])
        reps = int(job.get("reps", 3))
        gap = float(job.get("gap_s", 0.5))
        p = self.link_params()
        total = len(sizes) * len(patterns) * reps
        self.current["total"] = total
        res = collections.Counter()
        idx = 0
        for size in sizes:
            for pattern in patterns:
                for _ in range(reps):
                    if self.cancel.is_set():
                        return dict(res)
                    idx += 1
                    name = C.perf_name(job["run"], idx, size, pattern)
                    data = C.perf_data(job["run"], idx, size, pattern)
                    frame = C.build_app_frame(job["peer"], name, data, job["port"])
                    n_pkts = C.n_packets(len(frame), p["mtu"])
                    air = (n_pkts + 2) * C.airtime(min(p["mtu"], len(frame)) + C.TP_HDR_BYTES, p)
                    timeout = float(job.get("timeout_s") or (3 * air + 15))
                    ev = None
                    for attempt in range(6):
                        while not self.events.empty():
                            self.events.get_nowait()
                        t_send = time.time()
                        ok = self.tr.send_app(frame)
                        self.log.write({"k": "app_send", "t": t_send, "job": job["id"], "run": job["run"], "idx": idx,
                                        "size": size, "pattern": pattern, "name": name, "frame_len": len(frame),
                                        "n_pkts": n_pkts, "crc": C.crc(data), "attempt": attempt,
                                        "queued": ok})
                        if not ok:
                            ev, t_ev = "not_accepted", time.time()
                            self._sleep(1.0)
                            continue
                        ev, t_ev = self._wait_event(timeout)
                        ev = ev or "timeout"
                        self.log.write({"k": "app_result", "t": t_ev, "job": job["id"], "run": job["run"], "idx": idx,
                                        "size": size, "pattern": pattern, "event": ev, "dt": t_ev - t_send,
                                        "attempt": attempt})
                        if ev != "tx_busy":
                            break
                        self._sleep(random.uniform(1.0, 3.0))
                    res[ev] += 1
                    self.current["done"] = idx
                    self.current["note"] = f"{size} B {pattern}: {ev}"
                    self.say(f"[ARQ] #{idx}/{total} {size} B {pattern}: {ev}")
                    if ev in ("timeout", "tx_failed"):
                        self._sleep(2.0)       # let the FSM finish resetting
                    self._sleep(gap)
        return dict(res)

    # -- raw link frames (no ARQ): BER / FER test set
    def _job_link(self, job):
        items = job.get("items") or [{"size": int(s), "count": int(job.get("count", 50)), "pattern": pt}
                                     for s in job.get("sizes", [200]) for pt in job.get("patterns", ["random"])]
        load = min(1.0, max(0.05, float(job.get("load", 0.8))))
        gap = float(job.get("gap_s", 0.0))
        p = self.link_params()
        total = sum(int(it.get("count", 1)) for it in items)
        self.current["total"] = total
        seq, sent, refused = 0, 0, 0
        t_next = time.time()
        for k, it in enumerate(items):
            size = max(int(it["size"]), C.LINK_HDR.size)
            for _ in range(int(it.get("count", 1))):
                if self.cancel.is_set():
                    return {"sent": sent, "refused": refused}
                self._sleep(t_next - time.time())
                t = time.time()
                payload = C.build_link_payload(job["run"], seq, k, it.get("pattern", "random"), size, t)
                ok = self.tr.send_link(payload, {"dst_addr": job["peer"], "perf_job": job["run"], "perf_seq": seq})
                self.log.write({"k": "link_send", "t": t, "job": job["id"], "run": job["run"], "seq": seq, "item": k,
                                "size": size, "pattern": it.get("pattern", "random"), "queued": ok})
                if ok:
                    sent += 1
                else:
                    refused += 1
                seq += 1
                self.current["done"] = seq
                self.current["note"] = f"item {k + 1}/{len(items)}: {size} B {it.get('pattern', 'random')}"
                t_next = max(t_next + C.airtime(size, p) / load + gap, time.time() - 1.0)
        # wait for the last frames to leave the radio and reach the peer
        self._sleep(3 * C.airtime(max(int(i["size"]) for i in items), p) + 1.0)
        return {"sent": sent, "refused": refused, "frames": total, "load": load}

    def _job_idle(self, job):
        dur = float(job.get("duration_s", 20))
        self.current["total"] = int(dur)
        t0 = time.time()
        while time.time() - t0 < dur and not self.cancel.is_set():
            self.current["done"] = int(time.time() - t0)
            self._sleep(0.5)
        return {"duration_s": round(time.time() - t0, 2)}

    def _job_mark(self, job):
        self.log.write({"k": "mark", "t": time.time(), "text": job.get("text", "")})
        return {"text": job.get("text", "")}

    # ---------------------------------------------------------------- reports
    def logs(self):
        out = []
        for folder, kind in ((self.logs_dir, "local"), (self.imported, "imported")):
            for p in sorted(folder.glob("*.jsonl"), key=lambda p: -p.stat().st_mtime):
                head = {}
                try:
                    with open(p, encoding="utf-8") as f:
                        head = json.loads(f.readline() or "{}")
                except Exception:
                    pass
                out.append({"name": p.name, "kind": kind, "size": p.stat().st_size, "mtime": p.stat().st_mtime,
                            "node": head.get("node_addr"), "host": head.get("host"),
                            "current": self.log is not None and p == self.log.path})
        return out

    def log_path(self, name, kind):
        folder = self.imported if kind == "imported" else self.logs_dir
        p = (folder / Path(name).name).resolve()
        if p.parent != folder.resolve() or not p.exists():
            raise FileNotFoundError(name)
        return p

    def build_report(self, sel, title=None):
        if self.report_state.get("state") == "running":
            raise RuntimeError("a report is already being built")
        paths = [self.log_path(s["name"], s.get("kind", "local")) for s in sel]

        def work():
            self.report_state = {"state": "running", "t0": time.time(), "logs": [p.name for p in paths]}
            try:
                import perf_report
                out = self.reports_dir / time.strftime("report_%Y%m%d-%H%M%S")
                perf_report.build_report([str(p) for p in paths], str(out), title=title)
                self.report_state = {"state": "done", "dir": out.name, "t": time.time()}
                self.say(f"report written: {out / 'report.html'}")
            except Exception as e:
                traceback.print_exc()
                self.report_state = {"state": "error", "error": repr(e), "t": time.time()}
                self.say(f"report failed: {e!r}")
        threading.Thread(target=work, daemon=True).start()

    def reports(self):
        return [{"name": p.name, "mtime": p.stat().st_mtime} for p in
                sorted(self.reports_dir.glob("report_*"), key=lambda p: -p.stat().st_mtime) if (p / "report.html").exists()]

    def status(self):
        p = self.link_params()
        snap = self.stats.snapshot()
        return {"node": self.a.local_addr, "peer": self.a.peer, "host": self.host, "session": self.session,
                "ready": self.ready.is_set(), "log": str(self.log.path) if self.log else None,
                "records": self.log.n if self.log else 0, "version": VERSION,
                "key_params": C.key_parameters(self.stats.cfg, self.grc),
                "flowgraph_alive": bool(self.flowgraph_alive()), "link_params": p,
                "config_vars": (self.stats.cfg or {}).get("vars", {}),
                "live": snap, "current": self.current, "queue": [{"id": j["id"], "type": j["type"],
                                                                  "set": j.get("set")} for j in list(self.jobs)],
                "done": list(self.done_jobs), "lines": list(self.lines)[-60:], "report": self.report_state,
                "time": time.time()}


# =====================================================================
#  HTTP dashboard / API
# =====================================================================
def make_handler(d):
    import perf_web

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body, ctype="application/json"):
            if isinstance(body, (dict, list)):
                body = json.dumps(body, default=str).encode()
            elif isinstance(body, str):
                body = body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _file(self, path, download=False):
            ctype = {".html": "text/html; charset=utf-8", ".csv": "text/csv", ".json": "application/json",
                     ".md": "text/markdown; charset=utf-8", ".jsonl": "application/x-ndjson"}.get(path.suffix, "application/octet-stream")
            data = path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            if download:
                self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
            self.end_headers()
            self.wfile.write(data)

        def _body(self):
            n = int(self.headers.get("Content-Length", 0))
            return self.rfile.read(n) if n else b""

        def do_GET(self):
            u = urlparse(self.path)
            try:
                if u.path in ("/", "/index.html"):
                    return self._send(200, perf_web.DASHBOARD, "text/html; charset=utf-8")
                if u.path == "/api/status":
                    return self._send(200, d.status())
                if u.path == "/api/sets":
                    return self._send(200, d.test_sets())
                if u.path == "/api/logs":
                    return self._send(200, d.logs())
                if u.path == "/api/reports":
                    return self._send(200, d.reports())
                parts = [unquote(x) for x in u.path.split("/") if x]
                if len(parts) == 3 and parts[0] == "files" and parts[1] in ("local", "imported"):
                    return self._file(d.log_path(parts[2], parts[1]), download=True)
                if len(parts) == 3 and parts[0] == "reports":
                    base = d.reports_dir.resolve()
                    p = (base / Path(parts[1]).name / Path(parts[2]).name).resolve()
                    if p.is_file() and base in p.parents:
                        return self._file(p, download=not p.name.endswith(".html"))
                return self._send(404, {"error": "not found"})
            except FileNotFoundError:
                return self._send(404, {"error": "not found"})
            except Exception as e:
                return self._send(500, {"error": repr(e)})

        def do_POST(self):
            u = urlparse(self.path)
            try:
                if u.path == "/api/job":
                    return self._send(200, {"ids": d.submit(json.loads(self._body() or b"{}"))})
                if u.path == "/api/cancel":
                    d.cancel_jobs()
                    return self._send(200, {"ok": True})
                if u.path == "/api/upload":
                    name = Path(parse_qs(u.query).get("name", ["peer.jsonl"])[0]).name
                    if not name.endswith(".jsonl"):
                        name += ".jsonl"
                    data = self._body()
                    (d.imported / name).write_bytes(data)
                    d.say(f"imported log {name} ({len(data)} B)")
                    return self._send(200, {"ok": True, "name": name})
                if u.path == "/api/report":
                    req = json.loads(self._body() or b"{}")
                    d.build_report(req.get("logs", []), req.get("title"))
                    return self._send(200, {"ok": True})
                return self._send(404, {"error": "not found"})
            except Exception as e:
                return self._send(400, {"error": str(e)})
    return H


def serve_http(d, host, port):
    srv = ThreadingHTTPServer((host, port), make_handler(d))
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    d.say(f"dashboard: http://{host}:{port}/")
    return srv


# =====================================================================
#  CLI
# =====================================================================
def common_args(ap):
    ap.add_argument("--root", default=None, help="folder for perf_logs/ and perf_reports/ (default: <package>/perf_data, "
                                                 "or perf_data_sim_node0/1 with --sim-node0/1)")
    ap.add_argument("--local-addr", type=int, default=None, help="normally read from the flowgraph (MY_ID)")
    ap.add_argument("--peer", type=int, default=None, help="normally read from the flowgraph (PEER_ID)")
    ap.add_argument("--port", type=int, default=0, help="destination port for ARQ test messages (0 = any)")
    ap.add_argument("--tx-port", type=int, default=None, help="app ZMQ into the FSM (default 52001)")
    ap.add_argument("--rx-port", type=int, default=None, help="app ZMQ out of the FSM (default 52002)")
    ap.add_argument("--tap-port", type=int, default=None, help="telemetry (default 52003)")
    ap.add_argument("--link-port", type=int, default=None, help="raw link frames (default 52004)")
    ap.add_argument("--http-host", default="127.0.0.1")
    ap.add_argument("--http-port", type=int, default=None, help="dashboard (default 8088)")
    ap.add_argument("--sim-node0", action="store_true", help="for perf_sim_node0.grc on a one-PC test")
    ap.add_argument("--sim-node1", action="store_true", help="for perf_sim_node1.grc on a one-PC test "
                                                             "(ports 52011-52014, dashboard 8089)")


def resolve_defaults(a):
    pkg = HERE.parent
    base, http, tag, grc = 52000, 8088, "", "perf_hw.grc"
    if getattr(a, "sim_node0", False):
        tag, grc = "_sim_node0", "perf_sim_node0.grc"
    if getattr(a, "sim_node1", False):
        base, http, tag, grc = 52010, 8089, "_sim_node1", "perf_sim_node1.grc"
    for k, off in (("tx_port", 1), ("rx_port", 2), ("tap_port", 3), ("link_port", 4)):
        if getattr(a, k) is None:
            setattr(a, k, base + off)
    if a.http_port is None:
        a.http_port = http
    if a.root is None:
        a.root = str(pkg / f"perf_data{tag}")
    if hasattr(a, "grc") and a.grc is None and (pkg / grc).exists():
        a.grc = str(pkg / grc)
    return a


def api(a, path, body=None):
    url = f"http://127.0.0.1:{a.http_port}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method="POST" if data is not None else "GET",
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())
    except Exception as e:
        sys.exit(f"cannot reach the perf daemon at {url} ({e}) - is `perf_daemon.py run` running?")


def main():
    ap = argparse.ArgumentParser(description="CDP transceiver performance-test daemon")
    sub = ap.add_subparsers(dest="cmd")
    r = sub.add_parser("run", help="run the daemon (default)")
    common_args(r)
    r.add_argument("--grc", default=None, help=".grc file to record in the log (all its parameters go in the report)")
    r.add_argument("--sets-dir", default=None)
    c = sub.add_parser("check", help="connect and print what each tap delivers for 8 s")
    common_args(c)
    s = sub.add_parser("status")
    common_args(s)
    sb = sub.add_parser("submit", help="queue a test on the running daemon")
    common_args(sb)
    sb.add_argument("type", choices=["arq", "link", "plan", "idle", "mark"])
    sb.add_argument("--sizes", default=None, help="comma list of message/payload sizes (bytes)")
    sb.add_argument("--patterns", default=None, help=f"comma list of {','.join(C.PATTERNS)}")
    sb.add_argument("--reps", type=int, default=None)
    sb.add_argument("--count", type=int, default=None)
    sb.add_argument("--set", default=None, help="link test set name (test_sets/*.json)")
    sb.add_argument("--name", default=None, help="plan name (test_sets/*.json)")
    sb.add_argument("--load", type=float, default=None, help="link test offered load 0..1 of the air rate")
    sb.add_argument("--gap", type=float, default=None)
    sb.add_argument("--duration", type=float, default=None)
    sb.add_argument("--text", default=None)
    sb.add_argument("--peer-addr", type=int, default=None)
    argv = sys.argv[1:]
    if not argv or argv[0].startswith("-"):
        argv = ["run"] + argv
    a = resolve_defaults(ap.parse_args(argv))

    if a.cmd == "status":
        st = api(a, "/api/status")
        print(json.dumps({k: st[k] for k in ("node", "peer", "ready", "flowgraph_alive", "current", "queue", "log")}, indent=2))
        print(json.dumps(st["live"]["counters"], indent=2))
        return
    if a.cmd == "submit":
        job = {"type": a.type}
        if a.sizes:
            job["sizes"] = [int(x) for x in a.sizes.split(",")]
        if a.patterns:
            job["patterns"] = a.patterns.split(",")
        for k, v in (("reps", a.reps), ("count", a.count), ("set", a.set), ("name", a.name), ("load", a.load),
                     ("gap_s", a.gap), ("duration_s", a.duration), ("text", a.text), ("peer", a.peer_addr)):
            if v is not None:
                job[k] = v
        print(api(a, "/api/job", job))
        return

    tr = ZmqTransport(a)
    if a.cmd == "check":
        got = collections.Counter()
        first = {}

        def on_tel(rec):
            got[rec.get("tap")] += 1
            first.setdefault(rec.get("tap"), rec)

        def on_app(meta, data):
            got["app_out"] += 1
        tr.start(on_app, on_tel)
        print(f"listening on tap port {a.tap_port} and app port {a.rx_port} for 8 s ...")
        time.sleep(8)
        tr.close()
        if not got:
            print("NOTHING received: is the perf flowgraph running with the same TL_ZMQ_* ports?")
        for k, n in got.most_common():
            print(f"  {k:10s} {n:6d}   e.g. {json.dumps(first.get(k, {}), default=str)[:150]}")
        return

    d = PerfDaemon(a, tr)
    d.say(f"perf daemon {VERSION}: ZMQ app {a.tx_port}/{a.rx_port}, telemetry {a.tap_port}, link {a.link_port}; "
          f"data in {Path(a.root).resolve()}")
    serve_http(d, a.http_host, a.http_port)
    d.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        d.say("stopping")
    finally:
        d.close()


def _sigterm(*_):
    raise KeyboardInterrupt


if __name__ == "__main__":
    import signal
    signal.signal(signal.SIGTERM, _sigterm)
    main()
