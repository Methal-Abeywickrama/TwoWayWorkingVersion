#!/usr/bin/env python3
"""
perf_report.py - hardware performance report for the CDP transceiver from perf_daemon logs.

    python3 perf_report.py perf_logs/node1_*.jsonl node2_from_other_pc.jsonl -o my_report [--title "..."]

Give it the logs of BOTH PCs for the full picture (exact BER of every failed frame, latency,
retransmission causes). One log alone gives a one-sided report.

Writes <out>/report.html (self-contained, charts + tables), report.md, summary.json,
frames.csv (every frame sent), messages.csv (every ARQ test message), packets.csv
(every SR-ARQ DATA packet), config.json (all flowgraph parameters of every node).
"""
import argparse
import base64
import bisect
import collections
import csv
import html
import json
import math
import statistics
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import perf_common as C  # noqa: E402
import perf_svg as S  # noqa: E402

esc = S.esc
BURST_GAP = 8          # error positions closer than this many bits belong to one burst
MATCH_MAX_BER = 0.25   # a failed frame is attributed to a sent frame only below this BER


# =====================================================================
#  Loading
# =====================================================================
class Node:
    def __init__(self, addr):
        self.addr = addr
        self.sessions = []
        self.tel = collections.defaultdict(list)
        self.recs = collections.defaultdict(list)
        self.configs = []

    @property
    def host(self):
        return self.sessions[0]["start"].get("host", "?") if self.sessions else "?"

    @property
    def config(self):
        return self.configs[-1] if self.configs else None

    def spans(self):
        out = []
        for s in self.sessions:
            t0 = s["start"]["t"]
            t1 = s["end"]["t"] if s["end"] else s.get("last_t", t0)
            out.append((t0, t1))
        return out

    def covered(self, t, margin=2.0):
        return any(a - margin <= t <= b + margin for a, b in self.spans())


def load_logs(paths):
    nodes, seen = {}, set()
    for p in paths:
        cur = None
        skip = False
        with open(p, encoding="utf-8", errors="replace") as f:
            for line in f:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                k = r.get("k")
                if k == "session_start":
                    sid = r.get("session")
                    skip = sid in seen
                    seen.add(sid)
                    if skip:
                        continue
                    cur = nodes.setdefault(r["node_addr"], Node(r["node_addr"]))
                    cur.sessions.append({"start": r, "end": None, "file": str(p), "last_t": r["t"]})
                    continue
                if skip or cur is None:
                    continue
                cur.sessions[-1]["last_t"] = r.get("t", cur.sessions[-1]["last_t"])
                if k == "session_end":
                    cur.sessions[-1]["end"] = r
                elif k == "tel":
                    tap = r.get("tap")
                    if tap == "config":
                        cur.configs.append(r)
                    else:
                        cur.tel[tap].append(r)
                else:
                    cur.recs[k].append(r)
    for n in nodes.values():
        for lst in list(n.tel.values()) + list(n.recs.values()):
            lst.sort(key=lambda r: r.get("t", 0))
    return nodes


# =====================================================================
#  Helpers
# =====================================================================
def pct(v, d=1):
    return "–" if v is None else f"{100 * v:.{d}f} %"


def num(v, d=1, unit=""):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "–"
    s = f"{v:,.{d}f}"
    return f"{s} {unit}".strip()


def sci(v):
    if v is None:
        return "–"
    if v == 0:
        return "0"
    return f"{v:.2e}"


def q(vals, p):
    vals = sorted(v for v in vals if v is not None)
    if not vals:
        return None
    k = (len(vals) - 1) * p
    lo = math.floor(k)
    hi = min(lo + 1, len(vals) - 1)
    return vals[lo] + (vals[hi] - vals[lo]) * (k - lo)


def med(vals):
    return q(vals, 0.5)


def sc(v, k):
    """v * k, or None when v is None."""
    return None if v is None else v * k


def mean(vals):
    vals = [v for v in vals if v is not None]
    return sum(vals) / len(vals) if vals else None


def bits_of(b):
    return np.unpackbits(np.frombuffer(b, dtype=np.uint8))


def qfunc(x):
    return 0.5 * math.erfc(x / math.sqrt(2))


def size_bucket(n):
    for lim in (16, 32, 64, 128, 200, 256, 512, 1024, 2048, 4096, 8192):
        if n <= lim:
            return lim
    return 65536


# =====================================================================
#  Physical / link layer: match every received frame to the frame that was sent
# =====================================================================
class Direction:
    def __init__(self, tx, rx):
        self.tx, self.rx = tx, rx
        self.frames = []          # TX frame records with analysis fields
        self.rx_events = []
        self.unmatched_rx = []    # (record, kind) kind = inner | false
        self.d_samples = []       # t_rx - t_tx - airtime  (raw clocks)

    @property
    def name(self):
        return f"{self.tx.addr} → {self.rx.addr}" if self.rx else f"{self.tx.addr} → ?"


def analyse_errors(pos, nbits, body_len):
    hdr_bits = 8 * C.LINK_HDR_BYTES
    pay_end = hdr_bits + 8 * max(body_len - C.LINK_HDR_BYTES - C.CRC_BYTES, 0)
    pos = np.asarray(pos)
    out = {"err_hdr": int(np.sum(pos < hdr_bits)), "err_pay": int(np.sum((pos >= hdr_bits) & (pos < pay_end))),
           "err_crc": int(np.sum(pos >= pay_end)), "bursts": 0, "max_burst": 0, "pairs": 0, "first_err": None}
    if len(pos):
        d = np.diff(pos)
        cuts = np.flatnonzero(d > BURST_GAP)
        starts = np.concatenate(([0], cuts + 1))
        ends = np.concatenate((cuts, [len(pos) - 1]))
        spans = pos[ends] - pos[starts] + 1
        out.update(bursts=int(len(starts)), max_burst=int(spans.max()), pairs=int(np.sum(d == 1)),
                   first_err=round(float(pos[0]) / max(nbits, 1), 4))
    return out


def match_direction(tx, rx, p):
    D = Direction(tx, rx)
    T = [dict(t) for t in tx.tel["link_tx"] if rx is None or t.get("dest") in (rx.addr, 0)]
    for t in T:
        t["_body"] = base64.b64decode(t.get("body", ""))
        t["air"] = t.get("frame_len", C.frame_bytes(t.get("len", 0), p)) * 8 / p["bit_rate"]
        t.update(status=None, rx=None, errors=None, bits=None, sync_err=None, snr=None)
    D.frames = T
    if rx is None:
        for t in T:
            t["status"] = "no_rx_log"
        return D
    R = sorted(rx.tel["link_rx"], key=lambda r: (r["t"], r.get("abs_bit", 0)))
    D.rx_events = R
    # ---- pass 1: good frames (header + first 32 payload bytes identify the sent frame)
    index = collections.defaultdict(list)
    for i, t in enumerate(T):
        b = t["_body"]
        head = b[C.LINK_HDR_BYTES:C.LINK_HDR_BYTES + min(32, t.get("len", 0))]
        index[(t.get("msg_id"), t.get("len"), t.get("dest"), head)].append(i)
        index[(t.get("msg_id"), t.get("len"), t.get("dest"), None)].append(i)      # logs without 'head'
    rmatch = [None] * len(R)
    last = -1
    for ri, r in enumerate(R):
        if r.get("status") != "ok":
            continue
        key = (r.get("msg_id"), r.get("len"), r.get("dest"), base64.b64decode(r["head"]) if "head" in r else None)
        lst = index.get(key)
        if not lst:
            continue
        j = bisect.bisect_right(lst, last)
        if j >= len(lst):
            j = len(lst) - 1
            if T[lst[j]]["status"] is not None:
                continue
        ti = lst[j]
        if T[ti]["status"] is not None:
            continue
        rmatch[ri] = ti
        last = max(last, ti)
        t = T[ti]
        nbits = 32 + 8 * len(t["_body"])
        t.update(status="ok", rx=r, errors=int(r.get("sync_err", 0)), bits=nbits, sync_err=int(r.get("sync_err", 0)),
                 pos=[], partial=False)
    d_ok = [R[ri]["t"] - T[ti]["t"] for ri, ti in enumerate(rmatch) if ti is not None]
    d_est = med(d_ok) if d_ok else 0.0
    # ---- pass 2: failed frames, matched by bit similarity among unmatched sent frames
    prev_ti = [-1] * len(R)
    run = -1
    for ri in range(len(R)):
        prev_ti[ri] = run
        if rmatch[ri] is not None:
            run = max(run, rmatch[ri])
    next_ti = [len(T)] * len(R)
    run = len(T)
    for ri in range(len(R) - 1, -1, -1):
        next_ti[ri] = run
        if rmatch[ri] is not None:
            run = min(run, rmatch[ri])
    t_tx = np.array([t["t"] for t in T]) if T else np.zeros(0)
    for ri, r in enumerate(R):
        if rmatch[ri] is not None or r.get("status") not in ("crc_fail", "bad_len") or not r.get("raw"):
            continue
        raw = base64.b64decode(r["raw"])
        lo, hi = prev_ti[ri] + 1, next_ti[ri]
        cands = [k for k in range(lo, hi) if T[k]["status"] in (None, "crc_fail", "bad_len")]
        if len(cands) > 200:
            cands.sort(key=lambda k: abs(t_tx[k] + d_est - r["t"]))
            cands = cands[:200]
        rb = bits_of(raw)
        best = None
        for k in cands:
            tb = bits_of(T[k]["_body"])
            n = min(len(tb), len(rb))
            if n < 48:
                continue
            x = np.bitwise_xor(tb[:n], rb[:n])
            e = int(x.sum())
            ber = e / n
            if best is None or ber < best[0]:
                best = (ber, k, n, x)
        if best is None or best[0] > MATCH_MAX_BER:
            D.unmatched_rx.append([r, None])
            continue
        ber, k, n, x = best
        t = T[k]
        if t["status"] is not None and t["errors"] - t["sync_err"] <= int(x.sum()):
            D.unmatched_rx.append([r, "inner"])
            continue
        if t["status"] is not None:
            D.unmatched_rx.append([t["rx"], "inner"])
        pos = np.flatnonzero(x)
        se = int(r.get("sync_err", 0))
        t.update(status=r["status"], rx=r, errors=int(len(pos)) + se, bits=32 + n, sync_err=se, pos=pos.tolist(),
                 partial=n < 8 * len(t["_body"]))
        t.update(analyse_errors(pos, n, len(t["_body"])))
    # ---- frames that were never detected, and RX events that match nothing
    for t in T:
        if t["status"] is None:
            t["status"] = "lost" if rx.covered(t["t"] + d_est) else "unobserved"
    spans = sorted((t["rx"]["abs_bit"], t["rx"]["abs_bit"] + 32 + 8 * len(t["_body"]), t["rx"]["t"])
                   for t in T if t["rx"] is not None and "abs_bit" in t["rx"])
    starts = [s[0] for s in spans]
    for u in D.unmatched_rx:
        if u[1] is None:
            r = u[0]
            j = bisect.bisect_right(starts, r.get("abs_bit", -1)) - 1
            u[1] = "inner" if j >= 0 and spans[j][0] <= r.get("abs_bit", -1) < spans[j][1] and abs(spans[j][2] - r["t"]) < 5 else "false"
    for ri, r in enumerate(R):
        if rmatch[ri] is None and r.get("status") == "ok":
            D.unmatched_rx.append([r, "foreign"])
    # ---- joins: per-frame SNR (EVM probe, same abs_bit) and RSSI burst
    evm = collections.defaultdict(list)
    for e in rx.tel["evm"]:
        evm[e.get("abs_bit")].append(e)
    bursts = rx.tel["burst"]
    b_t1 = [b["t1"] for b in bursts]
    for t in T:
        r = t["rx"]
        if r is None:
            continue
        cand = [e for e in evm.get(r.get("abs_bit"), []) if abs(e["t"] - r["t"]) < 10]
        if cand:
            e = min(cand, key=lambda e: abs(e["t"] - r["t"]))
            t.update(snr=e.get("snr_db"), evm_pct=e.get("evm_pct"), drift_hz=e.get("drift_hz"))
        j = bisect.bisect_left(b_t1, r["t"] - t["air"] - 0.5)
        best, ov = None, 0.0
        for b in bursts[j:j + 6]:
            o = min(b["t1"], r["t"]) - max(b["t0"], r["t"] - t["air"] - 0.2)
            if o > ov:
                best, ov = b, o
        if best:
            t.update(rssi_dbfs=best.get("p_dbfs"), rssi_snr=best.get("snr_db"))
        D.d_samples.append(r["t"] - t["t"] - t["air"])
    return D


def clock_offsets(nodes, dirs):
    """offset[n] such that t_corrected = t - offset[n]; reference = lowest address."""
    addrs = sorted(nodes)
    off = {a: 0.0 for a in addrs}
    info = {"method": "single node" if len(addrs) < 2 else "none", "pipeline_s": None}
    if len(addrs) < 2:
        return off, info
    ref = addrs[0]
    for other in addrs[1:]:
        fwd = [d for d in dirs if d.tx.addr == ref and d.rx is not None and d.rx.addr == other]
        bwd = [d for d in dirs if d.tx.addr == other and d.rx is not None and d.rx.addr == ref]
        a = q(sum((d.d_samples for d in fwd), []), 0.1)
        b = q(sum((d.d_samples for d in bwd), []), 0.1)
        if a is not None and b is not None:
            off[other] = (a - b) / 2
            info.update(method="two-way (like NTP), from the earliest-arriving 10 % of frames each way",
                        pipeline_s=(a + b) / 2)
        elif a is not None:
            off[other] = a
            info.update(method="one-way only: receive pipeline delay assumed 0 (offset includes it)")
        elif b is not None:
            off[other] = -b
            info.update(method="one-way only: receive pipeline delay assumed 0 (offset includes it)")
    return off, info


def frame_summary(frames):
    obs = [f for f in frames if f["status"] in ("ok", "crc_fail", "bad_len", "lost")]
    det = [f for f in obs if f["status"] != "lost"]
    failed = [f for f in det if f["status"] != "ok"]
    bits = sum(f["bits"] for f in det)
    errs = sum(f["errors"] for f in det)
    lost_bits = sum(32 + 8 * len(f["_body"]) for f in obs if f["status"] == "lost")
    dens = [f["errors"] / f["bits"] for f in failed if f["bits"]]
    return {"sent": len(frames), "observed": len(obs), "ok": len(det) - len(failed),
            "crc_fail": sum(f["status"] == "crc_fail" for f in det), "bad_len": sum(f["status"] == "bad_len" for f in det),
            "lost": len(obs) - len(det), "unobserved": sum(f["status"] == "unobserved" for f in frames),
            "fer": (len(obs) - (len(det) - len(failed))) / len(obs) if obs else None,
            "fail_rate": len(failed) / len(det) if det else None,
            "loss_rate": (len(obs) - len(det)) / len(obs) if obs else None,
            "bits": bits, "errors": errs, "ber": errs / bits if bits else None,
            "ber_worst": (errs + lost_bits / 2) / (bits + lost_bits) if bits + lost_bits else None,
            "density_mean": mean(dens), "density_max": max(dens) if dens else None,
            "snr_med": med([f.get("snr") for f in det]), "sync_err": sum(f["sync_err"] or 0 for f in det)}


# =====================================================================
#  Transport (SR-ARQ) analysis, from the sender's taps
# =====================================================================
def arq_sessions(node, off_self, rx_node=None, off_rx=0.0):
    sess = collections.OrderedDict()
    events = []
    for r in node.tel["tp_tx"]:
        events.append((r["t"], "tx", r))
    for r in node.tel["tp_rx"]:
        events.append((r["t"], "rx", r))
    events.sort(key=lambda e: e[0])
    peer_rx = collections.defaultdict(list)        # (session, seq) -> corrected times the peer decoded DATA
    if rx_node is not None:
        for r in rx_node.tel["tp_rx"]:
            m = r.get("meta", {})
            if m.get("pkt_type") == "DATA":
                peer_rx[(m.get("session_id"), m.get("seq_no"))].append(r["t"] - off_rx)
    for t, kind, r in events:
        m = r.get("meta", {})
        sid = m.get("session_id")
        pt = m.get("pkt_type")
        if kind == "tx" and pt == "SYN" and sid not in sess:
            sess[sid] = {"sid": sid, "t_syn": t, "syn_tx": 0, "t_synack": None, "data": [], "slots": {}, "fin_tx": 0,
                         "t_fin": None, "t_finack": None, "total_pkts": m.get("total_pkts"), "dup_ack": 0,
                         "tx_bytes": 0, "tx_frames": 0, "air": 0.0}
        s = sess.get(sid)
        if s is None:
            continue
        if kind == "tx":
            s["tx_frames"] += 1
            s["tx_bytes"] += r.get("len", 0) + C.TP_HDR_BYTES
            if pt == "SYN":
                s["syn_tx"] += 1
            elif pt == "FIN":
                s["fin_tx"] += 1
                s["t_fin"] = s["t_fin"] or t
            elif pt == "DATA":
                slot = m.get("seq_no")
                cur = s["slots"].get(slot)
                if cur is not None and cur["t_ack"] is None:
                    cur["tx"] += 1
                    cur["tx_times"].append(t)
                    if rx_node is not None:
                        got = [x for x in peer_rx.get((sid, slot), []) if cur["t0"] - off_self - 0.01 <= x <= t - off_self]
                        cur["causes"].append("ack lost/late" if got else "data lost")
                else:
                    cur = {"slot": slot, "len": r.get("len", 0), "t0": t, "tx": 1, "tx_times": [t], "t_ack": None,
                           "causes": []}
                    s["slots"][slot] = cur
                    s["data"].append(cur)
        else:
            if pt == "SYN_ACK" and s["t_synack"] is None:
                s["t_synack"] = t
            elif pt == "ACK":
                cur = s["slots"].get(m.get("seq_no"))
                if cur is not None and cur["t_ack"] is None:
                    cur["t_ack"] = t
                else:
                    s["dup_ack"] += 1
            elif pt == "FIN_ACK" and s["t_finack"] is None:
                s["t_finack"] = t
    return list(sess.values())


def arq_messages(node, sessions, p, rx_node, off_tx, off_rx):
    sends = collections.defaultdict(list)
    for r in node.recs["app_send"]:
        sends[(r["run"], r["idx"])].append(r)
    results = collections.defaultdict(list)
    for r in node.recs["app_result"]:
        results[(r["run"], r["idx"])].append(r)
    delivered = {}
    if rx_node is not None:
        for r in rx_node.recs["app_rx"]:
            if r.get("perf"):
                delivered.setdefault((r["run"], r["idx"]), r)
    syn_times = [s["t_syn"] for s in sessions]
    msgs = []
    for key, sl in sends.items():
        last = sl[-1]
        res = [r for r in results.get(key, []) if r.get("attempt") == last.get("attempt")]
        res = res[-1] if res else None
        m = {"run": key[0], "idx": key[1], "job": last["job"], "size": last["size"], "pattern": last["pattern"],
             "n_pkts": last["n_pkts"], "frame_len": last["frame_len"], "attempts": len(sl), "t_send": last["t"],
             "event": res["event"] if res else "no result", "t_done": res["t"] if res else None}
        m["time_s"] = (m["t_done"] - m["t_send"]) if m["t_done"] else None
        j = bisect.bisect_left(syn_times, last["t"] - 0.05)
        s = sessions[j] if j < len(sessions) and (m["t_done"] is None or sessions[j]["t_syn"] <= m["t_done"]) else None
        if s:
            data = s["data"]
            m.update(session=s["sid"], syn_tx=s["syn_tx"], fin_tx=s["fin_tx"],
                     handshake_s=(s["t_synack"] - s["t_syn"]) if s["t_synack"] else None,
                     data_pkts=len(data), data_tx=sum(d["tx"] for d in data),
                     retx=sum(d["tx"] - 1 for d in data),
                     rtt_med=med([d["t_ack"] - d["t0"] for d in data if d["t_ack"] and d["tx"] == 1]),
                     fin_s=(s["t_finack"] - s["t_fin"]) if s["t_finack"] and s["t_fin"] else None,
                     fin_acked=s["t_finack"] is not None, tx_frames=s["tx_frames"],
                     air_s=sum(C.airtime(C.TP_HDR_BYTES + d["len"], p) * d["tx"] for d in data)
                     + (s["syn_tx"] + s["fin_tx"]) * C.airtime(C.TP_HDR_BYTES, p))
            m["bytes_on_air"] = sum(C.frame_bytes(C.TP_HDR_BYTES + d["len"], p) * d["tx"] for d in data) \
                + (s["syn_tx"] + s["fin_tx"]) * C.frame_bytes(C.TP_HDR_BYTES, p)
        if m["event"] == "tx_done" and m["time_s"]:
            m["goodput_bps"] = m["size"] * 8 / m["time_s"]
            m["util"] = m.get("air_s", 0) / m["time_s"] if m.get("air_s") else None
        dl = delivered.get(key)
        if rx_node is not None:
            m["delivered"] = bool(dl and dl.get("ok"))
            m["content_ok"] = dl.get("ok") if dl else None
            if dl:
                m["latency_s"] = (dl["t"] - off_rx) - (m["t_send"] - off_tx)
        msgs.append(m)
    msgs.sort(key=lambda m: m["t_send"])
    return msgs


def ideal_arq_time(size, p, name_len=30):
    flen = C.app_frame_len(name_len, size)
    n = C.n_packets(flen, p["mtu"])
    last = flen - (n - 1) * p["mtu"]
    a = lambda L: C.airtime(C.TP_HDR_BYTES + L, p)
    return 2 * a(0) + (n - 1) * a(p["mtu"]) + a(last) + a(0) + 2 * a(0)


# =====================================================================
#  Report
# =====================================================================
CSS = """
:root{color-scheme:light;--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;--grid:#e1e0d9;
--axis:#c3c2b7;--ring:rgba(11,11,11,.10);--s1:#2a78d6;--s2:#eb6834;--s3:#1baf7a;--theory:#898781;--good:#0ca30c;--warn:#fab219;--crit:#d03b3b}
@media (prefers-color-scheme:dark){:root:where(:not([data-theme="light"])){color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;--ink:#fff;
--ink2:#c3c2b7;--grid:#2c2c2a;--axis:#383835;--ring:rgba(255,255,255,.10);--s1:#3987e5;--s2:#d95926;--s3:#199e70;--theory:#898781}}
:root[data-theme="dark"]{color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;--ink:#fff;--ink2:#c3c2b7;--grid:#2c2c2a;--axis:#383835;
--ring:rgba(255,255,255,.10);--s1:#3987e5;--s2:#d95926;--s3:#199e70;--theory:#898781}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1180px;margin:0 auto;padding:24px 20px 60px}h1{font-size:24px;margin:0 0 4px}h2{font-size:18px;margin:36px 0 10px;
padding-top:12px;border-top:1px solid var(--ring)}h3{font-size:14px;margin:0 0 6px}.sub{color:var(--ink2);margin:0 0 18px}
.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;margin:14px 0}
.tile{background:var(--surface);border:1px solid var(--ring);border-radius:10px;padding:12px 14px}.tile .l{font-size:12px;color:var(--ink2)}
.tile .v{font-size:24px;font-weight:620;margin:2px 0}.tile .s{font-size:12px;color:var(--muted)}
.chart{background:var(--surface);border:1px solid var(--ring);border-radius:10px;padding:14px 16px;margin:12px 0}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:900px){.grid2{grid-template-columns:1fr}}
.legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:var(--ink2);margin:0 0 6px}.lg{display:inline-flex;gap:6px;align-items:center}
table{border-collapse:collapse;width:100%;font-size:13px;margin:6px 0}th,td{padding:5px 8px;border-bottom:1px solid var(--grid);text-align:left;vertical-align:top}
th{color:var(--ink2);font-weight:600}td.n{text-align:right;font-variant-numeric:tabular-nums}.wrap{overflow-x:auto}
details.tv{margin-top:6px;font-size:12px}details.tv summary{color:var(--ink2);cursor:pointer}.note,.empty{font-size:12px;color:var(--muted);margin:6px 0 0}
.status{display:inline-flex;gap:6px;align-items:center;font-weight:600}.status i{width:9px;height:9px;border-radius:50%;display:inline-block}
.rec{background:var(--surface);border:1px solid var(--ring);border-left-width:4px;border-radius:8px;padding:10px 14px;margin:8px 0}
.rec.warn{border-left-color:var(--warn)}.rec.crit{border-left-color:var(--crit)}.rec.good{border-left-color:var(--good)}
code{font:12px ui-monospace,SFMono-Regular,Menlo,monospace}.toc a{color:var(--ink2);margin-right:12px;font-size:13px}
.pt:hover circle:last-of-type,.bar:hover path{opacity:.8}
"""


class Report:
    def __init__(self, title):
        self.h = []
        self.md = []
        self.title = title

    def sec(self, anchor, title, intro=None):
        self.h.append(f'<h2 id="{anchor}">{esc(title)}</h2>')
        self.md.append(f"\n## {title}\n")
        if intro:
            self.h.append(f'<p class="sub">{esc(intro)}</p>')
            self.md.append(intro + "\n")

    def p(self, text):
        self.h.append(f"<p>{esc(text)}</p>")
        self.md.append(text + "\n")

    def raw(self, h, md=None):
        self.h.append(h)
        if md:
            self.md.append(md)

    def tiles(self, items):
        self.h.append('<div class="tiles">' + "".join(
            f'<div class="tile"><div class="l">{esc(l)}</div><div class="v">{esc(v)}</div><div class="s">{esc(s or "")}</div></div>'
            for l, v, s in items) + "</div>")
        self.md += [f"- **{l}:** {v}" + (f" ({s})" if s else "") for l, v, s in items]
        self.md.append("")

    def table(self, headers, rows, num_cols=None, md=True):
        num_cols = set(range(1, len(headers))) if num_cols is None else set(num_cols)
        out = ['<div class="wrap"><table><thead><tr>'] + [f"<th>{esc(h)}</th>" for h in headers] + ["</tr></thead><tbody>"]
        for r in rows:
            out.append("<tr>" + "".join(f'<td class="n">{esc(c)}</td>' if i in num_cols else f"<td>{esc(c)}</td>"
                                        for i, c in enumerate(r)) + "</tr>")
        out.append("</tbody></table></div>")
        self.h.append("".join(out))
        if md and rows:
            self.md.append("| " + " | ".join(headers) + " |")
            self.md.append("|" + "---|" * len(headers))
            self.md += ["| " + " | ".join(str(c).replace("|", "/") for c in r) + " |" for r in rows]
            self.md.append("")

    def chart(self, svg_html):
        self.h.append(svg_html)

    def rec(self, level, text):
        icon = {"good": "✓", "warn": "!", "crit": "✕"}[level]
        word = {"good": "OK", "warn": "Check", "crit": "Problem"}[level]
        self.h.append(f'<div class="rec {level}"><span class="status"><i style="background:var(--{level})"></i>'
                      f'{icon} {word}</span> {esc(text)}</div>')
        self.md.append(f"- **{word}:** {text}")

    def html(self, subtitle, toc):
        nav = "".join(f'<a href="#{a}">{esc(t)}</a>' for a, t in toc)
        return (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" '
                f'content="width=device-width,initial-scale=1"><title>{esc(self.title)}</title><style>{CSS}</style></head>'
                f'<body><main><h1>{esc(self.title)}</h1><p class="sub">{esc(subtitle)}</p><p class="toc">{nav}</p>'
                + "\n".join(self.h) + "</main></body></html>")


def fmt_t(t):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t)) + f".{int((t % 1) * 1000):03d}"


def build_report(paths, out_dir, title=None):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    nodes = load_logs(paths)
    if not nodes:
        raise ValueError("no perf_daemon sessions found in the given logs")
    addrs = sorted(nodes)
    params = {a: C.link_params(nodes[a].config) for a in addrs}
    p0 = params[addrs[0]]

    # ---------------- physical / link analysis, every direction
    dirs = []
    for a in addrs:
        n = nodes[a]
        if not n.tel["link_tx"]:
            continue
        dests = {t.get("dest") for t in n.tel["link_tx"]}
        rxs = [nodes[d] for d in sorted(dests) if d in nodes and d != a] or [None]
        if 0 in dests:
            rxs = [nodes[b] for b in addrs if b != a] or [None]
        for rxn in rxs:
            dirs.append(match_direction(n, rxn, params[a]))
    off, clk = clock_offsets(nodes, dirs)

    # ---------------- jobs
    jobs = []
    for a in addrs:
        n = nodes[a]
        ends = {r["job"]: r for r in n.recs["job_end"]}
        for s in n.recs["job_start"]:
            e = ends.get(s["job"])
            jobs.append({"node": a, "job": s["job"], "run": s["run"], "type": s["type"], "params": s.get("params", {}),
                         "t0": s["t"], "t1": e["t"] if e else None, "status": e["status"] if e else "unfinished",
                         "summary": e.get("summary", {}) if e else {}})
    jobs.sort(key=lambda j: j["t0"] - off[j["node"]])

    # ---------------- link tests
    link_rows, item_stats = [], []
    for d in dirs:
        sends = {}
        for r in d.tx.recs["link_send"]:
            sends[(r["run"], r["seq"])] = r
        for j in [j for j in jobs if j["type"] == "link" and j["node"] == d.tx.addr]:
            fr = [f for f in d.frames if f.get("perf_job") == j["run"]]
            items = collections.OrderedDict()
            for f in fr:
                s = sends.get((j["run"], f.get("perf_seq")), {})
                items.setdefault((s.get("item"), s.get("size", f["len"]), s.get("pattern", "?")), []).append(f)
            for (item, size, pattern), fs in items.items():
                st = frame_summary(fs)
                ok = [f for f in fs if f["status"] == "ok"]
                thr = None
                if len(ok) >= 2:
                    span = ok[-1]["rx"]["t"] - ok[0]["rx"]["t"] + ok[0]["air"]
                    thr = sum(8 * f["len"] for f in ok) / span if span > 0 else None
                tx_span = fs[-1]["t"] - fs[0]["t"] + fs[-1]["air"] if fs else None
                rec = {"dir": d.name, "job": j["job"], "set": j["params"].get("set") or "custom", "item": item,
                       "size": size, "pattern": pattern, "load": j["params"].get("load"), **st,
                       "rx_throughput_bps": thr, "max_link_bps": size * 8 / C.airtime(size, params[d.tx.addr]),
                       "tx_duty": sum(f["air"] for f in fs) / tx_span if tx_span else None}
                item_stats.append(rec)

    # ---------------- ARQ
    arq = {}
    for a in addrs:
        n = nodes[a]
        if not n.recs["app_send"]:
            continue
        peer_addr = n.sessions[0]["start"].get("peer_addr")
        rxn = nodes.get(peer_addr)
        sess = arq_sessions(n, off[a], rxn, off.get(peer_addr, 0.0))
        msgs = arq_messages(n, sess, params[a], rxn, off[a], off.get(peer_addr, 0.0))
        pk = [dict(d, sid=s["sid"]) for s in sess for d in s["data"]]
        arq[a] = {"sessions": sess, "messages": msgs, "packets": pk, "peer": peer_addr, "rx_log": rxn is not None}

    # ================= write report
    rep = Report(title or "CDP transceiver — hardware performance report")
    toc = [("summary", "Summary"), ("setup", "Setup"), ("params", "Parameters"), ("capacity", "Capacity"), ("phy", "Physical layer"),
           ("link", "Link BER tests"), ("errors", "Error analysis"), ("arq", "SR-ARQ"), ("app", "Application"),
           ("rf", "RF"), ("timeline", "Timeline"), ("recs", "Findings"), ("config", "Flowgraph parameters")]
    all_frames = [f for d in dirs for f in d.frames]
    summ = {"generated": time.time(), "logs": [str(p) for p in paths], "nodes": {}, "directions": {}, "clock": clk,
            "offsets": off}

    # ---------- summary tiles
    rep.sec("summary", "Summary", "Headline numbers; every number below is broken down further in its section.")
    tiles = [("PHY bit rate (air)", num(p0["bit_rate"] / 1e3, 1, "kb/s"),
              f"{p0['samp_rate'] / 1e6:g} MS/s ÷ {p0['sps']:g} sps, BPSK")]
    thr = [s["rx_throughput_bps"] for s in item_stats if s["rx_throughput_bps"]]
    if thr:
        best = max(item_stats, key=lambda s: s["rx_throughput_bps"] or 0)
        tiles.append(("Max link throughput measured", num(best["rx_throughput_bps"] / 1e3, 1, "kb/s"),
                      f"{best['size']} B frames, load {best['load']}, {best['dir']}"))
    gp = [m for v in arq.values() for m in v["messages"] if m.get("goodput_bps")]
    if gp:
        b = max(gp, key=lambda m: m["goodput_bps"])
        tiles.append(("Max app goodput (SR-ARQ)", num(b["goodput_bps"] / 1e3, 2, "kb/s"), f"{b['size']} B message"))
    for d in dirs:
        st = frame_summary(d.frames)
        summ["directions"][d.name] = {k: v for k, v in st.items()}
        if st["observed"]:
            tiles.append((f"BER {d.name}", sci(st["ber"]), f"{st['errors']:,} errors / {st['bits']:,} bits"))
            tiles.append((f"Frame error rate {d.name}", pct(st["fer"], 2),
                          f"{st['crc_fail'] + st['bad_len']} failed + {st['lost']} lost of {st['observed']}"))
    pk_all = [x for v in arq.values() for x in v["packets"]]
    if pk_all:
        retx = sum(x["tx"] - 1 for x in pk_all)
        tiles.append(("Retransmission rate", pct(retx / len(pk_all), 1), f"{retx} retx / {len(pk_all)} DATA packets"))
    snrs = [f.get("snr") for f in all_frames if f.get("snr") is not None]
    if snrs:
        tiles.append(("SNR from EVM (median)", num(med(snrs), 1, "dB"), f"p10 {num(q(snrs, .1), 1)} · p90 {num(q(snrs, .9), 1)} dB"))
    obw = [r.get("obw99_hz") for a in addrs for r in nodes[a].tel["rssi"] if r.get("obw99_hz") and r.get("busy_pct", 0) >= 20]
    tiles.append(("Occupied bandwidth", num(med(obw) / 1e3, 0, "kHz") if obw else "–",
                  f"theory (1+α)·Rs = {p0['bit_rate'] * (1 + p0['alpha']) / 1e3:.0f} kHz"))
    rtts = [x["t_ack"] - x["t0"] for x in pk_all if x["t_ack"] and x["tx"] == 1]
    if rtts:
        tiles.append(("DATA→ACK round trip (median)", num(1e3 * med(rtts), 0, "ms"), f"p95 {num(1e3 * q(rtts, .95), 0)} ms"))
    msgs_all = [m for v in arq.values() for m in v["messages"]]
    if msgs_all:
        okm = sum(m["event"] == "tx_done" for m in msgs_all)
        tiles.append(("ARQ messages completed", f"{okm} / {len(msgs_all)}",
                      f"{sum(1 for m in msgs_all if m.get('content_ok'))} verified byte-exact at the receiver"
                      if any(v["rx_log"] for v in arq.values()) else "receiver log not included"))
    rep.tiles(tiles)

    # ---------- setup
    rep.sec("setup", "Test setup", "Who logged what, and how the two clocks were aligned.")
    rows = []
    for a in addrs:
        n = nodes[a]
        for s in n.sessions:
            st = s["start"]
            rows.append([a, st.get("host"), Path(s["file"]).name, fmt_t(st["t"]),
                         fmt_t(s["end"]["t"]) if s["end"] else f"(no end marker) last {fmt_t(s['last_t'])}",
                         st.get("clock", {}).get("ntp", {}).get("NTPSynchronized", "?"), num(off[a] * 1e3, 1, "ms")])
    rep.table(["Node", "Host", "Log", "Program start", "Program end", "NTP synced", "Clock offset vs ref"], rows, num_cols=[6])
    kp = {a: C.key_parameters(nodes[a].config, nodes[a].sessions[-1]["start"].get("grc")) for a in addrs}
    order = []
    for a in addrs:
        for grp, k, _v in kp[a]:
            if (grp, k) not in order:
                order.append((grp, k))
    if order:
        rep.raw('<h3 id="params">Key radio, modem and protocol parameters</h3>',
                "\n### Key radio, modem and protocol parameters\n")
        vals = {a: {(g, k): val for g, k, val in kp[a]} for a in addrs}
        rows = []
        for g, k in order:
            vs = [vals[a].get((g, k), "–") for a in addrs]
            rows.append([g, k] + vs + (["≠" if len(set(vs)) > 1 and g not in ("Node", "Radio") else ""]
                                       if len(addrs) > 1 else []))
        rep.table(["Group", "Parameter"] + [f"Node {a}" for a in addrs] + (["Differs"] if len(addrs) > 1 else []),
                  rows, num_cols=[])
        summ["key_parameters"] = {a: kp[a] for a in addrs}
    rep.p(f"Clock alignment: {clk['method']}."
          + (f" Estimated one-way receive pipeline delay (framer → deframer minus air time): {clk['pipeline_s'] * 1e3:.1f} ms."
             if clk.get("pipeline_s") is not None else ""))
    jrows = [[j["job"], j["node"], j["type"], j["params"].get("set") or j["params"].get("plan") or "",
              fmt_t(j["t0"]), num((j["t1"] - j["t0"]) if j["t1"] else None, 1, "s"), j["status"],
              json.dumps(j["summary"])[:90]] for j in jobs]
    rep.table(["Job", "Node", "Type", "Set / plan", "Start", "Duration", "Status", "Result"], jrows, num_cols=[5])

    # ---------- capacity
    rep.sec("capacity", "Theoretical capacity of this configuration",
            "What the flowgraph parameters allow at best. The fixed per-burst overhead (preamble, sync, header, CRC, "
            "postamble) sets the ceiling for short frames.")
    p = p0
    ovh = p["preamble_len"] + C.SYNC_BYTES + C.LINK_HDR_BYTES + C.CRC_BYTES + p["postamble_len"]
    rep.tiles([("Symbol rate", num(p["bit_rate"] / 1e3, 1, "kBd"), f"samp_rate {p['samp_rate'] / 1e6:g} MS/s, sps {p['sps']:g}"),
               ("Raw bit rate", num(p["bit_rate"] / 1e3, 1, "kb/s"), "BPSK, 1 bit/symbol"),
               ("Occupied bandwidth (theory)", num(p["bit_rate"] * (1 + p["alpha"]) / 1e3, 0, "kHz"), f"RRC α = {p['alpha']:g}"),
               ("Spectral efficiency", num(1 / (1 + p["alpha"]), 2, "b/s/Hz"), "raw bits per Hz"),
               ("Overhead per burst", f"{ovh:,} B", f"preamble {p['preamble_len']} B + postamble {p['postamble_len']} B + 14 B"),
               ("Burst air time, 200 B", num(C.airtime(200, p) * 1e3, 1, "ms"), f"{C.frame_bytes(200, p):,} B on air")])
    sizes = [16, 32, 64, 128, 200, 256, 512, 1024, 2048, 4096, 8192]
    cap_rows = []
    for s_ in sizes:
        ta = C.airtime(s_, p)
        it = ideal_arq_time(s_, p)
        cap_rows.append([s_, num(ta * 1e3, 1), num(s_ * 8 / ta / 1e3, 1), pct(s_ / C.frame_bytes(s_, p), 1),
                         C.n_packets(C.app_frame_len(30, s_), p["mtu"]), num(s_ * 8 / it / 1e3, 2)])
    rep.table(["Payload (B)", "Burst air time (ms)", "Max link throughput (kb/s)", "Air efficiency",
               f"ARQ packets (MTU {p['mtu']})", "ARQ ideal goodput (kb/s)"], cap_rows)

    # ---------- physical layer
    rep.sec("phy", "Physical layer: every burst, every direction",
            "Each burst handed to the modulator is matched to what the other node's deframer decided. ok = CRC passed; "
            "crc_fail = sync found, CRC wrong; bad_len = sync found, header length impossible; lost = no sync detected "
            "while the receiver was logging. BER counts sync-word + header + payload + CRC bits of detected bursts; "
            "'worst case' also counts lost bursts at 50 %.")
    rows = []
    for d in dirs:
        st = frame_summary(d.frames)
        rows.append([d.name, st["sent"], st["observed"], st["ok"], st["crc_fail"], st["bad_len"], st["lost"],
                     pct(st["fer"], 2), sci(st["ber"]), sci(st["ber_worst"]), sci(st["density_mean"]),
                     num(st["snr_med"], 1), st["sync_err"]])
    rep.table(["Direction", "Sent", "Observed", "OK", "CRC fail", "Bad len", "Lost", "FER", "BER", "BER worst",
               "Mean err. density (failed)", "SNR med (dB)", "Sync-word bit errors"], rows)
    fs_rows = []
    for d in dirs:
        kinds = collections.Counter(u[1] for u in d.unmatched_rx)
        fs_rows.append([d.name, kinds.get("false", 0), kinds.get("inner", 0), kinds.get("foreign", 0)])
    rep.table(["Direction", "False syncs (noise)", "Re-syncs inside a failed frame", "Good frames from unknown sender"], fs_rows)
    # FER / BER vs size, all frames, per direction
    series_fer, series_ber = [], []
    for d in dirs:
        bysz = collections.defaultdict(list)
        for f in d.frames:
            bysz[size_bucket(f["len"])].append(f)
        fer_pts, ber_pts = [], []
        for sz in sorted(bysz):
            st = frame_summary(bysz[sz])
            if st["observed"] >= 3:
                fer_pts.append((sz, st["fer"]))
                if st["ber"]:
                    ber_pts.append((sz, st["ber"]))
        series_fer.append({"name": d.name, "points": fer_pts})
        series_ber.append({"name": d.name, "points": ber_pts})
    rep.raw('<div class="grid2">')
    rep.chart(S.line_chart(series_fer, "Frame error rate vs payload size (all bursts)", "payload size, bytes (bucket upper edge)",
                           "frame error rate", logx=True, ylo=0, yhi=max([y for s in series_fer for _, y in s["points"]] + [0.05])))
    rep.chart(S.line_chart(series_ber, "Bit error rate vs payload size (detected bursts)", "payload size, bytes (bucket upper edge)",
                           "BER", logx=True, logy=True, note="Buckets with zero bit errors are not drawn (see table)."))
    rep.raw("</div>")
    # BER vs SNR with theory
    snr_bins = collections.defaultdict(lambda: [0, 0, 0, 0])
    for f in all_frames:
        if f.get("snr") is not None and f["bits"]:
            b = snr_bins[round(f["snr"])]
            b[0] += f["errors"]
            b[1] += f["bits"]
            b[2] += 1
            b[3] += f["status"] != "ok"
    if snr_bins:
        ks = sorted(snr_bins)
        meas = [(k, snr_bins[k][0] / snr_bins[k][1]) for k in ks if snr_bins[k][0] > 0]
        fer_s = [(k, snr_bins[k][3] / snr_bins[k][2]) for k in ks]
        xs = np.arange(min(ks) - 1, max(ks) + 1.01, 0.25)
        th1 = [(float(x), 2 * qfunc(math.sqrt(2 * 10 ** (x / 10)))) for x in xs]
        th2 = [(float(x), 0.5 * math.exp(-10 ** (x / 10))) for x in xs]
        rep.raw('<div class="grid2">')
        rep.chart(S.line_chart([{"name": "measured", "points": meas},
                                {"name": "coherent BPSK + diff. decoding", "points": th1, "theory": True, "label_end": False},
                                {"name": "non-coherent DBPSK", "points": th2, "theory": True, "label_end": False}],
                               "BER vs per-burst SNR (EVM)", "SNR from EVM, dB (1 dB bins)", "BER", logy=True,
                               ylo=1e-7, yhi=0.5, note="SNR from EVM includes every impairment (phase noise, ISI, residual "
                               "CFO), so the measured curve sits right of the theory by the implementation loss. Below ~7 dB the "
                               "decision-directed SNR reads high and bursts that lose sync are missing, so measured BER "
                               "can sit left of the theory there."))
        rep.chart(S.line_chart([{"name": "FER", "points": fer_s}], "Frame error rate vs per-burst SNR",
                               "SNR from EVM, dB", "frame error rate", ylo=0, yhi=1))
        rep.raw("</div>")
        rep.table(["SNR bin (dB)", "Bursts", "Failed", "Bits", "Bit errors", "BER"],
                  [[k, snr_bins[k][2], snr_bins[k][3], f"{snr_bins[k][1]:,}", snr_bins[k][0],
                    sci(snr_bins[k][0] / snr_bins[k][1])] for k in sorted(snr_bins)])
    lat = [(f["rx"]["t"] - off[d.rx.addr]) - (f["t"] - off[d.tx.addr]) for d in dirs if d.rx for f in d.frames if f["rx"]]
    if lat:
        rep.p(f"Burst delivery latency (framer → deframer decision, clock-corrected, includes TX queueing and air time): "
              f"median {med(lat) * 1e3:.1f} ms, p95 {q(lat, .95) * 1e3:.1f} ms, max {max(lat) * 1e3:.1f} ms.")

    # ---------- link tests
    rep.sec("link", "Link BER tests (message sets, no ARQ)",
            "Raw frames from the perf daemon straight into the framer; every frame sent exactly once. "
            "Throughput = delivered payload bits ÷ time between first and last good frame at the receiver.")
    if item_stats:
        rows = [[s["dir"], s["job"], s["set"], s["size"], s["pattern"], s["load"], s["sent"], s["ok"],
                 s["crc_fail"] + s["bad_len"], s["lost"], pct(s["fer"], 1), sci(s["ber"]), sci(s["density_mean"]),
                 sci(s["density_max"]), num(s["snr_med"], 1),
                 num(s["rx_throughput_bps"] / 1e3 if s["rx_throughput_bps"] else None, 1),
                 num(s["max_link_bps"] / 1e3, 1)] for s in item_stats]
        rep.table(["Dir", "Job", "Set", "Size (B)", "Pattern", "Load", "Sent", "OK", "Failed", "Lost", "FER", "BER",
                   "Err. density mean", "Err. density max", "SNR (dB)", "Throughput (kb/s)", "Max possible (kb/s)"],
                  rows, num_cols=[3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
        rnd = [s for s in item_stats if s["pattern"] == "random"]
        by_dir = collections.defaultdict(list)
        for s in rnd:
            by_dir[s["dir"]].append(s)
        rep.raw('<div class="grid2">')
        rep.chart(S.line_chart([{"name": f"{k} measured", "points": [(s["size"], s["rx_throughput_bps"] / 1e3) for s in v
                                                                   if s["rx_throughput_bps"]]} for k, v in by_dir.items()]
                               + [{"name": "max possible", "theory": True,
                                   "points": [(x, x * 8 / C.airtime(x, p) / 1e3) for x in sizes]}],
                               "Link throughput vs frame size (random payload)", "payload bytes", "kb/s", logx=True, ylo=0))
        pats = collections.defaultdict(list)
        for s in item_stats:
            pats[s["pattern"]].append(s)
        cats = list(pats)
        vals = [sum(x["crc_fail"] + x["bad_len"] + x["lost"] for x in pats[c]) / max(sum(x["observed"] for x in pats[c]), 1)
                for c in cats]
        rep.chart(S.bar_chart(cats, [{"name": "FER", "values": vals}],
                              "Frame error rate by payload content", "frame error rate", fmt=lambda v: f"{100 * v:.1f}%"))
        rep.raw("</div>")
    else:
        rep.p("No link test jobs in these logs.")
    # receiver-only view
    for a in addrs:
        n = nodes[a]
        runs = collections.defaultdict(lambda: {"ok": set(), "fail": set(), "bits": 0, "err": 0})
        for r in n.tel["link_rx"]:
            if r.get("status") == "ok" and r.get("head"):
                info = C.parse_link_payload(base64.b64decode(r["head"]) + bytes(32))
                if info:
                    runs[info["run"]]["ok"].add(info["seq"])
            elif r.get("raw"):
                raw = base64.b64decode(r["raw"])
                info = C.parse_link_payload(raw[C.LINK_HDR_BYTES:])
                if info and info["run"] in runs:
                    exp = C.expected_link_payload(info)
                    got = raw[C.LINK_HDR_BYTES:C.LINK_HDR_BYTES + len(exp)]
                    k = min(len(exp), len(got))
                    runs[info["run"]]["fail"].add(info["seq"])
                    runs[info["run"]]["bits"] += 8 * k
                    runs[info["run"]]["err"] += int(np.bitwise_xor(bits_of(exp[:k]), bits_of(got[:k])).sum())
        known_tx = {j["run"] for j in jobs if j["type"] == "link"}
        rr = [[a, run, len(v["ok"]), len(v["fail"] - v["ok"]), max(v["ok"] | v["fail"]) + 1 - len(v["ok"] | v["fail"]),
               sci(v["err"] / v["bits"] if v["bits"] else None), "yes" if run in known_tx else "no (sender log missing)"]
              for run, v in runs.items()]
        if rr:
            rep.raw("<h3>Receiver-only view (from the receiving node's log alone)</h3>", "\n### Receiver-only view\n")
            rep.table(["RX node", "Run", "OK", "Failed (header readable)", "Missing (lost or unreadable)",
                       "Payload BER of failed", "Sender log present"], rr, num_cols=[1, 2, 3, 4, 5])

    # ---------- error analysis
    rep.sec("errors", "Error analysis of failed bursts",
            "Per failed burst: error density = bit errors ÷ compared bits. A burst = errors closer than "
            f"{BURST_GAP} bits. In differential BPSK one wrong symbol gives two adjacent bit errors (a pair).")
    failed = [f for f in all_frames if f["status"] in ("crc_fail", "bad_len") and f.get("pos") is not None]
    if failed:
        dens = [f["errors"] / f["bits"] for f in failed]
        prof = np.zeros(20)
        for f in failed:
            for x in f["pos"]:
                prof[min(19, int(20 * x / max(f["bits"] - 32, 1)))] += 1
        pairs = sum(f.get("pairs", 0) for f in failed)
        errs = sum(len(f["pos"]) for f in failed)
        rep.tiles([("Failed bursts analysed", f"{len(failed):,}", f"{sum(f.get('partial', False) for f in failed)} partial (bad length)"),
                   ("Error density median", sci(med(dens)), f"max {sci(max(dens))}"),
                   ("Errors per failed burst (median)", num(med([len(f['pos']) for f in failed]), 0), ""),
                   ("Error bursts per failed frame", num(mean([f.get("bursts", 0) for f in failed]), 2),
                    f"longest burst {max(f.get('max_burst', 0) for f in failed)} bits"),
                   ("Errors in adjacent pairs", pct(2 * pairs / errs if errs else None), "≈100 % = isolated symbol errors"),
                   ("Where (hdr / payload / CRC)", f"{sum(f.get('err_hdr', 0) for f in failed)} / "
                    f"{sum(f.get('err_pay', 0) for f in failed)} / {sum(f.get('err_crc', 0) for f in failed)}", "bit errors")])
        hist_edges = [1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1]
        cats = ["<1e-4", "1e-4–1e-3", "1e-3–1e-2", "1e-2–0.1", "≥0.1"]
        hv = [sum(1 for x in dens if lo <= x < hi) for lo, hi in zip([0] + hist_edges[1:-1], hist_edges[1:])]
        rep.raw('<div class="grid2">')
        rep.chart(S.bar_chart(cats, [{"name": "failed bursts", "values": hv}], "Error density per failed burst",
                              "number of bursts", fmt=lambda v: f"{v:.0f}"))
        rep.chart(S.bar_chart([f"{5 * i}" for i in range(20)], [{"name": "bit errors", "values": prof.tolist()}],
                              "Where in the burst the errors are (% of burst after sync)", "bit errors",
                              fmt=lambda v: f"{v:.0f}",
                              note="Rising to the right = timing/phase drift during long bursts; at the left = preamble "
                                   "too short for the loops/AGC to settle."))
        rep.raw("</div>")
        worst = sorted(failed, key=lambda f: -f["errors"] / f["bits"])[:25]
        rep.table(["Sent at", "Msg id", "Size", "Status", "Bit errors", "Bits", "Density", "Bursts", "Longest burst",
                   "First error at", "SNR (dB)"],
                  [[fmt_t(f["t"]), f.get("msg_id"), f["len"], f["status"], f["errors"], f["bits"],
                    sci(f["errors"] / f["bits"]), f.get("bursts"), f.get("max_burst"),
                    pct(f.get("first_err")), num(f.get("snr"), 1)] for f in worst], num_cols=[1, 2, 4, 5, 6, 7, 8, 9, 10])
    else:
        rep.p("No failed bursts with recorded bits (either nothing failed, or the sender's log is missing).")

    # ---------- ARQ
    rep.sec("arq", "SR-ARQ transport layer",
            "From the sender's taps on the FSM: every SYN / DATA / FIN sent and every SYN_ACK / ACK / FIN_ACK received. "
            "A DATA packet sent again before its ACK arrived is a retransmission. With the receiver's log, each "
            "retransmission is classified: the receiver had decoded the DATA (so the ACK was lost or late) or not.")
    for a, v in arq.items():
        pk = v["packets"]
        if not pk:
            rep.p(f"Node {a}: no DATA packets recorded.")
            continue
        sess = v["sessions"]
        causes = collections.Counter(c for x in pk for c in x["causes"])
        rtts = [x["t_ack"] - x["t0"] for x in pk if x["t_ack"] and x["tx"] == 1]
        hs = [s["t_synack"] - s["t_syn"] for s in sess if s["t_synack"]]
        rep.tiles([("Sessions (node %s → %s)" % (a, v["peer"]), len(sess),
                    f"{sum(1 for s in sess if s['t_finack'])} closed with FIN_ACK"),
                   ("DATA packets", f"{len(pk):,}", f"{sum(x['tx'] for x in pk):,} transmissions"),
                   ("Retransmission rate", pct(sum(x["tx"] - 1 for x in pk) / len(pk)),
                    ", ".join(f"{k}: {n}" for k, n in causes.items()) or "no retransmissions"),
                   ("Never ACKed", sum(1 for x in pk if not x["t_ack"]), "packets"),
                   ("SYN retries", sum(s["syn_tx"] - 1 for s in sess), f"{sum(s['fin_tx'] - 1 for s in sess)} FIN retries"),
                   ("RTT DATA→ACK", num(1e3 * med(rtts), 0, "ms") if rtts else "–",
                    f"min {num(1e3 * min(rtts), 0)} · p95 {num(1e3 * q(rtts, .95), 0)} ms (Karn: first-try packets)" if rtts else ""),
                   ("Handshake SYN→SYN_ACK", num(1e3 * med(hs), 0, "ms") if hs else "–", f"{len(hs)} sessions"),
                   ("Duplicate ACKs", sum(s["dup_ack"] for s in sess), "")])
        byb = collections.defaultdict(list)
        for x in pk:
            byb[x["len"]].append(x)
        if len(byb) > 12:
            byb2 = collections.defaultdict(list)
            for x in pk:
                byb2[size_bucket(x["len"])].append(x)
            byb, lab = byb2, "≤"
        else:
            lab = ""
        link_fer = {}
        for d in dirs:
            if d.tx.addr == a:
                for f in d.frames:
                    if f["status"] in ("ok", "crc_fail", "bad_len", "lost"):
                        link_fer.setdefault(size_bucket(f["len"]), []).append(f["status"] != "ok")
        rows, cats, vals = [], [], []
        for L in sorted(byb):
            xs = byb[L]
            n_tx = sum(x["tx"] for x in xs)
            rr = (n_tx - len(xs)) / len(xs)
            lf = link_fer.get(size_bucket(L + C.TP_HDR_BYTES))
            rows.append([f"{lab}{L}", L + C.TP_HDR_BYTES, len(xs), n_tx, n_tx - len(xs), pct(rr), num(n_tx / len(xs), 3),
                         pct(1 - len(xs) / n_tx), pct(sum(lf) / len(lf)) if lf else "–",
                         num(sc(med([x["t_ack"] - x["t0"] for x in xs if x["t_ack"] and x["tx"] == 1]), 1e3), 0)])
            cats.append(f"{lab}{L}")
            vals.append(rr)
        rep.chart(S.bar_chart(cats, [{"name": "retransmission rate", "values": vals}],
                              f"Retransmission rate vs DATA payload size (node {a})", "retransmissions per packet",
                              fmt=lambda v: f"{100 * v:.0f}%",
                              note="Payload = file bytes in the packet; the burst also carries the 18 B transport header."))
        rep.table(["Payload (B)", "On-link payload (B)", "Packets", "Transmissions", "Retx", "Retx rate", "Tx per packet",
                   "Implied packet loss", "Link FER at that size", "Median RTT (ms)"], rows)

    # ---------- application
    rep.sec("app", "Application: messages through the full stack",
            "Each test message = app frame (8 B header + name + payload) → SR-ARQ → radio; completion = tx_done "
            "from the FSM. Goodput = payload bits ÷ completion time. Latency = sender hand-off → verified at the receiver.")
    for a, v in arq.items():
        msgs = v["messages"]
        if not msgs:
            continue
        bys = collections.OrderedDict()
        for m in sorted(msgs, key=lambda m: (m["size"], m["pattern"])):
            bys.setdefault((m["size"], m["pattern"]), []).append(m)
        rows, pts, ideal = [], [], []
        pats = collections.Counter(m["pattern"] for m in msgs)
        main_pat = "random" if "random" in pats else pats.most_common(1)[0][0]
        for (sz, pt), ms in bys.items():
            ok = [m for m in ms if m["event"] == "tx_done"]
            g = [m["goodput_bps"] for m in ok if m.get("goodput_bps")]
            rows.append([sz, pt, len(ms), len(ok), sum(1 for m in ms if m.get("content_ok")) if v["rx_log"] else "–",
                         ms[0]["n_pkts"], num(mean([m.get("retx", 0) for m in ms]), 2),
                         num(med([m["time_s"] for m in ok if m["time_s"]]), 2),
                         num(med(g) / 1e3 if g else None, 2), num(max(g) / 1e3 if g else None, 2),
                         num(sz * 8 / ideal_arq_time(sz, params[a]) / 1e3, 2),
                         num(med([m.get("util") for m in ok]), 2),
                         num(sc(med([m.get("handshake_s") for m in ms]), 1e3), 0),
                         num(med([m.get("latency_s") for m in ms]), 2)])
            if pt == main_pat and g:
                pts.append((sz, med(g) / 1e3))
        ideal = [(x, x * 8 / ideal_arq_time(x, params[a]) / 1e3) for x in sorted({m["size"] for m in msgs})]
        rep.chart(S.line_chart([{"name": "measured (median)", "points": pts},
                                {"name": "ideal (air time only)", "points": ideal, "theory": True}],
                               f"Application goodput vs message size (node {a} → {v['peer']}, {main_pat} payload)",
                               "message size, bytes", "goodput, kb/s", logx=True, ylo=0))
        rep.table(["Size (B)", "Pattern", "Sent", "Completed", "Verified", "Packets", "Mean retx", "Median time (s)",
                   "Median goodput (kb/s)", "Max goodput (kb/s)", "Ideal goodput (kb/s)", "Channel utilisation",
                   "Handshake (ms)", "Latency (s)"], rows, num_cols=[0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13])
        bad = [m for m in msgs if m["event"] != "tx_done" or m.get("content_ok") is False]
        if bad:
            rep.table(["Sent at", "Size", "Pattern", "Result", "Attempts", "Retx", "Delivered", "Content OK"],
                      [[fmt_t(m["t_send"]), m["size"], m["pattern"], m["event"], m["attempts"], m.get("retx"),
                        m.get("delivered"), m.get("content_ok")] for m in bad], num_cols=[1, 4, 5])

    # ---------- RF
    rep.sec("rf", "RF measurements at each receiver",
            "From the RSSI/spectrum probe on the raw IQ (before the AGC): dBFS relative to the ADC full scale. "
            "Wideband SNR is over the whole sample-rate bandwidth (about 6 dB below the SNR in the symbol bandwidth "
            "at 4 samples/symbol). OBW = band holding 99 % of the received signal power; CFO = its power centroid.")
    rows = []
    for a in addrs:
        rs = nodes[a].tel["rssi"]
        if not rs:
            continue
        sig = [r for r in rs if r.get("busy_pct", 0) >= 20]           # intervals with enough signal for OBW / CFO

        def g(k, src=None):
            return [r.get(k) for r in (src if src is not None else rs) if r.get(k) is not None]
        rows.append([a, len(rs), num(med(g("nf_dbfs")), 1), num(med(g("sig_dbfs")), 1), num(med(g("snr_db")), 1),
                     num(med(g("obw99_hz", sig)) / 1e3 if g("obw99_hz", sig) else None, 0),
                     num(med(g("cfo_hz", sig)) / 1e3 if g("cfo_hz", sig) else None, 2), num(max(g("clip_pct") or [0]), 4),
                     num(max(g("peak_dbfs") or [-200]), 1), num(mean(g("busy_pct")), 1)])
        hist = [(r["t"] - off[a], r) for r in rs]
        t0 = hist[0][0]
        rep.chart(S.line_chart([{"name": "noise floor", "points": [((t - t0) / 60, r["nf_dbfs"]) for t, r in hist if r.get("nf_dbfs") is not None]},
                                {"name": "signal (bursts)", "points": [((t - t0) / 60, r["sig_dbfs"]) for t, r in hist if r.get("sig_dbfs") is not None]}],
                               f"Received power at node {a} over time", "minutes since this node's log started", "dBFS",
                               markers=False))
    rep.table(["Node", "Samples", "Noise floor (dBFS)", "Signal (dBFS)", "Wideband SNR (dB)", "OBW 99 % (kHz)",
               "CFO (kHz)", "Max clipping (%)", "Peak (dBFS)", "Channel busy (%)"], rows)
    for a in addrs:
        ev = nodes[a].tel["evm"]
        if ev:
            t0 = ev[0]["t"]
            dr = [e.get("drift_hz") for e in ev if e.get("drift_hz") is not None]
            rep.chart(S.line_chart([{"name": "SNR from EVM", "points": [((e["t"] - t0) / 60, e["snr_db"]) for e in ev
                                                                        if e.get("snr_db") is not None]}],
                                   f"Per-burst SNR (EVM) at node {a} over time", "minutes", "dB", markers=False,
                                   note=f"Residual frequency after the Costas loop: median {num(med(dr), 1)} Hz."))

    # ---------- timeline
    rep.sec("timeline", "Timeline", "Program start/end at both ends, jobs and notes, on the reference clock (node "
            f"{addrs[0]}).")
    tl = []
    for a in addrs:
        for s in nodes[a].sessions:
            tl.append((s["start"]["t"] - off[a], a, "program start", s["start"].get("host", "")))
            if s["end"]:
                tl.append((s["end"]["t"] - off[a], a, "program end", f"{s['end'].get('records', '')} records"))
        for r in nodes[a].recs["mark"]:
            tl.append((r["t"] - off[a], a, "note", r.get("text", "")))
    for j in jobs:
        tl.append((j["t0"] - off[j["node"]], j["node"], f"job {j['job']} start", j["type"] + " " + (j["params"].get("set") or "")))
        if j["t1"]:
            tl.append((j["t1"] - off[j["node"]], j["node"], f"job {j['job']} end", j["status"]))
    tl.sort()
    rep.table(["Time (reference clock)", "Node", "Event", "Detail"], [[fmt_t(t), a, e, d] for t, a, e, d in tl], num_cols=[])

    # ---------- findings
    rep.sec("recs", "Findings and suggestions", "Automatic checks on the numbers above.")
    n_rec = 0
    pre_share = p["preamble_len"] / C.frame_bytes(200, p)
    if pre_share > 0.5:
        rep.rec("warn", f"The {p['preamble_len']} B preamble is {pre_share:.0%} of every 200 B burst's air time, so it caps "
                        f"200 B throughput at {200 * 8 / C.airtime(200, p) / 1e3:.0f} kb/s of {p['bit_rate'] / 1e3:.0f}. "
                        "Try halving it and compare FER at the same SNR; bigger MTU also amortises it.")
        n_rec += 1
    for a in addrs:
        clip = [r.get("clip_pct", 0) for r in nodes[a].tel["rssi"]]
        if clip and max(clip) > 0.01:
            rep.rec("crit", f"Node {a}: ADC clipping up to {max(clip):.3f} % of samples: lower the RX gain or the peer's TX power.")
            n_rec += 1
    for d in dirs:
        st = frame_summary(d.frames)
        if st["observed"] and st["lost"] > (st["crc_fail"] + st["bad_len"]) and st["lost"] > 2:
            rep.rec("warn", f"{d.name}: more bursts were never detected ({st['lost']}) than failed CRC "
                            f"({st['crc_fail'] + st['bad_len']}): acquisition (AGC/FLL/timing settling on the preamble, sync "
                            "threshold) is the weak point, not the bit errors.")
            n_rec += 1
        if st["observed"] and st["fer"] is not None and st["fer"] > 0.1:
            rep.rec("warn", f"{d.name}: {st['fer']:.1%} of bursts failed or were lost (median SNR "
                            f"{num(st['snr_med'], 1)} dB). See FER vs SNR / size to find where the link breaks down.")
            n_rec += 1
        if st["observed"] and st["fer"] is not None and st["fer"] < 0.01:
            rep.rec("good", f"{d.name}: frame error rate {st['fer']:.2%} over {st['observed']} bursts.")
            n_rec += 1
    pz = {s["pattern"]: s for s in item_stats}
    if "zeros" in pz and "random" in pz and (pz["zeros"]["fer"] or 0) > 2 * (pz["random"]["fer"] or 0) + 0.05:
        rep.rec("warn", "All-zero payloads fail much more often than random ones: with differential BPSK, zeros mean no "
                        "phase changes, so the symbol-timing loop gets no transitions. A scrambler/whitening before the "
                        "modulator removes this content dependence.")
        n_rec += 1
    if failed:
        tail = prof[15:].sum() / max(prof.sum(), 1)
        if tail > 0.4:
            rep.rec("warn", f"{tail:.0%} of bit errors are in the last quarter of the bursts: timing or phase drift over "
                            "long bursts. Consider a smaller MTU, wider symbol-sync / Costas loop bandwidth, or mid-amble.")
            n_rec += 1
    for a, v in arq.items():
        c = collections.Counter(cc for x in v["packets"] for cc in x["causes"])
        if c and sum(c.values()) >= 3 and c.get("ack lost/late", 0) > c.get("data lost", 0):
            rep.rec("warn", f"Node {a}: most retransmissions happened although the peer had decoded the DATA: ACKs were "
                            "lost or arrived after the RTO. Check the reverse link FER, or raise TL_RTO_MS above the "
                            "measured RTT p95.")
            n_rec += 1
        rt = [x["t_ack"] - x["t0"] for x in v["packets"] if x["t_ack"] and x["tx"] == 1]
        rto = (nodes[a].config or {}).get("vars", {}).get("tl_rto_ms")
        if rt and rto and q(rt, .95) * 1e3 > 0.8 * rto:
            rep.rec("warn", f"Node {a}: RTT p95 {q(rt, .95) * 1e3:.0f} ms is close to the RTO {rto} ms: spurious retransmissions likely.")
            n_rec += 1
    if snrs and med(snrs) < 10:
        rep.rec("warn", f"Median SNR {med(snrs):.1f} dB is low for BPSK at these frame lengths: raise TX power "
                        "(lower CH_GAIN attenuation) or shorten the distance.")
        n_rec += 1
    if not n_rec:
        rep.p("Nothing unusual detected.")

    # ---------- configuration
    rep.sec("config", "Flowgraph parameters (every node)",
            "Runtime values reported by the running flowgraph (variables after environment variables were applied, "
            "settings of the Python blocks), the GRC expressions of every DSP/radio block, and the daemon's settings.")
    cfg_out = {}
    for a in addrs:
        n = nodes[a]
        cfg = n.config or {}
        cfg_out[a] = {"vars": cfg.get("vars"), "blocks": cfg.get("blocks"),
                      "grc_blocks": (cfg.get("grc_config") or {}).get("grc_blocks"),
                      "grc_file": n.sessions[0]["start"].get("grc"), "env": n.sessions[0]["start"].get("env"),
                      "ports": n.sessions[0]["start"].get("ports")}
        rep.raw(f"<h3>Node {a} ({esc(n.host)})</h3>", f"\n### Node {a} ({n.host})\n")
        if not cfg:
            rep.p("No configuration record (flowgraph telemetry never reached the daemon).")
            continue
        rep.table(["Variable", "Value"], [[k, v] for k, v in sorted((cfg.get("vars") or {}).items())], num_cols=[])
        rows = [[b, k, v] for b, d in sorted((cfg.get("blocks") or {}).items()) for k, v in sorted(d.items())]
        rep.table(["Python block", "Setting", "Value"], rows, num_cols=[])
        gb = dict((cfg.get("grc_config") or {}).get("grc_blocks") or {})
        gb.update((n.sessions[-1]["start"].get("grc") or {}).get("blocks") or {})
        rows = [[b, d.get("id"), ", ".join(f"{k}={v}" for k, v in d.items() if k != "id")]
                for b, d in sorted(gb.items())]
        rep.table(["GRC block", "Type", "Parameters (as set in GRC)"], rows, num_cols=[])
        env = n.sessions[0]["start"].get("env") or {}
        if env:
            rep.table(["Environment", "Value"], [[k, v] for k, v in sorted(env.items())], num_cols=[])
    if len(addrs) == 2:
        va = (nodes[addrs[0]].config or {}).get("vars", {})
        vb = (nodes[addrs[1]].config or {}).get("vars", {})
        diff = [[k, va.get(k), vb.get(k)] for k in sorted(set(va) | set(vb)) if va.get(k) != vb.get(k)]
        if diff:
            rep.raw("<h3>Differences between the two nodes</h3>", "\n### Differences between the nodes\n")
            rep.table(["Variable", f"Node {addrs[0]}", f"Node {addrs[1]}"], diff, num_cols=[])

    # ================= files
    sub = (f"{len(paths)} log(s), nodes {', '.join(str(a) for a in addrs)} · generated {fmt_t(time.time())} · "
           f"{sum(len(d.frames) for d in dirs):,} bursts, {sum(len(v['messages']) for v in arq.values())} ARQ messages")
    (out / "report.html").write_text(rep.html(sub, toc), encoding="utf-8")
    (out / "report.md").write_text(f"# {rep.title}\n\n{sub}\n" + "\n".join(rep.md), encoding="utf-8")
    with open(out / "frames.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["direction", "t_sent", "msg_id", "perf_job", "perf_seq", "payload_len", "frame_len", "air_ms", "status",
                    "t_rx", "latency_ms", "bit_errors", "bits", "error_density", "sync_err", "bursts", "max_burst",
                    "err_hdr", "err_pay", "err_crc", "first_err_frac", "snr_db", "evm_pct", "rssi_dbfs", "partial"])
        for d in dirs:
            for x in d.frames:
                r = x["rx"]
                w.writerow([d.name, f"{x['t']:.6f}", x.get("msg_id"), x.get("perf_job"), x.get("perf_seq"), x["len"],
                            x.get("frame_len"), f"{x['air'] * 1e3:.2f}", x["status"], f"{r['t']:.6f}" if r else "",
                            f"{((r['t'] - off[d.rx.addr]) - (x['t'] - off[d.tx.addr])) * 1e3:.2f}" if r else "",
                            x["errors"], x["bits"], f"{x['errors'] / x['bits']:.3e}" if x["bits"] else "", x["sync_err"],
                            x.get("bursts"), x.get("max_burst"), x.get("err_hdr"), x.get("err_pay"), x.get("err_crc"),
                            x.get("first_err"), x.get("snr"), x.get("evm_pct"), x.get("rssi_dbfs"), x.get("partial")])
    with open(out / "messages.csv", "w", newline="") as f:
        keys = ["node", "run", "idx", "job", "size", "pattern", "n_pkts", "frame_len", "attempts", "t_send", "event",
                "time_s", "goodput_bps", "data_pkts", "data_tx", "retx", "syn_tx", "fin_tx", "handshake_s", "rtt_med",
                "fin_acked", "bytes_on_air", "air_s", "util", "delivered", "content_ok", "latency_s"]
        w = csv.DictWriter(f, keys, extrasaction="ignore")
        w.writeheader()
        for a, v in arq.items():
            for m in v["messages"]:
                w.writerow(dict(m, node=a))
    with open(out / "packets.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["node", "session", "slot", "payload_len", "transmissions", "t_first", "t_ack", "rtt_s", "retx_causes"])
        for a, v in arq.items():
            for x in v["packets"]:
                w.writerow([a, x["sid"], x["slot"], x["len"], x["tx"], f"{x['t0']:.6f}",
                            f"{x['t_ack']:.6f}" if x["t_ack"] else "", f"{x['t_ack'] - x['t0']:.4f}" if x["t_ack"] else "",
                            ";".join(x["causes"])])
    (out / "config.json").write_text(json.dumps(cfg_out, indent=1, default=str))
    summ["link_items"] = item_stats
    summ["arq"] = {a: {"messages": len(v["messages"]), "packets": len(v["packets"]),
                       "retx": sum(x["tx"] - 1 for x in v["packets"]),
                       "completed": sum(m["event"] == "tx_done" for m in v["messages"]),
                       "verified": sum(1 for m in v["messages"] if m.get("content_ok")),
                       "max_goodput_bps": max([m.get("goodput_bps") or 0 for m in v["messages"]] or [0])}
                   for a, v in arq.items()}
    summ["nodes"] = {a: {"host": nodes[a].host, "rssi_samples": len(nodes[a].tel["rssi"]),
                         "evm_samples": len(nodes[a].tel["evm"])} for a in addrs}
    (out / "summary.json").write_text(json.dumps(summ, indent=1, default=str))
    return out


def main():
    ap = argparse.ArgumentParser(description="Build the CDP transceiver performance report from perf_daemon logs")
    ap.add_argument("logs", nargs="+", help="perf_logs/*.jsonl from one or both PCs")
    ap.add_argument("-o", "--out", default=time.strftime("perf_report_%Y%m%d-%H%M%S"))
    ap.add_argument("--title", default=None)
    a = ap.parse_args()
    out = build_report(a.logs, a.out, a.title)
    print(f"report: {out / 'report.html'}")


if __name__ == "__main__":
    main()
