"""Formats shared by perf_daemon.py and perf_report.py (no GNU Radio / ZMQ imports here)."""
import math
import random
import struct
import zlib
from pathlib import Path

PATTERNS = ["random", "zeros", "ones", "alt55", "altAA", "text", "ramp"]
PATTERN_CODE = {p: i for i, p in enumerate(PATTERNS)}
LINK_MAGIC = b"\xC3\x5A"                 # first byte not 1..6, so the RX header parser ignores it
LINK_HDR = struct.Struct(">2sIIHBHd")     # magic, run, seq, item, pattern, size, t_send = 23 bytes
TP_HDR_BYTES = 18                        # SR-ARQ transport header (RX Header Parser / TX Header Serializer)
LINK_HDR_BYTES = 6                       # framer header: len(2) dest msg_id rep n_reps
SYNC_BYTES = 4
CRC_BYTES = 4
APP_HDR_BYTES = 8                        # [dst][port][media][res][len:4]
LOREM = (b"The quick brown fox jumps over the lazy dog. CDP link performance test 0123456789. "
         b"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. ")

DEFAULTS = {"preamble_len": 1024, "postamble_len": 160, "bit_rate": 375000.0, "mtu": 200,
            "samp_rate": 1.5e6, "sps": 4, "alpha": 0.35}


def pattern_bytes(pattern, n, seed):
    if n <= 0:
        return b""
    if pattern == "zeros":
        return bytes(n)
    if pattern == "ones":
        return b"\xff" * n
    if pattern == "alt55":
        return b"\x55" * n
    if pattern == "altAA":
        return b"\xaa" * n
    if pattern == "ramp":
        return bytes(i & 0xFF for i in range(n))
    if pattern == "text":
        return (LOREM * (n // len(LOREM) + 1))[:n]
    return random.Random(f"perf:{seed}").randbytes(n)          # "random"


# ---------------------------------------------------------------- raw link test frames
def build_link_payload(run, seq, item, pattern, size, t_send):
    size = max(size, LINK_HDR.size)
    hdr = LINK_HDR.pack(LINK_MAGIC, run & 0xFFFFFFFF, seq & 0xFFFFFFFF, item & 0xFFFF,
                        PATTERN_CODE.get(pattern, 0), size & 0xFFFF, float(t_send))
    return hdr + pattern_bytes(pattern, size - LINK_HDR.size, f"{run}:{seq}")


def parse_link_payload(data):
    if len(data) < LINK_HDR.size or data[:2] != LINK_MAGIC:
        return None
    magic, run, seq, item, pcode, size, t_send = LINK_HDR.unpack_from(data)
    return {"run": run, "seq": seq, "item": item, "pattern": PATTERNS[pcode] if pcode < len(PATTERNS) else "?",
            "size": size, "t_send": t_send}


def expected_link_payload(info):
    """Regenerate the payload from its (intact) test header."""
    return build_link_payload(info["run"], info["seq"], info["item"], info["pattern"], info["size"], info["t_send"])


# ---------------------------------------------------------------- app (ARQ) test messages
def perf_name(run, idx, size, pattern):
    return f"perf_{run}_{idx:05d}_{size}_{pattern}.bin"


def parse_perf_name(name):
    try:
        p = Path(name).stem.split("_")
        if p[0] != "perf" or len(p) != 5:
            return None
        return {"run": int(p[1]), "idx": int(p[2]), "size": int(p[3]), "pattern": p[4]}
    except (ValueError, IndexError):
        return None


def perf_data(run, idx, size, pattern):
    return pattern_bytes(pattern, size, f"app:{run}:{idx}")


def build_app_frame(dst_addr, name, data, dst_port=0, media=0):
    name_b = name.encode("utf-8")[:65535]
    body = struct.pack(">H", len(name_b)) + name_b + data
    return struct.pack(">BBBBI", dst_addr & 0xFF, dst_port & 0xFF, media, 0, len(body)) + body


def parse_app_frame(frame):
    if len(frame) < 8:
        raise ValueError("frame too short")
    _d, _p, _m, _r, length = struct.unpack_from(">BBBBI", frame, 0)
    body = frame[8:]
    if len(body) != length or len(body) < 2:
        raise ValueError("bad length")
    (n,) = struct.unpack_from(">H", body, 0)
    if 2 + n > len(body):
        raise ValueError("name overruns body")
    return body[2:2 + n].decode("utf-8", "replace"), body[2 + n:]


# ---------------------------------------------------------------- link budget
def link_params(cfg):
    """Pull the numbers the timing model needs out of a hub 'config' record (or defaults)."""
    p = dict(DEFAULTS)
    if not cfg:
        return p
    v = cfg.get("vars", {})
    for k in ("samp_rate", "sps", "alpha"):
        if isinstance(v.get(k), (int, float)):
            p[k] = float(v[k])
    p["bit_rate"] = p["samp_rate"] / p["sps"]
    if isinstance(v.get("tl_mtu"), (int, float)):
        p["mtu"] = int(v["tl_mtu"])
    for name, b in cfg.get("blocks", {}).items():
        if "preamble_len" in b:
            p["preamble_len"] = int(b["preamble_len"])
            p["postamble_len"] = int(b.get("postamble_len", 0))
    return p


def frame_bytes(payload_len, p):
    return p["preamble_len"] + SYNC_BYTES + LINK_HDR_BYTES + payload_len + CRC_BYTES + p["postamble_len"]


def airtime(payload_len, p):
    return frame_bytes(payload_len, p) * 8 / p["bit_rate"]


def app_frame_len(name_len, size):
    return APP_HDR_BYTES + 2 + name_len + size


def n_packets(frame_len, mtu):
    return max(1, math.ceil(frame_len / mtu))


def crc(data):
    return zlib.crc32(data)


# ---------------------------------------------------------------- key flowgraph parameters
def key_parameters(cfg, grc_file=None):
    """[(group, parameter, value)] of the settings that matter for performance, from a hub config record
    (evaluated GRC variables, Python-block settings) and the GRC expressions of the DSP/radio blocks.
    grc_file = the daemon's parse of the .grc that was running; its block settings win over the copy
    embedded in the flowgraph when it was built."""
    if not cfg:
        return []
    v = cfg.get("vars", {}) or {}
    pyb = cfg.get("blocks", {}) or {}
    grc = dict((cfg.get("grc_config") or {}).get("grc_blocks") or {})
    if grc_file and isinstance(grc_file.get("blocks"), dict):
        grc.update(grc_file["blocks"])

    def g_id(prefix):
        return [(n, b) for n, b in sorted(grc.items()) if str(b.get("id", "")).startswith(prefix)]

    def g1(prefix, key, default="–"):
        for _n, b in g_id(prefix):
            if key in b:
                return _resolve(b[key], v)
        return default

    def py(cls_attr, key, default="–"):
        for _n, b in pyb.items():
            if cls_attr in b and key in b:
                return b[key]
        return default

    sr, sps = v.get("samp_rate"), v.get("sps")
    out = []
    add = lambda grp, k, val: out.append((grp, k, _fmt_val(val)))
    add("Node", "MY_ID / PEER_ID", f"{v.get('MY_ID', v.get('tl_local_addr', '?'))} / {v.get('PEER_ID', v.get('tl_peer_addr', '?'))}")
    add("Radio", "SDR URI", v.get("ADDR", "–"))
    add("Radio", "TX frequency", _hz(v.get("tx_freq")))
    add("Radio", "RX frequency", _hz(v.get("rx_freq")))
    add("Radio", "Sample rate", _hz(sr, "S/s"))
    add("Radio", "TX attenuation (CH_GAIN)", f"{g1('iio_pluto_sink', 'attenuation1')} dB")
    add("Radio", "TX / RX analog bandwidth", f"{g1('iio_pluto_sink', 'bandwidth')} / {g1('iio_pluto_source', 'bandwidth')}")
    add("Radio", "RX gain mode / manual gain", f"{g1('iio_pluto_source', 'gain1')} / {g1('iio_pluto_source', 'manual_gain1')} dB")
    add("Radio", "Pluto buffer (TX / RX)", f"{g1('iio_pluto_sink', 'buffer_size')} / {g1('iio_pluto_source', 'buffer_size')} samples")
    sq = g_id("analog_pwr_squelch") + g_id("analog_simple_squelch")
    if sq:
        for n, b in sq:
            add("Radio", f"Power squelch {n}", ", ".join(f"{k}={_resolve(x, v)}" for k, x in b.items() if k != "id"))
    else:
        add("Radio", "Power squelch", "none in this flowgraph")
    add("Modem", "Modulation", "BPSK, differential" if g1("digital_constellation_modulator", "differential") == "True" else
        g1("digital_constellation_modulator", "constellation"))
    add("Modem", "Samples / symbol (sps)", sps)
    add("Modem", "Symbol rate", _hz(sr / sps if sr and sps else None, "Bd"))
    add("Modem", "RRC roll-off (alpha)", v.get("alpha"))
    add("Modem", "RX RRC taps", g1("root_raised_cosine_filter", "ntaps"))
    add("RX loops", "AGC rate / reference / max gain",
        f"{g1('analog_agc', 'rate')} / {g1('analog_agc', 'reference')} / {g1('analog_agc', 'max_gain')}")
    add("RX loops", "FLL band-edge loop BW (fll_loop_bw)", v.get("fll_loop_bw"))
    add("RX loops", "FLL filter size", g1("digital_fll_band_edge", "filter_size"))
    add("RX loops", "Symbol sync loop BW (sym_bw)", v.get("sym_bw"))
    add("RX loops", "Symbol sync TED / damping / TED gain",
        f"{g1('digital_symbol_sync', 'ted_type')} / {g1('digital_symbol_sync', 'damping')} / {g1('digital_symbol_sync', 'ted_gain')}")
    add("RX loops", "Symbol sync max deviation / out sps / filters",
        f"{g1('digital_symbol_sync', 'max_dev')} / {g1('digital_symbol_sync', 'osps')} / {g1('digital_symbol_sync', 'nfilters')}")
    add("RX loops", "Equalizer taps / sps", f"{g1('digital_linear_equalizer', 'num_taps')} / {g1('digital_linear_equalizer', 'sps')}")
    add("RX loops", "Equalizer algorithm", ", ".join(f"{k}={x}" for k, x in (grc.get("adpt_alg") or {}).items() if k != "id") or "–")
    add("RX loops", "Costas loop BW (costas_bw) / order", f"{v.get('costas_bw', '–')} / {g1('digital_costas_loop', 'order')}")
    add("RX test", "Added noise (nv slider)", v.get("nv"))
    add("Framing", "Preamble length", f"{py('preamble_len', 'preamble_len')} B of 0x{int(py('preamble_byte', 'preamble_byte', 255)):02X}")
    add("Framing", "Postamble length", f"{py('postamble_len', 'postamble_len')} B")
    add("Framing", "Sync word / max sync bit errors", f"0x1ACFFC1D / {py('max_bit_errors', 'max_bit_errors')}")
    add("Framing", "Max payload (framer / deframer)", f"{py('preamble_len', 'max_payload_len')} / {py('max_bit_errors', 'max_payload_len')} B")
    add("Framing", "Burst repeats", py("repeat_count", "repeat_count"))
    add("Framing", "Header / CRC", "6 B (len, dest, msg_id, rep, n_reps) / CRC32")
    add("SR-ARQ", "MTU (bytes per DATA packet)", v.get("tl_mtu"))
    add("SR-ARQ", "Sequence bits m / window", f"{v.get('tl_m', '–')} / {2 ** (int(v['tl_m']) - 1) if v.get('tl_m') else '–'}")
    add("SR-ARQ", "RTO / max retries", f"{v.get('tl_rto_ms', '–')} ms / {v.get('tl_max_retries', '–')}")
    add("SR-ARQ", "Local port / role", f"{v.get('tl_local_port', '–')} / {v.get('tl_role', '–')}")
    add("Ports", "ZMQ app in / out / telemetry / link",
        f"{v.get('tl_zmq_tx_port', '–')} / {v.get('tl_zmq_rx_port', '–')} / {v.get('tl_zmq_tap_port', '–')} / {v.get('tl_zmq_link_port', '–')}")
    return out


def _resolve(expr, v):
    """Value of a GRC expression using the flowgraph's variables: '45 (11*sps+1)'; text otherwise."""
    s = str(expr).strip()
    if s in v:
        return v[s]
    if s.endswith(".arity()"):                       # constellation objects are not in the telemetry
        return "2 (BPSK)" if "BPSK" in s else s
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"":
        return s[1:-1]
    try:
        float(s)
        return s                                     # a plain number: show it as written
    except ValueError:
        pass
    try:
        import ast
        names = {n.id for n in ast.walk(ast.parse(s, mode="eval")) if isinstance(n, ast.Name)}
        if names <= set(v) | {"int", "float"}:
            val = eval(compile(s, "<grc>", "eval"), {"__builtins__": {}, "int": int, "float": float}, dict(v))
            if isinstance(val, (int, float)) and not isinstance(val, bool):
                txt = f"{val:g}" if isinstance(val, float) else str(val)
                return txt if txt == s else f"{txt} ({s})"
    except Exception:
        pass
    return s


def _hz(x, unit="Hz"):
    if not isinstance(x, (int, float)):
        return "–"
    for div, p in ((1e9, "G"), (1e6, "M"), (1e3, "k")):
        if abs(x) >= div:
            return f"{x / div:g} {p}{unit}"
    return f"{x:g} {unit}"


def _fmt_val(x):
    if x is None:
        return "–"
    if isinstance(x, float):
        return f"{x:g}"
    return str(x)
