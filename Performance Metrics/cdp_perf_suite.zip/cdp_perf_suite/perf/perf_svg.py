"""Tiny dependency-free SVG charts for the performance report (light/dark via CSS variables).

Colors are role tokens (--s1..--s3 series, --theory reference curves, --grid, --axis, --muted)
defined in the report's stylesheet. Every mark carries a <title> (hover tooltip) and every
chart is followed by a <details> table with the same numbers.
"""
import html
import math

SERIES = ["var(--s1)", "var(--s2)", "var(--s3)"]
FONT = 'font-family="system-ui,-apple-system,Segoe UI,sans-serif"'


def esc(s):
    return html.escape(str(s), quote=True)


def _nice(lo, hi, n=5):
    if hi <= lo:
        hi = lo + 1
    span = hi - lo
    step = 10 ** math.floor(math.log10(span / n))
    for m in (1, 2, 2.5, 5, 10):
        if span / (step * m) <= n:
            step *= m
            break
    a = math.floor(lo / step) * step
    b = math.ceil(hi / step) * step
    ticks = []
    v = a
    while v <= b + step * 1e-9:
        ticks.append(round(v, 12))
        v += step
    return a, b, ticks


def _fmt(v):
    if v == 0:
        return "0"
    a = abs(v)
    if a >= 1e4 or a < 1e-3:
        return f"{v:.0e}".replace("e-0", "e-").replace("e+0", "e")
    if a >= 100:
        return f"{v:,.0f}"
    if a >= 1:
        return f"{v:.3g}"
    return f"{v:.2g}"


class Axis:
    def __init__(self, vals, log=False, lo=None, hi=None, ticks=None):
        self.log = log
        vals = [v for v in vals if v is not None and (v > 0 or not log)]
        if not vals:
            vals = [1.0] if log else [0.0, 1.0]
        if log:
            a = math.floor(math.log10(min(vals) if lo is None else lo))
            b = math.ceil(math.log10(max(vals) if hi is None else hi))
            if b <= a:
                b = a + 1
            self.lo, self.hi = 10.0 ** a, 10.0 ** b
            self.ticks = ticks or [10.0 ** k for k in range(a, b + 1)]
        else:
            lo_ = min(vals) if lo is None else lo
            hi_ = max(vals) if hi is None else hi
            self.lo, self.hi, t = _nice(lo_, hi_)
            self.ticks = ticks or t

    def frac(self, v):
        if self.log:
            v = max(v, self.lo * 1e-3)
            return (math.log10(v) - math.log10(self.lo)) / (math.log10(self.hi) - math.log10(self.lo))
        return (v - self.lo) / (self.hi - self.lo)


def _frame(w, h, title_id, title):
    return [f'<svg viewBox="0 0 {w} {h}" width="100%" role="img" aria-labelledby="{title_id}" {FONT} '
            f'style="max-width:{w}px;display:block">', f'<title id="{title_id}">{esc(title)}</title>']


def _legend(names_colors, kind="line"):
    if len(names_colors) < 2:
        return ""
    items = []
    for name, color, dashed in names_colors:
        key = (f'<svg width="18" height="10"><line x1="1" y1="5" x2="17" y2="5" stroke="{color}" stroke-width="2" '
               f'stroke-linecap="round"/></svg>' if kind == "line" else
               f'<svg width="12" height="12"><rect width="12" height="12" rx="3" fill="{color}"/></svg>')
        items.append(f'<span class="lg">{key}{esc(name)}</span>')
    return '<div class="legend">' + "".join(items) + "</div>"


def _table(headers, rows):
    out = ['<details class="tv"><summary>Table view</summary><table><thead><tr>']
    out += [f"<th>{esc(h)}</th>" for h in headers]
    out.append("</tr></thead><tbody>")
    for r in rows:
        out.append("<tr>" + "".join(f'<td class="n">{esc(c)}</td>' for c in r) + "</tr>")
    out.append("</tbody></table></details>")
    return "".join(out)


_uid = [0]


def _id():
    _uid[0] += 1
    return f"c{_uid[0]}"


def line_chart(series, title, xlabel, ylabel, logx=False, logy=False, w=680, h=300, ylo=None, yhi=None,
               xlo=None, xhi=None, markers=True, note=""):
    """series: [{"name", "points": [(x, y)], "theory": bool, "label_end": bool}]"""
    pts_all = [p for s in series for p in s["points"] if p[1] is not None]
    if not pts_all:
        return f'<div class="chart"><h3>{esc(title)}</h3><p class="empty">No data.</p></div>'
    L, R, T, B = 64, 110, 16, 46
    ax = Axis([p[0] for p in pts_all], logx, xlo, xhi)
    ay = Axis([p[1] for p in pts_all], logy, ylo, yhi)
    pw, ph = w - L - R, h - T - B
    X = lambda v: L + pw * ax.frac(v)
    Y = lambda v: T + ph * (1 - ay.frac(v))
    cid = _id()
    o = _frame(w, h, cid, title)
    for t in ay.ticks:
        y = Y(t)
        o.append(f'<line x1="{L}" x2="{L + pw}" y1="{y:.1f}" y2="{y:.1f}" stroke="var(--grid)" stroke-width="1"/>')
        o.append(f'<text x="{L - 6}" y="{y + 4:.1f}" text-anchor="end" font-size="11" fill="var(--muted)">{_fmt(t)}</text>')
    for t in ax.ticks:
        x = X(t)
        o.append(f'<text x="{x:.1f}" y="{T + ph + 16}" text-anchor="middle" font-size="11" fill="var(--muted)">{_fmt(t)}</text>')
    o.append(f'<line x1="{L}" x2="{L + pw}" y1="{T + ph}" y2="{T + ph}" stroke="var(--axis)" stroke-width="1"/>')
    o.append(f'<clipPath id="{cid}k"><rect x="{L - 6}" y="{T - 6}" width="{pw + 12}" height="{ph + 12}"/></clipPath>')
    o.append(f'<text x="{L + pw / 2}" y="{h - 8}" text-anchor="middle" font-size="12" fill="var(--ink2)">{esc(xlabel)}</text>')
    o.append(f'<text transform="translate(14 {T + ph / 2}) rotate(-90)" text-anchor="middle" font-size="12" '
             f'fill="var(--ink2)">{esc(ylabel)}</text>')
    legend, ci = [], 0
    for s in series:
        pts = sorted((p for p in s["points"] if p[1] is not None and (p[1] > 0 or not logy)), key=lambda p: p[0])
        if not pts:
            continue
        color = "var(--theory)" if s.get("theory") else SERIES[ci % 3]
        if not s.get("theory"):
            ci += 1
        legend.append((s["name"], color, s.get("theory")))
        width = 1.5 if s.get("theory") else 2
        if len(pts) > 1:
            o.append(f'<polyline clip-path="url(#{cid}k)" fill="none" stroke="{color}" stroke-width="{width}" stroke-linejoin="round" '
                     f'stroke-linecap="round" points="{" ".join(f"{X(x):.1f},{Y(y):.1f}" for x, y in pts)}"/>')
        if markers and not s.get("theory"):
            for x, y in pts:
                o.append(f'<g class="pt"><circle cx="{X(x):.1f}" cy="{Y(y):.1f}" r="12" fill="transparent"/>'
                         f'<circle cx="{X(x):.1f}" cy="{Y(y):.1f}" r="4" fill="{color}" stroke="var(--surface)" '
                         f'stroke-width="2"/><title>{esc(s["name"])}: {_fmt(y)} at {_fmt(x)}</title></g>')
        if s.get("label_end", True):
            inside = [q_ for q_ in pts if 0 <= ay.frac(q_[1]) <= 1 and 0 <= ax.frac(q_[0]) <= 1]
            if not inside:
                continue
            x, y = inside[-1]
            o.append(f'<text x="{X(x) + 8:.1f}" y="{Y(y) + 4:.1f}" font-size="11" fill="var(--ink2)">{esc(s["name"])}</text>')
    o.append("</svg>")
    xs = sorted({p[0] for s in series for p in s["points"]})
    rows = []
    for x in xs:
        row = [_fmt(x)]
        for s in series:
            v = [p[1] for p in s["points"] if p[0] == x]
            row.append(_fmt(v[0]) if v and v[0] is not None else "")
        rows.append(row)
    return (f'<div class="chart"><h3>{esc(title)}</h3>{_legend(legend)}{"".join(o)}'
            f'{f"<p class=note>{esc(note)}</p>" if note else ""}'
            f'{_table([xlabel] + [s["name"] for s in series], rows)}</div>')


def bar_chart(cats, series, title, ylabel, logy=False, w=680, h=300, note="", fmt=None, ylo=None, yhi=None):
    """cats: category labels; series: [{"name", "values": [v per cat]}] (max 3 series)."""
    fmt = fmt or _fmt
    vals = [v for s in series for v in s["values"] if v is not None]
    if not cats or not vals:
        return f'<div class="chart"><h3>{esc(title)}</h3><p class="empty">No data.</p></div>'
    L, R, T, B = 64, 20, 16, 56
    ay = Axis(vals + ([] if logy else [0]), logy, ylo, yhi)
    pw, ph = w - L - R, h - T - B
    Y = lambda v: T + ph * (1 - ay.frac(v))
    base = Y(ay.lo) if logy else Y(max(0, ay.lo))
    band = pw / len(cats)
    ns = len(series)
    bw = min(24, (band - 8 - 2 * (ns - 1)) / ns)
    cid = _id()
    o = _frame(w, h, cid, title)
    for t in ay.ticks:
        y = Y(t)
        o.append(f'<line x1="{L}" x2="{L + pw}" y1="{y:.1f}" y2="{y:.1f}" stroke="var(--grid)" stroke-width="1"/>')
        o.append(f'<text x="{L - 6}" y="{y + 4:.1f}" text-anchor="end" font-size="11" fill="var(--muted)">{_fmt(t)}</text>')
    o.append(f'<text transform="translate(14 {T + ph / 2}) rotate(-90)" text-anchor="middle" font-size="12" '
             f'fill="var(--ink2)">{esc(ylabel)}</text>')
    for i, c in enumerate(cats):
        cx = L + band * i + band / 2
        o.append(f'<text x="{cx:.1f}" y="{T + ph + 16}" text-anchor="middle" font-size="11" fill="var(--muted)">{esc(c)}</text>')
        x0 = cx - (ns * bw + 2 * (ns - 1)) / 2
        for k, s in enumerate(series):
            v = s["values"][i]
            if v is None or (logy and v <= 0):
                continue
            y = Y(v)
            hgt = max(base - y, 1)
            x = x0 + k * (bw + 2)
            r = min(4, bw / 2, hgt)
            path = (f"M{x:.1f},{base:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} H{x + bw - r:.1f} "
                    f"Q{x + bw:.1f},{y:.1f} {x + bw:.1f},{y + r:.1f} V{base:.1f} Z")
            o.append(f'<g class="bar"><rect x="{x - 3:.1f}" y="{T}" width="{bw + 6:.1f}" height="{ph}" fill="transparent"/>'
                     f'<path d="{path}" fill="{SERIES[k % 3]}"/><title>{esc(s["name"])} · {esc(c)}: {fmt(v)}</title></g>')
            if ns == 1 and len(cats) <= 14:
                o.append(f'<text x="{x + bw / 2:.1f}" y="{y - 4:.1f}" text-anchor="middle" font-size="10" '
                         f'fill="var(--ink2)">{fmt(v)}</text>')
    o.append(f'<line x1="{L}" x2="{L + pw}" y1="{base:.1f}" y2="{base:.1f}" stroke="var(--axis)" stroke-width="1"/>')
    o.append("</svg>")
    rows = [[c] + [fmt(s["values"][i]) if s["values"][i] is not None else "" for s in series] for i, c in enumerate(cats)]
    legend = _legend([(s["name"], SERIES[k % 3], False) for k, s in enumerate(series)], kind="bar")
    return (f'<div class="chart"><h3>{esc(title)}</h3>{legend}{"".join(o)}'
            f'{f"<p class=note>{esc(note)}</p>" if note else ""}{_table(["category"] + [s["name"] for s in series], rows)}</div>')
