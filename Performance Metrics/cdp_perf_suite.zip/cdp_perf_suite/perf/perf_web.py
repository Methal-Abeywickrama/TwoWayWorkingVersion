"""Dashboard page served by perf_daemon.py (single self-contained HTML, no external resources)."""

DASHBOARD = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CDP Link Perf</title>
<style>
:root{color-scheme:light;--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;
--grid:#e1e0d9;--axis:#c3c2b7;--ring:rgba(11,11,11,.10);--s1:#2a78d6;--s2:#eb6834;--s3:#1baf7a;
--good:#0ca30c;--warn:#fab219;--crit:#d03b3b;--accent:#2a78d6;--wash:rgba(42,120,214,.10)}
@media (prefers-color-scheme:dark){:root:where(:not([data-theme="light"])){color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;
--ink:#fff;--ink2:#c3c2b7;--grid:#2c2c2a;--axis:#383835;--ring:rgba(255,255,255,.10);--s1:#3987e5;--s2:#d95926;--s3:#199e70;--accent:#3987e5;--wash:rgba(57,135,229,.14)}}
:root[data-theme="dark"]{color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;--ink:#fff;--ink2:#c3c2b7;--grid:#2c2c2a;--axis:#383835;
--ring:rgba(255,255,255,.10);--s1:#3987e5;--s2:#d95926;--s3:#199e70;--accent:#3987e5;--wash:rgba(57,135,229,.14)}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}
header{display:flex;flex-wrap:wrap;gap:12px 20px;align-items:center;padding:14px 20px;border-bottom:1px solid var(--ring);background:var(--surface)}
header h1{font-size:16px;margin:0;font-weight:650}header .meta{color:var(--ink2);font-size:13px}
.pill{display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;border:1px solid var(--ring);font-size:12px;font-weight:600}
.dot{width:8px;height:8px;border-radius:50%}
main{max-width:1280px;margin:0 auto;padding:16px 20px 40px;display:grid;gap:16px}
.card{background:var(--surface);border:1px solid var(--ring);border-radius:10px;padding:14px 16px}
.card h2{font-size:13px;font-weight:650;margin:0 0 10px;color:var(--ink2);text-transform:uppercase;letter-spacing:.04em}
.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.tile{border:1px solid var(--ring);border-radius:8px;padding:10px 12px;background:var(--surface)}
.tile .l{font-size:12px;color:var(--ink2)}.tile .v{font-size:22px;font-weight:620;margin-top:2px}.tile .s{font-size:12px;color:var(--muted)}
.cols{display:grid;grid-template-columns:1.1fr .9fr;gap:16px}@media(max-width:900px){.cols{grid-template-columns:1fr}}
.tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:12px}.tabs button{border:1px solid var(--ring);background:transparent;color:var(--ink2);
padding:5px 12px;border-radius:6px;cursor:pointer;font:inherit}.tabs button.on{background:var(--wash);color:var(--ink);border-color:var(--accent)}
form{display:grid;gap:10px}form[hidden]{display:none}label{display:grid;gap:4px;font-size:12px;color:var(--ink2)}
input[type=text],input[type=number],select,textarea{font:inherit;color:var(--ink);background:var(--page);border:1px solid var(--axis);border-radius:6px;padding:6px 8px;width:100%}
.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}
.checks{display:flex;flex-wrap:wrap;gap:6px 14px;color:var(--ink)}.checks label{display:flex;gap:5px;align-items:center;font-size:13px;color:var(--ink)}
button.go{justify-self:start;background:var(--accent);color:#fff;border:0;border-radius:6px;padding:7px 16px;font:inherit;font-weight:600;cursor:pointer}
button.sec{background:transparent;color:var(--ink);border:1px solid var(--axis);border-radius:6px;padding:6px 12px;font:inherit;cursor:pointer}
.hint{font-size:12px;color:var(--muted);margin:0}
.bar{height:8px;border-radius:4px;background:var(--wash);overflow:hidden}.bar>i{display:block;height:100%;background:var(--accent);border-radius:4px}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:5px 6px;border-bottom:1px solid var(--grid)}th{color:var(--ink2);font-weight:600}
td.n{font-variant-numeric:tabular-nums;text-align:right}
pre{margin:0;max-height:260px;overflow:auto;font:12px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--ink2);white-space:pre-wrap}
a{color:var(--accent)}.spark{width:100%;height:90px;display:block}
.sparkhead{display:flex;justify-content:space-between;font-size:12px;color:var(--ink2);margin:6px 0 2px}
</style></head><body>
<header>
  <h1>CDP link · performance</h1>
  <span class="meta" id="who">connecting…</span>
  <span class="pill" id="fg"><span class="dot"></span><span>flowgraph</span></span>
  <span class="meta" id="logname"></span>
</header>
<main>
  <section class="card"><h2>Live (this node)</h2>
    <div class="tiles" id="tiles"></div>
    <div class="cols" style="margin-top:12px">
      <div><div class="sparkhead"><span>Per-frame SNR from EVM (dB)</span><span id="snrlast"></span></div><svg class="spark" id="sp1" role="img" aria-label="SNR over time"></svg></div>
      <div><div class="sparkhead"><span>Noise floor at the antenna (dBFS)</span><span id="nflast"></span></div><svg class="spark" id="sp2" role="img" aria-label="Noise floor over time"></svg></div>
    </div>
  </section>

  <div class="cols">
    <section class="card"><h2>Run a test</h2>
      <div class="tabs" id="tabs"></div>
      <form id="f-plan" data-tab="Full review">
        <label>Plan <select id="plan"></select></label><p class="hint" id="plandesc"></p>
        <p class="hint">Runs on THIS node as sender. Keep the daemon running on the other PC too (it records the receiving side).</p>
        <button class="go">Queue plan</button></form>
      <form id="f-link" data-tab="Link BER set" hidden>
        <label>Message set <select id="lset"></select></label><p class="hint" id="lsetdesc"></p>
        <div class="row"><label>Offered load (0–1 of air rate)<input type="number" id="lload" step="0.05" min="0.05" max="1" value="0.8"></label>
        <label>Extra gap per frame (s)<input type="number" id="lgap" step="0.01" min="0" value="0"></label></div>
        <p class="hint">Raw frames straight into the framer (no ARQ): every frame is sent once. The other PC's log records what arrived, including the bits of failed frames. Bring both logs together to get BER and error density per frame.</p>
        <button class="go">Send set</button></form>
      <form id="f-arq" data-tab="ARQ sweep" hidden>
        <label>Message sizes (bytes, comma separated)<input type="text" id="asizes" value="16,64,128,200,400,1000,4000"></label>
        <div class="checks" id="apats"></div>
        <div class="row"><label>Repetitions per size × pattern<input type="number" id="areps" value="3" min="1"></label>
        <label>Gap between messages (s)<input type="number" id="agap" value="0.5" step="0.1" min="0"></label></div>
        <p class="hint">Full stack: app frame → SR-ARQ → radio. Measures completion time, goodput, retransmissions vs packet size, RTT and handshake time. The other PC verifies every byte.</p>
        <button class="go">Queue sweep</button></form>
      <form id="f-idle" data-tab="Idle baseline" hidden>
        <label>Duration (s)<input type="number" id="idur" value="20" min="1"></label>
        <p class="hint">Nobody transmits: records the noise floor and false sync detections.</p>
        <button class="go">Queue idle</button></form>
      <form id="f-mark" data-tab="Note" hidden>
        <label>Note written into the log (shows in the report timeline)<input type="text" id="mtext" placeholder="e.g. antennas 3 m apart, CH_GAIN 10"></label>
        <button class="go">Add note</button></form>
      <p class="hint" id="submitmsg"></p>
    </section>

    <section class="card"><h2>Jobs</h2>
      <div id="cur"><p class="hint">No job running.</p></div>
      <div style="display:flex;gap:8px;margin:10px 0"><button class="sec" id="cancel">Cancel running + queued</button></div>
      <table><thead><tr><th>Job</th><th>Type</th><th>Status</th><th>Result</th></tr></thead><tbody id="jobs"></tbody></table>
    </section>
  </div>

  <section class="card"><h2>Flowgraph parameters (live from the running flowgraph)</h2>
    <table><thead><tr><th>Group</th><th>Parameter</th><th>Value</th></tr></thead><tbody id="params"></tbody></table>
    <p class="hint">Change them in GRC and restart the flowgraph; every report lists them for both nodes.</p>
  </section>

  <section class="card"><h2>Logs and reports</h2>
    <p class="hint">Select this node's log and the other PC's log (import it first), then build the report. One log alone gives a one-sided report.</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:8px 0">
      <label style="display:flex;gap:8px;align-items:center;color:var(--ink)">Import peer log <input type="file" id="up" accept=".jsonl"></label>
      <input type="text" id="rtitle" placeholder="Report title (optional)" style="max-width:320px">
      <button class="go" id="build">Build report from selected logs</button><span class="hint" id="rstate"></span>
    </div>
    <table><thead><tr><th></th><th>Log</th><th>Node</th><th>Host</th><th class="n">Size</th><th>Modified</th><th></th></tr></thead><tbody id="logs"></tbody></table>
    <h2 style="margin-top:16px">Reports</h2><table><tbody id="reports"></tbody></table>
  </section>

  <section class="card"><h2>Activity</h2><pre id="lines"></pre></section>
</main>
<script>
const $=id=>document.getElementById(id);
const el=(t,txt,cls)=>{const e=document.createElement(t);if(txt!=null)e.textContent=txt;if(cls)e.className=cls;return e};
const fmt=(v,d=1)=>v==null||Number.isNaN(v)?'–':Number(v).toLocaleString(undefined,{maximumFractionDigits:d,minimumFractionDigits:d});
const fint=v=>v==null?'–':Number(v).toLocaleString();
const pct=v=>v==null?'–':(100*v).toFixed(v<0.01?2:1)+' %';
const sci=v=>v==null?'–':(v===0?'0':v.toExponential(1));
async function j(url,opt){const r=await fetch(url,opt);const b=await r.json();if(!r.ok)throw new Error(b.error||r.status);return b}
const PATTERNS=["random","zeros","ones","alt55","altAA","text","ramp"];
// tabs
const forms=[...document.querySelectorAll('form[data-tab]')];
forms.forEach((f,i)=>{const b=el('button',f.dataset.tab);b.type='button';if(i===0)b.classList.add('on');
 b.onclick=()=>{forms.forEach(x=>x.hidden=x!==f);[...$('tabs').children].forEach(x=>x.classList.toggle('on',x===b))};$('tabs').append(b)});
PATTERNS.forEach(p=>{const l=el('label');const c=el('input');c.type='checkbox';c.value=p;c.checked=(p==='random');l.append(c,document.createTextNode(p));$('apats').append(l)});
async function submit(job){try{const r=await j('/api/job',{method:'POST',body:JSON.stringify(job)});$('submitmsg').textContent='Queued '+r.ids.join(', ')}catch(e){$('submitmsg').textContent='Error: '+e.message}}
$('f-plan').onsubmit=e=>{e.preventDefault();submit({type:'plan',name:$('plan').value})};
$('f-link').onsubmit=e=>{e.preventDefault();submit({type:'link',set:$('lset').value,load:+$('lload').value,gap_s:+$('lgap').value})};
$('f-arq').onsubmit=e=>{e.preventDefault();const pats=[...$('apats').querySelectorAll('input:checked')].map(x=>x.value);
 submit({type:'arq',sizes:$('asizes').value.split(',').map(s=>parseInt(s)).filter(x=>x>0),patterns:pats.length?pats:['random'],reps:+$('areps').value,gap_s:+$('agap').value})};
$('f-idle').onsubmit=e=>{e.preventDefault();submit({type:'idle',duration_s:+$('idur').value})};
$('f-mark').onsubmit=e=>{e.preventDefault();submit({type:'mark',text:$('mtext').value})};
$('cancel').onclick=()=>j('/api/cancel',{method:'POST'});
let SETS=[];
async function loadSets(){SETS=await j('/api/sets');for(const [sel,type,desc] of [['plan','plan','plandesc'],['lset','link','lsetdesc']]){
 const s=$(sel);s.textContent='';SETS.filter(x=>x.type===type).forEach(x=>{const o=el('option',x.name);o.value=x.name;s.append(o)});
 const show=()=>{const x=SETS.find(y=>y.name===s.value);$(desc).textContent=x?(x.description||''):''};s.onchange=show;show()}}
function tile(l,v,s){const t=el('div',null,'tile');t.append(el('div',l,'l'),el('div',v,'v'),el('div',s||' ','s'));return t}
function spark(svg,pts,color){const W=svg.clientWidth||400,H=90,P=4;svg.setAttribute('viewBox',`0 0 ${W} ${H}`);svg.textContent='';
 if(pts.length<2)return;const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]);let x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys);
 if(y1-y0<1){y0-=0.5;y1+=0.5}const X=x=>P+(W-2*P)*(x-x0)/Math.max(x1-x0,1e-9),Y=y=>H-P-(H-2*P)*(y-y0)/(y1-y0);
 const ns='http://www.w3.org/2000/svg';for(const gy of [y0,(y0+y1)/2,y1]){const g=document.createElementNS(ns,'line');g.setAttribute('x1',0);g.setAttribute('x2',W);
 g.setAttribute('y1',Y(gy));g.setAttribute('y2',Y(gy));g.setAttribute('stroke','var(--grid)');svg.append(g);const t=document.createElementNS(ns,'text');t.setAttribute('x',W-2);
 t.setAttribute('y',Math.max(10,Math.min(H-2,Y(gy)-2)));t.setAttribute('text-anchor','end');t.setAttribute('font-size','10');t.setAttribute('fill','var(--muted)');t.textContent=gy.toFixed(1);svg.append(t)}
 const p=document.createElementNS(ns,'polyline');p.setAttribute('points',pts.map(q=>X(q[0])+','+Y(q[1])).join(' '));p.setAttribute('fill','none');
 p.setAttribute('stroke',color);p.setAttribute('stroke-width','2');p.setAttribute('stroke-linejoin','round');svg.append(p);
 const c=document.createElementNS(ns,'circle');const L=pts[pts.length-1];c.setAttribute('cx',X(L[0]));c.setAttribute('cy',Y(L[1]));c.setAttribute('r',4);c.setAttribute('fill',color);
 c.setAttribute('stroke','var(--surface)');c.setAttribute('stroke-width',2);svg.append(c)}
async function tick(){let s;try{s=await j('/api/status')}catch(e){$('who').textContent='daemon not reachable';return}
 $('who').textContent=s.ready?`node ${s.node} → peer ${s.peer} · ${s.host}`:'waiting for the flowgraph (start it in GRC) …';
 $('logname').textContent=s.session?'log: '+s.session+'.jsonl ('+fint(s.records)+' records)':'';
 const PT=$('params');if(PT.dataset.n!==String((s.key_params||[]).length)+s.ready){PT.textContent='';PT.dataset.n=String((s.key_params||[]).length)+s.ready;
  let last='';for(const [g,k,v] of (s.key_params||[])){const tr=el('tr');tr.append(el('td',g===last?'':g),el('td',k),el('td',v));last=g;PT.append(tr)}
  if(!(s.key_params||[]).length){const tr=el('tr');tr.append(el('td','–'),el('td','no configuration received yet'),el('td',''));PT.append(tr)}}
 const fg=$('fg');fg.lastChild.textContent=s.flowgraph_alive?'✓ flowgraph telemetry live':'✕ no flowgraph telemetry';fg.firstChild.style.background=s.flowgraph_alive?'var(--good)':'var(--crit)';
 const c=s.live.counters,L=s.live,lp=s.link_params,r=L.rssi||{},ev=L.evm||{};
 const T=$('tiles');T.textContent='';
 T.append(tile('Air bit rate',fmt(lp.bit_rate/1000,0)+' kb/s',`BW ≈ ${fmt(lp.bit_rate*(1+lp.alpha)/1000,0)} kHz · pre ${lp.preamble_len} B`),
  tile('Frames sent',fint(c.tx_frames||0),`${fint(c.tx_link_test||0)} link-test`),
  tile('Frames received OK',fint(c.rx_ok||0),`${fint(c.rx_crc_fail||0)} CRC fail · ${fint(c.rx_bad_len||0)} bad len`),
  tile('Frame error rate (RX)',pct(L.rx_fer),`${fint(L.rx_decided)} decided`),
  tile('Live BER (link test)',sci(L.live_ber),'failed frames vs regenerated'),
  tile('SNR from EVM',ev.snr_db!=null?fmt(ev.snr_db)+' dB':'–',ev.evm_pct!=null?`EVM ${fmt(ev.evm_pct)} %`:''),
  tile('RSSI SNR (wideband)',r.snr_db!=null?fmt(r.snr_db)+' dB':'–',r.sig_dbfs!=null?`signal ${fmt(r.sig_dbfs)} dBFS`:''),
  tile('Noise floor',r.nf_dbfs!=null?fmt(r.nf_dbfs)+' dBFS':'–',r.clip_pct?`clipping ${fmt(r.clip_pct,3)} %`:'no clipping'),
  tile('Occupied BW (99 %)',r.obw99_hz!=null?fmt(r.obw99_hz/1000,0)+' kHz':'–',r.cfo_hz!=null?`CFO ${fmt(r.cfo_hz/1000,2)} kHz`:''),
  tile('ARQ DATA sent',fint(c.tp_tx_DATA||0),`${fint(c.tp_retx||0)} retransmitted`),
  tile('ACKs received',fint(c.tp_rx_ACK||0),`${fint(c.tp_tx_ACK||0)} ACKs sent`),
  tile('Test messages in',fint((c.app_rx_ok||0)+(c.app_rx_bad||0)),`${fint(c.app_rx_bad||0)} with content errors`));
 const h=L.hist;spark($('sp1'),h.filter(x=>x[1]!=null).map(x=>[x[0],x[1]]),'var(--s1)');spark($('sp2'),h.filter(x=>x[3]!=null).map(x=>[x[0],x[3]]),'var(--s2)');
 $('snrlast').textContent=ev.snr_db!=null?fmt(ev.snr_db)+' dB':'';$('nflast').textContent=r.nf_dbfs!=null?fmt(r.nf_dbfs)+' dBFS':'';
 const cur=$('cur');cur.textContent='';if(s.current){const x=s.current,p=x.total?x.done/x.total:0;cur.append(el('div',`${x.id} · ${x.type} · ${x.done}/${x.total}`),
  Object.assign(el('div',null,'bar'),{innerHTML:''}),el('p',x.note||'','hint'));const b=cur.children[1];const i=el('i');i.style.width=(100*p).toFixed(1)+'%';b.append(i)}
 else cur.append(el('p',s.queue.length?`${s.queue.length} queued`:'No job running.','hint'));
 const JB=$('jobs');JB.textContent='';for(const q of s.queue){const tr=el('tr');tr.append(el('td',q.id),el('td',q.type+(q.set?' · '+q.set:'')),el('td','queued'),el('td',''));JB.append(tr)}
 for(const d of s.done){const tr=el('tr');tr.append(el('td',d.id),el('td',d.type+(d.set?' · '+d.set:'')),el('td',(d.status==='done'?'✓ ':d.status==='error'?'✕ ':'– ')+d.status),el('td',JSON.stringify(d.summary).slice(0,80)));JB.append(tr)}
 $('lines').textContent=s.lines.join('\n');
 const rs=s.report;$('rstate').textContent=rs.state==='running'?'building…':rs.state==='error'?'Error: '+rs.error:rs.state==='done'?'done: '+rs.dir:'';}
async function lists(){try{const logs=await j('/api/logs');const T=$('logs');const keep=new Set([...T.querySelectorAll('input:checked')].map(x=>x.value));T.textContent='';
 for(const l of logs){const tr=el('tr');const c=el('input');c.type='checkbox';c.value=l.kind+'/'+l.name;c.checked=keep.has(c.value)||(keep.size===0&&(l.current||l.kind==='imported'));
  const td=el('td');td.append(c);const a=el('a','download');a.href=`/files/${l.kind}/${encodeURIComponent(l.name)}`;const tda=el('td');tda.append(a);
  tr.append(td,el('td',(l.current?'● ':'')+l.name+(l.kind==='imported'?' (imported)':'')),el('td',l.node??'?'),el('td',l.host||''),el('td',(l.size/1024).toFixed(0)+' kB','n'),
  el('td',new Date(l.mtime*1000).toLocaleString()),tda);T.append(tr)}
 const reps=await j('/api/reports');const R=$('reports');R.textContent='';for(const r of reps){const tr=el('tr');const a=el('a',r.name);a.href=`/reports/${encodeURIComponent(r.name)}/report.html`;a.target='_blank';
  const td=el('td');td.append(a);const c=el('a','CSV / JSON files');c.href=`/reports/${encodeURIComponent(r.name)}/summary.json`;const td2=el('td');td2.append(c);
  tr.append(td,el('td',new Date(r.mtime*1000).toLocaleString()),td2);R.append(tr)}}catch(e){}}
$('up').onchange=async e=>{const f=e.target.files[0];if(!f)return;await fetch('/api/upload?name='+encodeURIComponent(f.name),{method:'POST',body:f});lists()};
$('build').onclick=async()=>{const sel=[...$('logs').querySelectorAll('input:checked')].map(x=>{const [kind,...n]=x.value.split('/');return{kind,name:n.join('/')}});
 if(!sel.length){$('rstate').textContent='select at least one log';return}try{await j('/api/report',{method:'POST',body:JSON.stringify({logs:sel,title:$('rtitle').value||null})});$('rstate').textContent='building…'}catch(e){$('rstate').textContent='Error: '+e.message}};
loadSets();tick();lists();setInterval(tick,1000);setInterval(lists,4000);
</script></body></html>
"""
