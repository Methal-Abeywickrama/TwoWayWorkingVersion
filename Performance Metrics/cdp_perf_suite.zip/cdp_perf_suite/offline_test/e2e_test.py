"""
Full simulated hardware session, checked against ground truth.

Node A (MY_ID 0, PEER_ID 1) and node B (MY_ID 1, PEER_ID 0), set like the GRC variables on the two PCs;
both perf daemons started WITHOUT addresses (they learn them from the flowgraph); A's dashboard on :8098.
A->B Es/N0 is changed between jobs (SNR sweep 6..13 dB, ARQ at 9.5 dB); B->A runs at 10 dB.
Checks: every failed burst's bit-error count in the report == the channel's true count; BER;
SNR estimate vs the channel setting; CFO; OBW; ARQ retransmissions & delivery; one-sided report;
report with B's clock shifted by +2.5 s.
"""
import csv
import json
import os
import shutil
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_harness as H  # noqa: E402
import perf_report  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
GEN = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "generated_hw")
GRC = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, "..", "perf_hw.grc")
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "out")
SHOTS = os.path.join(OUT, "shots")
shutil.rmtree(OUT, ignore_errors=True)
os.makedirs(SHOTS)
snr = {"ab": 12.0, "ba": 10.0}
A = H.Node("A", GEN, ids=(0, 1))
B = H.Node("B", GEN, ids=(1, 0))
# count what reaches each FSM vs what the RX header parser produced (node 0 used to get every packet twice)
fsm_in = {"A": 0, "B": 0}
parsed = {"A": 0, "B": 0}
for n, node in (("A", A), ("B", B)):
    h = node.blocks["epy_block_1"]._handlers["pdu_in"]
    node.blocks["epy_block_1"]._handlers["pdu_in"] = (lambda m, h=h, n=n: (fsm_in.__setitem__(n, fsm_in[n] + 1), h(m)))
    H.gr.msg_connect(node.blocks["epy_block_0"], "pdus", (lambda m, n=n: parsed.__setitem__(n, parsed[n] + 1)), None)
ab = H.Channel(A, B, lambda t: snr["ab"], cfo_hz=1200.0)
ba = H.Channel(B, A, lambda t: snr["ba"], cfo_hz=-800.0, sig_dbfs=-30.0)
ab.start(); ba.start()
dA = H.make_daemon(A, f"{OUT}/A", http_port=8098, grc=GRC)
dB = H.make_daemon(B, f"{OUT}/B", http_port=8099, grc=GRC)
while not (dA.ready.is_set() and dB.ready.is_set() and dA.flowgraph_alive() and dB.flowgraph_alive()):
    time.sleep(0.2)
print("daemons learned their addresses:", (dA.a.local_addr, dA.a.peer), (dB.a.local_addr, dB.a.peer))
assert (dA.a.local_addr, dA.a.peer, dB.a.local_addr, dB.a.peer) == (0, 1, 1, 0)
snr_log = []


def run(d, job, ab_db=None):
    if ab_db is not None:
        snr["ab"] = ab_db
    ids = d.submit(job)
    while d.jobs or d.current:
        time.sleep(0.2)
    snr_log.append((job.get("type"), ab_db, ids))
    return ids


def shot(url, name, full=False, wait=1.5):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return                                   # screenshots are optional
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1300, "height": 900})
        pg.goto(url)
        pg.wait_for_timeout(int(wait * 1000))
        pg.screenshot(path=os.path.join(SHOTS, name), full_page=full)
        b.close()


t_start = time.time()
run(dA, {"type": "mark", "text": "e2e start, antennas 1 m"})
run(dA, {"type": "idle", "duration_s": 3})
# link set at 12 dB: sizes and patterns
items = [{"size": s, "count": 12, "pattern": "random"} for s in (32, 128, 512, 2048)] + \
        [{"size": 512, "count": 12, "pattern": p} for p in ("zeros", "ones")]
threading.Thread(target=lambda: (time.sleep(2.0), shot("http://127.0.0.1:8098/", "dashboard_running.png")), daemon=True).start()
run(dA, {"type": "link", "items": items, "load": 0.8}, ab_db=12.0)
# SNR sweep with 400 B frames
for db in (6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 13.0):
    run(dA, {"type": "link", "items": [{"size": 400, "count": 25, "pattern": "random"}], "load": 0.9}, ab_db=db)
# stress (max bit rate) at 13 dB
run(dA, {"type": "link", "items": [{"size": 4096, "count": 15, "pattern": "random"}], "load": 1.0}, ab_db=13.0)
# ARQ sweep at 9.5 dB (some retransmissions), plus B -> A messages
run(dA, {"type": "arq", "sizes": [16, 120, 400, 1500, 5000], "patterns": ["random"], "reps": 2, "gap_s": 0.3}, ab_db=8.0)
run(dB, {"type": "arq", "sizes": [200, 2000], "patterns": ["text"], "reps": 1, "gap_s": 0.3})
run(dA, {"type": "mark", "text": "e2e end"})
time.sleep(1.5)
shot("http://127.0.0.1:8098/", "dashboard_done.png")
print(f"session took {time.time() - t_start:.0f} s")
live_retx = dA.stats.c.get("tp_retx", 0)
print("packets into the FSM vs parsed:", fsm_in, parsed)
assert fsm_in == parsed, "a node handed packets to its FSM twice"
logA, logB = str(dA.log.path), str(dB.log.path)

# dashboard: build the report through the HTTP API, like a user would
import urllib.request  # noqa: E402
shutil.copy(logB, f"{OUT}/A/perf_logs/imported/{os.path.basename(logB)}")
req = urllib.request.Request("http://127.0.0.1:8098/api/report", method="POST",
                             data=json.dumps({"logs": [{"kind": "local", "name": os.path.basename(logA)},
                                                       {"kind": "imported", "name": os.path.basename(logB)}],
                                              "title": "Simulated session"}).encode())
print("report via API:", urllib.request.urlopen(req).read().decode())
while dA.report_state.get("state") == "running":
    time.sleep(0.2)
print("report state:", dA.report_state)
time.sleep(4.5)
shot("http://127.0.0.1:8098/", "dashboard_reports.png", full=True)
dA.close(); dB.close()
ab.stop = ba.stop = True
time.sleep(0.3)

# ---------------- checks against ground truth
out = perf_report.build_report([logA, logB], f"{OUT}/report", title="CDP transceiver — simulated hardware session")
rows = [r for r in csv.DictReader(open(out / "frames.csv")) if r["direction"].startswith("0")]
truth = ab.truth
print(f"A->B bursts: report {len(rows)}, channel {len(truth)}")
assert len(rows) == len(truth), "burst count mismatch"
cmp = mism = 0
st_count = {}
for r, t in zip(rows, truth):
    st_count[r["status"]] = st_count.get(r["status"], 0) + 1
    if r["status"] == "crc_fail" and r["partial"] == "False":
        cmp += 1
        if int(r["bit_errors"]) != t["errors"]:
            mism += 1
            print("  MISMATCH", r["msg_id"], r["payload_len"], r["bit_errors"], t["errors"])
    if r["status"] == "ok" and t["errors"] != int(r["bit_errors"]):
        mism += 1
        print("  OK-frame mismatch", r["msg_id"], r["bit_errors"], t["errors"])
print(f"statuses {st_count}; failed bursts compared bit-exactly: {cmp}, mismatches: {mism}")
det = [(r, t) for r, t in zip(rows, truth) if r["status"] in ("ok", "crc_fail") and r["partial"] != "True"]
print(f"BER over detected bursts: report {sum(int(r['bit_errors']) for r, _ in det) / sum(int(r['bits']) for r, _ in det):.3e} "
      f"truth {sum(t['errors'] for _, t in det) / sum(int(r['bits']) for r, _ in det):.3e}")
by = {}
for r, t in zip(rows, truth):
    if r["snr_db"] and t["esn0"] is not None:
        by.setdefault(t["esn0"], []).append(float(r["snr_db"]))
print("Es/N0 set -> SNR(EVM) median:", {k: round(sorted(v)[len(v) // 2], 2) for k, v in sorted(by.items())})
s = json.load(open(out / "summary.json"))
print("ARQ:", s["arq"])
print("live dashboard retx", live_retx, "vs report", s["arq"]["0"]["retx"])
assert live_retx == s["arq"]["0"]["retx"]
kp = {k: dict(((g, n), v) for g, n, v in rows_) for k, rows_ in s["key_parameters"].items()}
for want in (("Framing", "Preamble length"), ("RX loops", "Costas loop BW (costas_bw) / order"),
             ("RX loops", "Symbol sync loop BW (sym_bw)"), ("Radio", "Power squelch"), ("SR-ARQ", "RTO / max retries")):
    print("  report parameter", want[1], "=", kp["0"][want])
print("clock:", s["clock"], s["offsets"])
rs = [json.loads(l) for l in open(logB) if '"tap":"rssi"' in l]
cfo = [r["cfo_hz"] for r in rs if r.get("cfo_hz") is not None and r.get("busy_pct", 0) >= 20]
obw = [r["obw99_hz"] for r in rs if r.get("obw99_hz") is not None and r.get("busy_pct", 0) >= 20]
wsnr = [(r["snr_db"]) for r in rs if r.get("snr_db") is not None and r.get("busy_pct", 0) > 30]
print(f"node 2 RF: CFO median {sorted(cfo)[len(cfo) // 2]:.0f} Hz (set 1200), OBW median {sorted(obw)[len(obw) // 2] / 1e3:.0f} kHz, "
      f"wideband SNR median {sorted(wsnr)[len(wsnr) // 2]:.1f} dB")
assert mism == 0

# one-sided and clock-shifted
perf_report.build_report([logA], f"{OUT}/report_A_only")
shifted = f"{OUT}/B_shifted.jsonl"
with open(logB) as f, open(shifted, "w") as g:
    for line in f:
        r = json.loads(line)
        for k in ("t", "rt", "t0", "t1", "t_start"):
            if isinstance(r.get(k), (int, float)):
                r[k] += 2.5
        r["session"] = r.get("session", "") + "_shift" if r.get("k") == "session_start" else r.get("session")
        g.write(json.dumps(r) + "\n")
o2 = perf_report.build_report([logA, shifted], f"{OUT}/report_shift")
s2 = json.load(open(o2 / "summary.json"))
print("shifted B clock by +2.5 s -> estimated offset:", round(s2["offsets"]["1"], 4), "s")
d1, d2 = s["directions"], s2["directions"]
assert all(abs((d1[k]["ber"] or 0) - (d2[k]["ber"] or 0)) < 1e-12 for k in d1), "clock shift changed BER"
print("RESULT: PASS")
