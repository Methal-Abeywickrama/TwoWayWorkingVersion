"""
Two-node simulation of the instrumented flowgraph + both perf daemons, in one process, real time.

- Message blocks: the generated epy code (FSM, header blocks, framer/deframer with taps, hub, probes)
  wired exactly as in the generated transeciever.py (msg_connect lines).
- Non-epy blocks: small fakes (pdu filter, message debug, ZMQ message blocks -> LocalTransport).
- Radio: per direction a real-time BPSK channel thread, 375 kBd: framer bytes -> differential
  encoding -> +/-1 symbols -> AWGN at Es/N0 (+ slow phase walk) = "Costas output" -> EVM probe;
  hard decisions -> differential decoding -> bits -> deframer; and the same symbols pulse-shaped
  (RRC) at 4 samples/symbol with CFO and a noise floor -> RSSI/spectrum probe. Idle = noise only.
  The channel records the TRUE number of bit errors in every burst for checking the report.
"""
import collections
import importlib.util
import json
import os
import re
import sys
import threading
import time
import types

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL = next(p for p in (os.path.join(HERE, "..", "perf"), os.path.join(HERE, "..", "tool")) if os.path.isdir(p))
sys.path.insert(0, os.path.join(HERE, "fakegr"))
sys.path.insert(0, TOOL)
import pmt  # noqa: E402
from gnuradio import gr  # noqa: E402
import perf_daemon  # noqa: E402

FS, SPS = 1.5e6, 4
RS = FS / SPS
rng = np.random.default_rng(11)


class FakeBlock(gr.basic_block):
    def __init__(self):
        gr.basic_block.__init__(self, name=type(self).__name__)


class PduFilter(FakeBlock):
    def __init__(self, k, v, invert=False):
        super().__init__()
        self.k, self.v, self.invert = k, v, invert
        self.message_port_register_out(pmt.intern("pdus"))
        self.set_msg_handler(pmt.intern("pdus"), self.handle)

    def handle(self, msg):
        meta = pmt.car(msg)
        ok = pmt.is_dict(meta) and pmt.dict_has_key(meta, self.k) and pmt.equal(pmt.dict_ref(meta, self.k, pmt.PMT_NIL), self.v)
        if ok != self.invert:
            self.message_port_pub(pmt.intern("pdus"), msg)


class MsgDebug(FakeBlock):
    def __init__(self):
        super().__init__()
        for p in ("print", "print_pdu", "store"):
            self.set_msg_handler(pmt.intern(p), lambda m: None)


class MsgSource(FakeBlock):
    def __init__(self):
        super().__init__()
        self.message_port_register_out(pmt.intern("out"))


class MsgSink(FakeBlock):
    def __init__(self):
        super().__init__()
        self.cb = None
        self.set_msg_handler(pmt.intern("in"), lambda m: self.cb and self.cb(m))


class Radio(FakeBlock):
    def __init__(self):
        super().__init__()
        self.q = collections.deque()
        self.set_msg_handler(pmt.intern("pdus"), lambda m: self.q.append(bytes(pmt.cdr(m).val)))


class FakeTB(gr.top_block):
    pass


def _load(gen_dir, modname, cache={}):
    key = (gen_dir, modname)
    if key not in cache:
        spec = importlib.util.spec_from_file_location(modname, os.path.join(gen_dir, modname + ".py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        cache[key] = mod
    return cache[key]


class Node:
    def __init__(self, name, gen_dir, env=None, ids=None, module=None):
        """ids=(MY_ID, PEER_ID): what you would type into the GRC variables on that PC."""
        self.name = name
        env = env or {}
        if module is None:          # the generated top-level file (cdp_perf.py, ...)
            module = next(f[:-3] for f in sorted(os.listdir(gen_dir)) if f.endswith(".py") and "_epy_block_" not in f)
        self.module = module
        py = open(os.path.join(gen_dir, f"{module}.py")).read()
        if ids is not None:
            py = re.sub(r"self\.MY_ID = MY_ID = .*", f"self.MY_ID = MY_ID = {ids[0]}", py)
            py = re.sub(r"self\.PEER_ID = PEER_ID = .*", f"self.PEER_ID = PEER_ID = {ids[1]}", py)
        old = dict(os.environ)
        os.environ.update(env)
        try:
            body = py.split("# Variables")[1].split("# Blocks")[0]
            lines = [ln[8:] for ln in body.splitlines() if ln.startswith("        ") and not ln.strip().startswith("#")]
            ns = {"self": types.SimpleNamespace()}
            exec("import os\nfrom gnuradio import digital\n" + "\n".join(lines), ns)
            ns.pop("self")
        finally:
            os.environ.clear()
            os.environ.update(old)
        self.ns = ns
        self.tb = FakeTB()
        for k, v in ns.items():
            if isinstance(v, (int, float, str, bool)) and not k.startswith("_"):
                setattr(self.tb, k, v)
        self.blocks = {}
        for m in re.finditer(r"self\.(epy_block_\w+) = (epy_block_\w+)\.(\w+)\((.*)\)\n", py):
            var, mod, cls, args = m.groups()
            mobj = _load(gen_dir, f"{self.module}_{mod}")
            self.blocks[var] = eval(f"module.{cls}({args})", {"module": mobj, **ns})
        for m in re.finditer(r"self\.(pdu_pdu_filter_\w+) = pdu\.pdu_filter\((.*)\)\n", py):
            self.blocks[m.group(1)] = eval(f"PduFilter({m.group(2)})", {"PduFilter": PduFilter, "pmt": pmt, **ns})
        for m in re.finditer(r"self\.(blocks_message_debug_\w+) = ", py):
            self.blocks[m.group(1)] = MsgDebug()
        for name in re.findall(r"self\.(zeromq_pull_msg_source_\w+) = ", py):
            self.blocks[name] = MsgSource()
        for name in re.findall(r"self\.(zeromq_(?:push|pub)_msg_sink_\w+) = ", py):
            self.blocks[name] = MsgSink()
        self.blocks["pdu_pdu_to_tagged_stream_0_0"] = self.radio = Radio()
        for k, b in self.blocks.items():
            setattr(self.tb, k, b)
        self.hub = self.blocks["epy_block_6"]
        self.hub._tb = self.tb                      # two nodes in one process: point each hub at its own graph
        for a, ap, b, bp in re.findall(r"self\.msg_connect\(\(self\.(\w+), '(\w+)'\), \(self\.(\w+), '(\w+)'\)\)", py):
            gr.msg_connect(self.blocks[a], ap, self.blocks[b], bp)
        self.deframer = self.blocks["epy_block_0_0_0"]
        self.evm = self.blocks["epy_block_7"]
        self.rssi = self.blocks["epy_block_8"]
        self.hub.start()


class LocalTransport:
    """Same interface as perf_daemon.ZmqTransport, wired straight to a simulated node."""

    def __init__(self, node):
        self.n = node

    def start(self, on_app, on_tel):
        def app(msg):
            meta = perf_daemon.pmt_to_py(pmt, pmt.car(msg))
            on_app(meta if isinstance(meta, dict) else {}, bytes(pmt.cdr(msg).val))

        def tel(msg):
            on_tel(json.loads(bytes(pmt.cdr(msg).val).decode()))
        self.n.blocks["zeromq_push_msg_sink_0"].cb = app
        self.n.blocks["zeromq_pub_msg_sink_tap"].cb = tel

    def send_app(self, frame):
        self.n.blocks["zeromq_pull_msg_source_0"].message_port_pub(
            pmt.intern("out"), pmt.cons(pmt.make_dict(), pmt.init_u8vector(len(frame), frame)))
        return True

    def send_link(self, payload, meta):
        m = pmt.make_dict()
        for k, v in meta.items():
            m = pmt.dict_add(m, pmt.intern(k), pmt.from_uint64(int(v)))
        self.n.blocks["zeromq_pull_msg_source_link"].message_port_pub(
            pmt.intern("out"), pmt.cons(m, pmt.init_u8vector(len(payload), payload)))
        return True

    def close(self):
        pass


def rrc_taps(sps=4, alpha=0.35, span=11):
    n = np.arange(-span * sps // 2, span * sps // 2 + 1) / sps
    h = np.zeros(len(n))
    for i, t in enumerate(n):
        if abs(t) < 1e-9:
            h[i] = 1 - alpha + 4 * alpha / np.pi
        elif abs(abs(4 * alpha * t) - 1) < 1e-9:
            h[i] = alpha / np.sqrt(2) * ((1 + 2 / np.pi) * np.sin(np.pi / (4 * alpha)) + (1 - 2 / np.pi) * np.cos(np.pi / (4 * alpha)))
        else:
            h[i] = (np.sin(np.pi * t * (1 - alpha)) + 4 * alpha * t * np.cos(np.pi * t * (1 + alpha))) / \
                   (np.pi * t * (1 - (4 * alpha * t) ** 2))
    return h / np.sqrt(np.sum(h ** 2))


class Channel(threading.Thread):
    """One FDD direction. esn0(t) gives Es/N0 in dB at time t (seconds since start)."""

    def __init__(self, tx, rx, esn0, preamble_len=1024, chunk=7500, cfo_hz=1200.0, sig_dbfs=-24.0, nf_snr_offset=0.0):
        super().__init__(daemon=True)
        self.tx, self.rx, self.esn0 = tx, rx, esn0
        self.pre_bits = preamble_len * 8
        self.chunk = chunk
        self.cfo = cfo_hz
        self.sig_amp = 10 ** (sig_dbfs / 20)
        self.stop = False
        self.t0 = time.time()
        self.pending = collections.deque()        # [symbols(float +/-1), frame_info]
        self.d_state = 0
        self.dhat_prev = 0
        self.phase = rng.uniform(0, 2 * np.pi)
        self.rf_phase = 0.0
        self.taps = rrc_taps()
        self.tail = np.zeros(len(self.taps) - 1, complex)
        self.truth = []                           # per burst: true bit errors in sync..CRC
        self.cur = None

    def _queue_frame(self, frame):
        bits = np.unpackbits(np.frombuffer(frame, np.uint8)).astype(np.int64)
        d = np.bitwise_xor.accumulate(np.concatenate(([self.d_state], bits)))[1:]
        self.d_state = int(d[-1])
        body_bits = len(bits) - self.pre_bits - 8 * self._post_len(frame)
        info = {"idx": len(self.truth), "len": len(frame), "start": self.pre_bits, "nbits": body_bits, "errors": 0,
                "pos": 0, "esn0": None}
        self.truth.append(info)
        self.pending.append([1.0 - 2.0 * d, info, 0])

    @staticmethod
    def _post_len(frame):
        n = 0
        while n < len(frame) and frame[len(frame) - 1 - n] == 0:
            n += 1
        return min(n, 160)

    def run(self):
        t_next = time.time()
        N = self.chunk
        while not self.stop:
            while self.tx.radio.q:
                self._queue_frame(self.tx.radio.q.popleft())
            sym = np.zeros(N)
            owner = []                                    # (offset in chunk, n, info, offset in frame)
            k = 0
            while k < N and self.pending:
                s, info, off = self.pending[0]
                n = min(N - k, len(s) - off)
                sym[k:k + n] = s[off:off + n]
                owner.append((k, n, info, off))
                k += n
                self.pending[0][2] += n
                if self.pending[0][2] >= len(s):
                    self.pending.popleft()
            active = np.zeros(N, bool)
            for k0, n, _, _ in owner:
                active[k0:k0 + n] = True
            esn0 = self.esn0(time.time() - self.t0)
            sigma = np.sqrt(0.5 / 10 ** (esn0 / 10))
            noise = sigma * (rng.standard_normal(N) + 1j * rng.standard_normal(N))
            ph = rng.normal(0, 0.01, N)                    # residual phase jitter after the Costas loop
            costas = np.where(active, sym * np.exp(1j * ph) + noise, (rng.standard_normal(N) + 1j * rng.standard_normal(N)) / np.sqrt(2))
            dhat = (costas.real < 0).astype(np.uint8)
            bits = np.bitwise_xor(dhat, np.concatenate(([self.dhat_prev], dhat[:-1]))).astype(np.uint8)
            self.dhat_prev = int(dhat[-1])
            # truth: decoded bits vs the bits that were sent, inside each burst's sync..CRC span
            dtrue = (sym < 0).astype(np.uint8)
            ext = np.concatenate(([self._prev_true], dtrue))
            btrue = np.bitwise_xor(ext[1:], ext[:-1])
            self._prev_true = int(dtrue[-1])
            errs = bits != btrue
            for k0, n, info, off in owner:
                a, b = max(off, info["start"]), min(off + n, info["start"] + info["nbits"])
                if b > a:
                    info["errors"] += int(errs[k0 + a - off:k0 + b - off].sum())
                    info["esn0"] = esn0
            self.rx.evm.work([costas.astype(np.complex64)], [])
            self.rx.deframer.work([bits], [])
            # RF: pulse-shaped burst + CFO + noise floor, 4 samples/symbol
            up = np.zeros(N * SPS, complex)
            up[::SPS] = sym
            full = np.concatenate((self.tail, up))
            shaped = np.convolve(full, self.taps, mode="valid")[:N * SPS]
            self.tail = full[-(len(self.taps) - 1):]
            n_rf = len(shaped)
            rot = np.exp(1j * (self.rf_phase + 2 * np.pi * self.cfo / FS * np.arange(n_rf)))
            self.rf_phase = float((self.rf_phase + 2 * np.pi * self.cfo / FS * n_rf) % (2 * np.pi))
            nf = self.sig_amp / np.sqrt(2 * 10 ** (13.0 / 10))          # fixed noise floor at the antenna
            amp = nf * np.sqrt(2 * 10 ** (esn0 / 10))                      # signal level sets Es/N0
            iq = amp * shaped * rot + nf * (rng.standard_normal(n_rf) + 1j * rng.standard_normal(n_rf))
            for j in range(0, n_rf, 4096):
                self.rx.rssi.work([iq[j:j + 4096].astype(np.complex64)], [])
            t_next += N / RS
            dt = t_next - time.time()
            if dt > 0:
                time.sleep(dt)

    _prev_true = 0


def make_daemon(node, root, addr=None, peer=None, http_port=None, grc=None):
    """addr/peer None = learn MY_ID / PEER_ID from the flowgraph, as on the real PCs."""
    a = types.SimpleNamespace(root=root, local_addr=addr, peer=peer, port=0, tx_port=0, rx_port=0, tap_port=0,
                              link_port=0, grc=grc, sets_dir=os.path.join(TOOL, "test_sets"))
    d = perf_daemon.PerfDaemon(a, LocalTransport(node))
    if http_port:
        perf_daemon.serve_http(d, "127.0.0.1", http_port)
    d.start()
    return d
