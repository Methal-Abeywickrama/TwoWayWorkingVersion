"""Pure-Python stand-in for the gnuradio package (tests only)."""
